/**
 @file  config_mp2m.h
 @brief MPEG-1/2 Multiplexer Configuration API

 @verbatim
 File: config_mp2m.h

 Desc: MPEG-1/2 Multiplexer Configuration API

 Copyright (c) 2021 MainConcept GmbH or its affiliates. All rights reserved.

 MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
 This software is protected by copyright law and international treaties. Unauthorized
 reproduction or distribution of any portion is prohibited by law.
 @endverbatim
 **/

#if !defined (__MP2M_CONFIG_API_INCLUDED__)
#define __MP2M_CONFIG_API_INCLUDED__

#include "mcapiext.h"

#include "mux_mp2.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @name API Function Type
 * These defines types for MCAPI_LoadStreamsParamAllocLen and MCAPI_LoadProgramsParamAllocLen functions.
 * @{
 */
 typedef int32_t(MC_EXPORT_API* APIEXTFUNC_LOADPARAMALLOCLEN) (void* param_set, const char *file_name, size_t* alloc_size);
 /** @} */

/**
 * @brief MCAPI_LoadStreamsParamAllocLen return count of bytes for allocation mp2mux_stream_set_struct* in mp2m_param_set.
 * @code
 * int32_t LoadStreamsParamAllocLen  (mp2m_param_set* param_set, const char *file_name, size_t* size);
 * @endcode
 * @param[in] param_set, pointer to mp2m_param_set, only stream_count value will be changed.
 * @param[in] filename  the name of the config file.
 * @param[in] alloc_size, pointer to size_t. return alloc size for stream_params.
 * @return    returns MCAPI_NOERROR if succeeded.
 * @note LoadStreamsParamAllocLen can load parameters from either config file or raw MPEG data.
 */
#define MCAPI_LoadStreamsParamAllocLen  0x00002003

 /**
  * @brief MCAPI_LoadProgramsParamAllocLen return count of bytes for allocation mp2mux_ts_program_set_struct* in mp2m_param_set.
  * @code
  * int32_t LoadProgramsParamAllocLen (mp2m_param_set* param_set, const char *file_name, size_t* size);
  * @endcode
  * @param[in] param_set, pointer to mp2m_param_set, only program_count value will be changed.
  * @param[in] filename  the name of the config file.
  * @param[in] alloc_size, pointer to size_t. return alloc size for program_params.
  * @return    returns MCAPI_NOERROR if succeeded.
  * @note LoadProgramsParamAllocLen can load parameters from either config file or raw MPEG data.
  */
#define MCAPI_LoadProgramsParamAllocLen 0x00002004

/**
 * The API Extension control.
 * @param func one of the following API function identifiers:
 *    MCAPI_LoadParamSet
 *    MCAPI_SaveParamSet
 *    MCAPI_ShowPages
 * @return pointer to the requested API function or NULL, if not supported.
 */
APIEXTFUNC MC_EXPORT_API MP2MConfigGetAPIExt(uint32_t func);

#ifdef __cplusplus
}
#endif

#pragma pack(push, 1)/**
 * @struct mp2m_param_set
 * This structure is used as parameter set for all available API functions.
 */
struct mp2m_param_set
{
  struct mp2muxer_set_struct params;
  struct mp2mux_ext_set_struct params_ext;
  uint32_t stream_count;
  struct mp2mux_stream_set_struct* stream_params;
  uint32_t program_count;
  struct mp2mux_ts_program_set_struct *program_params;

  uint8_t reserved[3992];//pointer size is always 8 bytes
};

#pragma pack(pop)

#endif // __MP2M_CONFIG_API_INCLUDED__
