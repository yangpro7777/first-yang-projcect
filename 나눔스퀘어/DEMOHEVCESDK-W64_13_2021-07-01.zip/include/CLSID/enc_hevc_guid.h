/********************************************************************
 Created: 2014/12/09 
 File name: enc_hevc_guid_demo.h
 Purpose: GUIDs for HEVC Encoder DS Filter

 Copyright (c) 2014 MainConcept GmbH. All rights reserved.

 This software is the confidential and proprietary information of
 MainConcept GmbH and may be used only in accordance with the terms of
 your license from MainConcept GmbH.

*********************************************************************/

#ifndef _ENC_HEVC_GUID_DEMO_H_
#define _ENC_HEVC_GUID_DEMO_H_

// {B2F3E9FB-522A-48ed-B891-2A16979C6771}
static const GUID CLSID_HEVCVideoEncoder = 
{ 0xb2f3e9fb, 0x522a, 0x48ed, { 0xb8, 0x91, 0x2a, 0x16, 0x97, 0x9c, 0x67, 0x71 } };

// {470580AF-C5F8-42f5-89D0-3D7CA25588A7}
static const GUID CLSID_HEVCVideoEncMainPropertyPage = 
{ 0x470580af, 0xc5f8, 0x42f5, { 0x89, 0xd0, 0x3d, 0x7c, 0xa2, 0x55, 0x88, 0xa7 } };

// {8716317A-958E-4820-A3D9-01398A6B2561}
static const GUID CLSID_HEVCVideoEncAdvancedPropertyPage = 
{ 0x8716317a, 0x958e, 0x4820, { 0xa3, 0xd9, 0x1, 0x39, 0x8a, 0x6b, 0x25, 0x61 } };

// {CB188CCB-C64D-49ca-820A-834F9B7643CF}
static const GUID CLSID_HEVCVideoEncAboutPropertyPage = 
{ 0xcb188ccb, 0xc64d, 0x49ca, { 0x82, 0xa, 0x83, 0x4f, 0x9b, 0x76, 0x43, 0xcf } };

#endif
