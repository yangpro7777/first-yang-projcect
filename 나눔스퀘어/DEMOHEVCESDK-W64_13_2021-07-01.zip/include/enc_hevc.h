/**
@file: enc_hevc.h
@brief HEVC/H.265 Encoder API

@verbatim
File: enc_hevc.h
Desc: HEVC/H.265 Encoder API

Copyright (c) 2019 MainConcept GmbH or its affiliates.  All rights reserved.

MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.  
This software is protected by copyright law and international treaties. Unauthorized 
reproduction or distribution of any portion is prohibited by law.
@endverbatim
 **/


#if !defined (__ENC_HEVC_API_INCLUDED__)
#define __ENC_HEVC_API_INCLUDED__

#include <mcdefs.h>
#include <mcprofile.h>
#include <mcapiext.h>
#include <mccolorimetry.h>

#include "common_video.h"
#include <bufstrm.h>

#include "enc_hevc_def.h"
#include <v_frame.h>

typedef struct hevc_v_encoder                       hevc_venc_tt;                     /**<@brief Encoder instance */
typedef struct hevc_v_settings                      hevc_v_settings_tt;
typedef struct hevc_v_layer                         hevc_v_layer_set_tt;
typedef struct hevc_chapter_position                hevc_chapter_tt;
typedef struct hevc_qp_map                          hevc_qp_map_tt;
typedef struct hevc_frame_data                      hevc_frame_data_tt;
typedef struct hevc_user_buffer                     hevc_user_buffer_tt;
typedef struct enc_acceleration_info                hevc_acceleration_info, hevc_acceleration_info_tt;


/**
* @brief HEVC typedef of globals
* @{
*/
typedef display_metadata_t                          hevc_mastering_display_metadata_tt;
typedef content_light_level_t                       hevc_content_light_level_tt;
typedef colorimetry_t                               hevc_colorimetry_tt;
typedef enc_user_data_tt                            hevc_user_data_tt;
/**
* @}
*/


#pragma pack(push,1)

//////////////////////////////////////////////////////////////////////////
//
// Stream setting struct
//
//////////////////////////////////////////////////////////////////////////
//

/**
  * @brief SEI time code parameters.
  * These parameters are used to configure the SEI time code message.
 **/
struct hevc_sei_time_code {
    uint8_t write_time_code;
    uint8_t counting_type;
    uint8_t full_timestamp_flag;
    uint8_t reserved;
};

//////////////////////////////////////////////////////////////////////////
//
// control functions
//
//////////////////////////////////////////////////////////////////////////
//

/**
  * @brief Layer parameters.
  * These parameters are used to configure the single encoding layer.
 **/
struct hevc_v_layer
{
    hevc_preset_t       preset;                         /**<@brief Predefined set of layer settings*/
    int32_t             level;                          /**<@brief Level ID */
    int32_t             high_tier;                      /**<@brief High tier */
    int32_t             width;                          /**<@brief Encoded pictures width */
    int32_t             height;                         /**<@brief Encoded pictures height */
    int32_t             wavefront_processing;           /**<@brief Wavefront Parallel Processing (WPP) */
    
    int32_t             slice_mode;                     /**<@brief Slicing mode: specify how picture is partitioned into slices */
    int32_t             slice_data;                     /**<@brief Slice dimension: `slice_mode` specifies the units */
    int32_t             reserved_0[3];                  /**<@brief Reserved for slices */

    int32_t             hw_acc_indices[HEVC_MAX_HW_DEVICES]; /**<@brief Devices indidices for hardware acceleration */
    int32_t             hw_acc_slice_overlapping;       /**<@brief The height in CTUs of the minimal overlapping area between devices */
    int32_t             reserved_1[114];                /**<@brief Reserved */

 /**
 * @name CTU settings
 * @{
 **/
    int32_t             log2_min_cu_size;               /**<@brief Minimum size of a coding block of luma samples */
    int32_t             log2_max_cu_size;               /**<@brief Maximum size of a coding block of luma samples*/
    int32_t             log2_min_tu_size;               /**<@brief Minimum size of a transfrom block of luma samples*/
    int32_t             log2_max_tu_size;               /**<@brief Maximum size of a transfrom block of luma samples*/
    int32_t             max_tu_depth_inter;             /**<@brief Maximum hierarchy depth for transform units of coding units coded in inter prediction mode*/
    int32_t             max_tu_depth_intra;             /**<@brief Maximum hierarchy depth for transform units of coding units coded in intra prediction mode*/
    int32_t             reserved_2[8];                  /**<@brief Reserved */
/** @} */

 /**
 * @name Intra prediction settings
 * @{
 **/
    int32_t             intra_partitioning;             /**<@brief Intra partitioning */
    int32_t             chroma_mode_search;             /**<@brief Chroma intra-mode search*/
    int32_t             strong_intra_smoothing;         /**<@brief Strong intra smoothing*/
    int32_t             intra_at_nonref_pics;           /**<@brief Intra processing at non-referenced pictures*/
    int32_t             reserved_3[7];                  /**<@brief Reserved */
/** @} */

 /**
 * @name Motion search settings
 * @{
 **/
    int32_t             motion_search_range;            /**<@brief Search range in quarter pixel units*/
    int32_t             motion_search_precision;        /**<@brief Sub-pel motion search accuracy*/
    int32_t             out_of_pic_mvs;                 /**<@brief Out of picture motion vectors*/
    int32_t             max_num_merge_cand;             /**<@brief Maximum number of merge candidates*/
    int32_t             inter_partitioning;             /**<@brief Inter partitioning*/
    int32_t             temporal_mv_prediction;         /**<@brief Temporal motion vector prediction*/
    int32_t             chroma_evaluation;              /**<@brief Chroma evaluation for merge and MVP candidates*/
    int32_t             motion_search_pattern;          /**<@brief Motion search pattern */
    int32_t             reserved_4[8];                  /**<@brief Reserved */
/** @} */

 /**
 * @name Deblock and SAO filters settings
 * @{
 **/
    int32_t             deblocking_filter;              /**<@brief Deblocking filter*/
    int32_t             beta_offset;                    /**<@brief Deblocking filter beta offset*/
    int32_t             tc_offset;                      /**<@brief Deblocking filter tc offset*/
    int32_t             sao_filter_luma;                /**<@brief SAO filter for luma samples*/
    int32_t             sao_filter_chroma;              /**<@brief SAO filter for chroma samples*/
    int32_t             adaptive_deblocking;            /**<@brief Adaptive offsets for a hierarchical pics encoding */
    int32_t             sao_on_ref_b_pics;              /**<@brief Allows SAO filter on referenced B-pictures*/
    int32_t             reserved_5[8];                  /**<@brief Reserved */
/** @} */

/**
* @name Rate control settings
* @{
**/
    int32_t             bit_rate_mode;                  /**<@brief Rate control mode*/
    int32_t             qp_i;                           /**<@brief QP for I pictures (@ref HEVC_CQT mode only)*/
    int32_t             qp_p;                           /**<@brief QP for P pictures (@ref HEVC_CQT mode only)*/
    int32_t             qp_b;                           /**<@brief QP for B pictures (@ref HEVC_CQT mode only)*/
    int32_t             min_qp;                         /**<@brief Minimum QP*/
    int32_t             max_qp;                         /**<@brief Maximum QP*/
    int64_t             bit_rate;                       /**<@brief Average bitrate, bits/sec*/
    int64_t             hss_rate;                       /**<@brief Maximum bitrate, bits/sec*/
    int64_t             cpb_size;                       /**<@brief CPB size, bits*/
    int64_t             cpb_fullness;                   /**<@brief Initial CPB fullness*/
    int64_t             cpb_fullness_trg;               /**<@brief Target CPB fullness*/
    int32_t             hrd_conformance;                /**<@brief HRD conformance*/
    int32_t             cpb_fullness_units;             /**<@brief CPB fullness units*/
    int32_t             bit_rate_scale;                 /**<@brief Scale factor for bit_rate, hss_rate*/
    int32_t             cpb_size_scale;                 /**<@brief Scale factor for cpb_size*/
    int32_t             qp_step;                        /**<@brief Max qp distance between two key pictures */
    int32_t             qp_scheme;                      /**<@brief QPs distribution model */
    int32_t             delta_qp_range;                 /**<@brief Range of QP difference between I and P, P and B pictures*/
    double              rate_factor;                    /**<@brief Constant rate factor used in @ref HEVC_CRF mode*/
    int32_t             reserved_6[236];                /**<@brief Reserved */

    int32_t             multi_pass;                     /**<@brief Multi pass mode */
    int32_t             reserved_7[782];
/** @} */

 /**
 * @name Transform settings
 * @{
 **/
    int32_t             sign_data_hiding;               /**<@brief Sign hide quantization*/
    int32_t             transform_skip;                 /**<@brief Transform skip*/
    int32_t             cb_qp_offset;                   /**<@brief Chroma Cb qp offset*/
    int32_t             cr_qp_offset;                   /**<@brief Chroma Cr qp offset*/
    int32_t             rdo_quantization;               /**<@brief RDO quantization*/
    int32_t             qp_delta_depth;                 /**<@brief QP delta depth*/
    int32_t             reserved_8[18];                 /**<@brief Reserved */

    int32_t             reserved_9[1024];               /**<@brief Reserved */ // scaling lists
/** @} */

 /**
 * @name RDO settings
 * @{
 **/
    int32_t             intra_skip_dist;                /**<@brief Fast intra decision*/
    int32_t             fast_cu_split_decision;         /**<@brief Fast CU split decision*/
    int32_t             fast_me_skip_decision;          /**<@brief Fast ME skip decision*/
    int32_t             fast_inter_nnz_decision;        /**<@brief Fast Inter NNZ decision*/
    int32_t             pu_pred_pattern_mode;           /**<@brief Fast CU split decision for inter frames*/
    int32_t             fast_type_decision;             /**<@brief Fast type decision*/
    int32_t             intra_cand_filtering;           /**<@brief Fast intra decision*/
    int32_t             num_inter_part_cands;           /**<@brief Fast inter partitioning decision*/
    int32_t             fast_inter_partitioning;        /**<@brief Fast inter partitioning decision*/
    int32_t             ssd_for_intra_cu;               /**<@brief SSD instead of HAD for intra decision*/
    int32_t             one_cand_for_intra_trans;       /**<@brief RDO candidates number for intra decision*/
    int32_t             unref_pic_weak_rdo;             /**<@brief Week RDO for unreferenced pictures*/
    int32_t             fast_bit_counting;              /**<@brief Fast bits approximation*/
    int32_t             fast_intra_mode;                /**<@brief Fast intra mode selection*/
    int32_t             intra_pattern_mode;             /**<@brief Fast CU split decision for intra frames*/
    int32_t             reserved_10[14];                /**<@brief Reserved */
/** @} */

 /**
 * @name VUI settings
 * @{
 **/
    int32_t             sar_idc;                        /**<@brief Sample aspect ratio*/
    int32_t             par_width;                      /**<@brief Reserved */
    int32_t             par_height;                     /**<@brief Reserved */
    int32_t             sar_width;                      /**<@brief The horizontal size of the sample aspect ratio*/
    int32_t             sar_height;                     /**<@brief The vertical size of the sample aspect ratio*/

    int32_t             reserved_11[20];                 /**<@brief Reserved */
/** @} */

 /**
 * @name File/stream settings
 * @{
 **/
    int32_t             annexb;                         /**<@brief Annex B*/
    int32_t             stream_type;                    /**<@brief Output stream type*/
    int32_t             au_delimiter;                   /**<@brief Access Unit Delimeters (AUD)*/
    int32_t             seq_end_code;                   /**<@brief End Of Sequence code (EOS)*/
    int32_t             single_sei_per_nalu;            /**<@brief Single SEI per NALU*/
    int32_t             reserved_12_[1];                /**<@brief Reserved */
    int32_t             timing_info;                    /**<@brief VUI timing info*/
    hevc_sei_time_code  sei_time_code;                  /**<@brief SEI time code message*/
    int32_t             reserved_13[39];                /**<@brief Reserved */
/** @} */
};

/**
 * @brief General parameters.
 * These parameters are used to configure the encoder.
 **/
struct hevc_v_settings
{
    hevc_profile_t      profile;                        /**<@brief Profile ID */
    int32_t             chroma_format;                  /**<@brief Chroma format of encoded picture*/
    int32_t             max_layers;                     /**<@brief Number of different coding layers*/
    int32_t             temporal_sub_layers;            /**<@brief Number of temporal sub-layers*/
    int32_t             max_dec_pic_buffering;          /**<@brief Maximum number of pictures in decoded picture buffer*/
    int32_t             max_src_pic_buffering;          /**<@brief Maximum number of pictures in source picture buffer*/
    int32_t             min_src_pic_buffering;          /**<@brief Minimum number of pictures in source picture buffer*/
    int32_t             bit_depth_luma;                 /**<@brief Bit depth of encoded luminance samples*/
    int32_t             bit_depth_chroma;               /**<@brief Bit depth of encoded chrominance samples*/
    int32_t             time_scale;                     /**<@brief Timing info use together with @ref num_units_in_tick (frame rate in fps = time_scale/num_units_in_tick) */
    int32_t             num_units_in_tick;              /**<@brief Timing info use together with @ref time_scale */
    int32_t             log2_max_poc_lsb;               /**<@brief Allows to specify custom log2_max_pic_order_cnt_lsb_minus4 value*/
    int32_t             persistent_parsets;             /**<@brief Persistent SPS and PPS*/
    int32_t             reserved[4];                    /**<@brief Reserved */

/**
* @name SABET specific
* @{
**/
    int32_t             snr_infer_split;                /**<@brief Accelerates SABET encoding*/
    int32_t             reserved_sabet[10];             /**<@brief Reserved */
/** @} */

/**
* @name Video signal description
* @{
**/
    int32_t                     video_signal_type_present;          /**<@brief Allows to write video signal description*/
    hevc_colorimetry_tt         input_colorimetry;                  /**<@brief Input picture colorimetry*/
    hevc_colorimetry_tt         output_colorimetry;                 /**<@brief Output picture colorimetry*/
    int32_t                     video_format;                       /**<@brief Representation of the picture: PAL, NTSC, SECAM, etc. */
    transfer_characteristics_t  fallback_transfer_characteristics;  /**<@brief Fallback alternative value for transfer characteristics */
    int32_t                     reserved_sig[4];                    /**<@brief Reserved */
/** @} */

/**
* @name Picture preprocessing options
* @{
**/
    int32_t             deinterlace;                    /**<@brief Input pictures de-interlacing */
    int32_t             input_filtering;                /**<@brief Input pictures filtering*/
    int32_t             reserved_pp[4];                 /**<@brief Reserved */
/** @} */

/**
* @name Picture pre-analysis options
* @{
**/
    int32_t             aq_mode;                        /**<@brief Adaptive quantization mode*/
    int32_t             weighted_refs;                  /**<@brief Weighted pictures processing*/
    int32_t             reserved_pa[8];                 /**<@brief Reserved */
/** @} */

/**
* @name Picture pre-analysis performance options
* @{
**/
    int32_t             inq_zero_mv_skip;               /**<@brief Skip zero motion vector analysis in input queue */
    int32_t             inq_skip_me_layers;             /**<@brief Motion estimation performance for input queue */
    int32_t             inq_b_intra;                    /**<@brief Full intra preanalysis for B-frames*/
    int32_t             inq_multi_ref;                  /**<@brief Multi-reference motion estimation in input queue */
    int32_t             reserved_ap[5];                 /**<@brief Reserved */
/** @} */

/**
* @name GOP options
* @{
**/
    int32_t             max_intra_period;               /**<@brief Maximum GOP length */
    int32_t             min_intra_period;               /**<@brief Minimum GOP length */
    int32_t             irap_period;                    /**<@brief IRAP period in GOP units*/
    int32_t             irap_period_type;               /**<@brief IRAP period type: IDR, CRA*/
    int32_t             fixed_intra_position;           /**<@brief Fixed position of I pictures*/
    int32_t             vscd_mode;                      /**<@brief Scene Change Detection*/
    int32_t             adaptive_num_b_pics;            /**<@brief Adaptive number of B pictures*/
    int32_t             max_num_b_pics;                 /**<@brief Maximum number of B pictures*/
    int32_t             pyramid_b_pics;                 /**<@brief Pyramid GOP structure*/

    int32_t             max_num_ref_pics_p;             /**<@brief Maximum number of reference pictures used on P-pictures from list0*/
    int32_t             max_num_ref_pics_b_l0;          /**<@brief Maximum number of reference pictures used on B-pictures from list0*/
    int32_t             max_num_ref_pics_b_l1;          /**<@brief Maximum number of reference pictures used on B-pictures from list1*/
    int32_t             wide_ref_pics_b;                /**<@brief Extended reference picture set for referenced B-pictures*/
    int32_t             scene_change_type;              /**<@brief Scene change picture type: TRAIL_R, IDR, CRA*/
    int32_t             intra_period_type;              /**<@brief Intra period picture type: TRAIL_R, IDR, CRA*/

    int32_t             reserved_gop[14];               /**<@brief Reserved */
/** @} */

/**
* @name Statistics options
* @{
**/
    // 
    int32_t             statistics_level;               /**<@brief Calculating of detailed mode encoding statistic and bits distribution */
    int32_t             pic_hash;                       /**<@brief Calculating MD5 */
    int32_t             quality_metric;                 /**<@brief Calculating quality metric*/
    int32_t             reserved_stat[2];               /**<@brief Reserved */
/** @} */

/**
* @name Performance options
* @{
**/
    int32_t             cpu_opt;                        /**<@brief CPU optimization */
    int32_t             num_threads;                    /**<@brief Number of threads */
    int32_t             num_parallel_pics;              /**<@brief Number of parallel coding pictures */
    int32_t             max_num_reencodings;            /**<@brief Maximum number of picture re-encodings */
    int32_t             min_encoding_fps;               /**<@brief Minimum encoding frames per second */
    int32_t             performance_level;              /**<@brief Performance level [Read-only]*/
    int32_t             max_auto_perf_level;            /**<@brief Maximal performance level allowed */
    int32_t             reserved_perf[10];               /**<@brief Reserved */

    int32_t             hw_acceleration;                /**<@brief Hardware acceleration */
    int32_t             hw_acc_mode;                    /**<@brief Hardware acceleration mode*/
    int32_t             reserved_hw[6];                 /**<@brief Reserved */

    int32_t             inq_numa_node_idx;              /**<@brief Numa node id */
    int32_t             inq_acceleration;               /**<@brief Hardware accelerated input queue*/
    int32_t             inq_acc_idx;                    /**<@brief Device index for hardware accelerated input queue*/
    int32_t             reserved_inq[7];               /**<@brief Reserved */
/** @} */

/**
* @name Layers settings
* @{
**/
    hevc_v_layer        layers[HEVC_MAX_LAYERS];        /**<@brief Array of different layers settings*/
/** @} */
};


/**
 * @brief A chapter position description.
 * Describes a new chapter position starting from specified frame number and specifies additional flags for them.
 */
struct hevc_chapter_position
{
    int32_t frame_nr;           /**<@brief  Chapter frame number */
    int32_t flags;              /**<@brief  Possible flags: @ref HEVC_CHAPTER_FORCE_IDR, @ref HEVC_CHAPTER_END_OF_LIST */
};

/**
* @brief External QPs for the adaptive quantization.
* Structure is passed via hevc_user_data_tt
*/
struct hevc_qp_map
{
    int32_t    format;          /**<@brief  QP map format, must be @ref HEVC_QP_MAP_FORMAT_8X8_INT8_DELTA */
    int32_t    size;            /**<@brief  QP map buffer size, in bytes*/
    void *     data;            /**<@brief  A pointer to QP map buffer*/
    int32_t    reserved[16];    /**<@brief  Reserved */
};

/**
* @brief Specifies data for certain frame.
*/
struct hevc_frame_data
{
    int32_t    cpb_removal_delay;   /**<@brief  CPB removal delay */
    int32_t    reserved[15];        /**<@brief  Reserved */
};

/**
* @brief An external buffer fullness description.
* Supposed to inform the encoder about capture buffer fullness to prevent the buffer overflow and frames drop.
* The structure can be attached as ext option of @ref hevcOutVideoPutFrame or @ref hevcOutVideoPutFrame.
*/
struct hevc_user_buffer
{
    int32_t    fullness;            /**<@brief  Current buffer fullness */
    int32_t    max_buffer;          /**<@brief  Maximal buffer fullness */
    int32_t    reserved[14];        /**<@brief  Reserved */
};

#pragma pack(pop)



#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief Fills a @ref hevc_v_settings structure with defaults values
* @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
* @param[out] set          - a pointer to the hevc_v_settings structure to be filled
* @param[in] video_type    - an encoder preset. For more information see @ref hevc_v_layer::preset
* @param[in] hw_acceleration - hardware acceleration option. For more information see @ref hevc_v_settings::hw_acceleration
* @return a pointer to string containing symbol name of the video type if no error and NULL otherwise
*/
char * MC_EXPORT_API hevcOutVideoDefaults(const callbacks_t * callbacks, struct hevc_v_settings* set, int32_t video_type, int32_t hw_acceleration);

/**
 * @brief Adjusts a performance-related part of a hevc_v_settings structure
 * @param[in] callbacks - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in,out] set   - a pointer to the @ref hevc_v_settings structure to be adjusted
 * @param[in] mode      - reserved, must be 0
 * @param[in] level     - a performance level, must be in range [0, 31]
 * @param[in] reserved  - reserved, must be 0
 */
void MC_EXPORT_API hevcOutVideoPerformance(const callbacks_t *      callbacks,
                                           struct hevc_v_settings * set,
                                           int32_t                  mode,
                                           int32_t                  level,
                                           int32_t                  reserved);


/**
 * @brief Creates a new HEVC Video Encoder instance
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in] set           - a pointer to the @ref hevc_v_settings structure that defines characteristics for the new instance
 * @param[in] options       - reserved, must be 0
 * @param[in] CPU           - reserved, must be 0xfffffff
 * @param[in] frame0        - reserved, must be 0
 * @param[in] nframes       - reserved, must be 0
 * @return a pointer to the encoder instance or NULL in case of memory allocation failure

 */
hevc_venc_tt * MC_EXPORT_API hevcOutVideoNew(const callbacks_t *            callbacks,
                                            const struct hevc_v_settings *  set,
                                            int32_t                         options,
                                            int32_t                         CPU,
                                            int32_t                         frame0,
                                            int32_t                         nframes);

/**
 * @brief Destroys a HEVC Video Encoder instance created by @ref hevcOutVideoNew
 * @param[in] instance  - a pointer to the encoder instance
 */
void MC_EXPORT_API hevcOutVideoFree(hevc_venc_tt * instance);


/**
 * @brief Initializes an encoder instance
 * @param[in] instance  - a pointer to the encoder instance created by @ref hevcOutVideoNew
 * @param[in] videobs   - a pointer to a @ref BUFSTRM_PAGE "bufstream object"
 * @param[in] options   - an options array ended with {EXT_OPT_PARAM_NULL, NULL} or a NULL pointer
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoInit(hevc_venc_tt *     instance,
                                       struct bufstream * videobs,
                                       const enc_option_t *options);


/**
 * @brief Flushes and destroys an encoding session
 * @param[in] instance  - a pointer to the encoder instance created by @ref hevcOutVideoNew
 * @param[in] abort - reserved, must be 0
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoDone(hevc_venc_tt * instance, int32_t abort);



/**
 * @brief Puts a picture into encoding queue
 * @param[in] instance  - a pointer to the encoder instance created by @ref hevcOutVideoNew
 * @param[in] pb_src    - a pointer to the picture buffer to be encoded
 * @param[in] src_line_size - stride of the picture
 * @param[in] src_width - width of the picture
 * @param[in] src_height - height of the picture
 * @param[in] fourcc    - color space of the picture
 * @param[in] options   - an options array ended with {EXT_OPT_PARAM_NULL, NULL} or a NULL pointer
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoPutFrame(hevc_venc_tt *  instance,
                                           uint8_t *       pb_src,
                                           int32_t         src_line_size,
                                           int32_t         src_width,
                                           int32_t         src_height,
                                           uint32_t        fourcc,
                                           const enc_option_t * options);

/**
 * @brief Puts a picture into encoding queue
 * @param[in] instance  - a pointer to the encoder instance created by @ref hevcOutVideoNew
 * @param[in] pframe_v  - a pointer to the picture buffer to be encoded
 * @param[in] options   - an options array ended with {EXT_OPT_PARAM_NULL, NULL} or a NULL pointer
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoPutFrameV(hevc_venc_tt *    instance,
                                            video_frame_tt * pframe_v,
                                            const enc_option_t * options);

/**
 * @brief Not implemented
 * @return @ref HEVC_ERROR_NOT_IMPLEMENTED
 */
int32_t MC_EXPORT_API hevcOutVideoUpdateSettings(hevc_venc_tt *                 instance,
                                                 const struct hevc_v_settings * set);

/**
 * @brief Checks encoder settings for a conformance
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in,out] set       - a pointer to the @ref hevc_v_settings structure to be checked
 * @param[in] options       - check/adjustment options.
 * The hevcOutVideoChkSettings checks settings and adjusts them to match profile, level/tier and optionally specified preset.<br>
 * Available options are:
 * <ul>
 * <li>@ref HEVC_ADJUST_MAIN    - Minimal settings adjustment for HEVC profile, level and tier conformance (default)</li>
 * <li>@ref HEVC_ADJUST_PRESET  - Adjust settings for specified preset conformance</li>
 * </ul>
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoChkSettings(const callbacks_t *      callbacks,
                                              struct hevc_v_settings * set,
                                              uint32_t                 options);

/**
 * @brief Returns a parameter set to the buffer and its length
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in] set           - the encoder @ref hevc_v_settings "settings".
 * @param[out] buffer       - a pointer to the buffer, which will be used for writing of parameter sets, can not be NULL
 * @param[in,out] length    - a length of the buffer, initially should contain the max buffer length, when the function returns length will contain the actual number of bytes written into the buffer
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoGetParSets(const callbacks_t *      callbacks,
                                             struct hevc_v_settings * set,
                                             uint8_t *                buffer,
                                             int32_t *                length);

/**
 * @brief Loads a parameter set from memory buffer to encoder settings
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in,out] set       - the encoder @ref hevc_v_settings "settings"
 * @param[in] config        - a pointer to the buffer, which contains config
 * @param[in] size          - length of the buffer
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoSetSettings(const callbacks_t *       callbacks,
                                              struct hevc_v_settings *  set,
                                              const char *              config,
                                              size_t                    size);

/**
 * @brief Puts a parameter set from encoder settings to memory buffer
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in] set           - the encoder @ref hevc_v_settings "settings".
 * @param[out] config       - a pointer to the buffer, which will be used for writing config
 * @param[in,out] size      - length of the buffer. To know required buffer size call the function with input buffer set to NULL first. 
 * @return Zero if successful; an @ref HEVC_ERROR_NOT_ENOUGH_SPACE if buffer size is not enough for config writting; an @ref HEVC_ERROR_NONE "error code" on other failures
 */
int32_t MC_EXPORT_API hevcOutVideoGetSettings(const callbacks_t *               callbacks,
                                              const struct hevc_v_settings *    set,
                                              char *                            config,
                                              size_t *                          size);

/**
 * @brief Sets a general setting by name 
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in,out] set       - the encoder @ref hevc_v_settings "settings"
 * @param[in] arg           - setting name
 * @param[in] value         - setting value
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoSetSettingByName (const callbacks_t *         callbacks,
                                                    struct hevc_v_settings *    set,
                                                    const char *                arg,
                                                    const char *                value);

/**
 * @brief Sets a layer setting by name
 * @param[in] callbacks     - a pointer to an application-defined callback functions. If callbacks is NULL, default handlers are used. For more information, see @ref GET_CALLBACK_PAGE "callbacks"
 * @param[in,out] layer_set - the encoder @ref hevc_v_layer "layer settings"
 * @param[in] arg           - setting name
 * @param[in] value         - setting value
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 */
int32_t MC_EXPORT_API hevcOutVideoSetLayerSettingByName(const callbacks_t *         callbacks,
                                                        struct hevc_v_layer *       layer_set,
                                                        const char *                arg,
                                                        const char *                value);

/**
 * @brief Flushes an encoder queue
 * @param[in] instance  - a pointer to the encoder instance created by @ref hevcOutVideoNew
 * @param[in] abort     - reserver, must be 0
 * @return Zero if successful; an @ref HEVC_ERROR_NONE "error code" on failure
 **/
int32_t MC_EXPORT_API hevcOutVideoFlush(hevc_venc_tt * instance, int32_t abort);


/**
 * @brief Gets all recommended acceleration configurations for all devices in the system
 * @param[out] buffer   - an output array of @ref hevc_acceleration_info
 * @param[in] length    - length of the buffer, the buffer should be long enough to hold all configuration
 * @retval 0  - if invalid argument;
 * @retval >0 - real number of the buffer entries. To know required buffer length call the function with input buffer set to NULL and length set to 0 first. 
 **/
int32_t MC_EXPORT_API hevcOutVideoEnumAcceleration(hevc_acceleration_info* buffer, int32_t length);


/**
 * @brief returns extended API function
 * @param[in] func      - an identifier of extended API functions, only @ref MCAPI_GetModuleInfo is allowed
 * @return a pointer to one of the extended API functions corresponded to identifier
 **/
APIEXTFUNC  MC_EXPORT_API hevcOutVideoGetAPIExt(uint32_t func);

#ifdef __cplusplus
}
#endif

/** @} */

#endif // #if !defined (__ENC_HEVC_API_INCLUDED__)

