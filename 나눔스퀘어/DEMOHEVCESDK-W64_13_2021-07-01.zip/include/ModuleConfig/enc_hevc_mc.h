/**
@file: enc_hevc_mc.h
@brief IModuleConfig HEVC/H.265 Encoder parameter's identifiers

@verbatim
File: enc_hevc_mc.h
Desc: IModuleConfig HEVC/H.265 Encoder parameter's identifiers

Copyright (c) 2019 MainConcept GmbH or its affiliates.  All rights reserved.

MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
This software is protected by copyright law and international treaties.  Unauthorized
reproduction or distribution of any portion is prohibited by law.
@endverbatim
 **/


#if !defined(__PROPID_H265ENC_HEADER__)
#define __PROPID_H265ENC_HEADER__
/**@file 
* HEVC DS Header
*/

/**
* namespace H265VE
* @brief H265VE specific namespace
**/
namespace H265VE
{

/**
* @brief Describes encoder profile.
**/
    typedef enum Profile
    {
        Profile_Main        = HEVC_PROFILE_MAIN,                            /**<Main Profile*/
        Profile_Main10      = HEVC_PROFILE_MAIN_10,                         /**<Main 10 Profile*/
        Profile_Main422_10  = HEVC_PROFILE_MAIN_422_10,                     /**<Main 422 10 Profile*/
    } Profile_t;

/**
* @brief Describes encoder presets.
**/    
    typedef enum VideoType
    {
        VideoType_MAIN                  = HEVC_MAIN,                        /**<Corresponds to Main profile of ITU-T H.265*/
        VideoType_MAIN_10               = HEVC_MAIN_10,                     /**<Corresponds to Main 10 profile of ITU-T H.265*/
        VideoType_MAIN_422_10           = HEVC_MAIN_422_10,                 /**<Corresponds to Main 4:2:2 10 profile of ITU-T H.265*/
    } VideoType_t;

/**
* @brief Describes levels.
**/    
    typedef enum Level
    {
        Level_1     = HEVC_LEVEL_1,                                         /**<Level 1*/
        Level_2     = HEVC_LEVEL_2,                                         /**<Level 2*/
        Level_21    = HEVC_LEVEL_21,                                        /**<Level 2.1*/
        Level_3     = HEVC_LEVEL_3,                                         /**<Level 3*/
        Level_31    = HEVC_LEVEL_31,                                        /**<Level 3.1*/
        Level_4     = HEVC_LEVEL_4,                                         /**<Level 4*/
        Level_41    = HEVC_LEVEL_41,                                        /**<Level 4.1*/
        Level_5     = HEVC_LEVEL_5,                                         /**<Level 5*/
        Level_51    = HEVC_LEVEL_51,                                        /**<Level 5.1*/
        Level_52    = HEVC_LEVEL_52,                                        /**<Level 5.2*/
        Level_6     = HEVC_LEVEL_6,                                         /**<Level 6*/
        Level_61    = HEVC_LEVEL_61,                                        /**<Level 6.1*/
        Level_62    = HEVC_LEVEL_62,                                        /**<Level 6.2*/
        Level_Auto  = HEVC_LEVEL_AUTO                                       /**<Automatic selection of suitable level*/
    } Level_t;

/**
* @brief Describes tiers.
**/    
    typedef enum Tier
    {
        MainTier    = 0,
        HighTier    = 1
    } Tier_t;

/**
* @brief Describes color sampling.
**/
    typedef enum ColourSampling
    {
        Chroma_400  = HEVC_CHROMA_400,   /**<Chroma Format 4:0:0*/
        Chroma_420  = HEVC_CHROMA_420,   /**<Chroma Format 4:2:0*/
        Chroma_422  = HEVC_CHROMA_422,   /**<Chroma Format 4:2:2*/
        Chroma_444  = HEVC_CHROMA_444,   /**<Chroma Format 4:4:4*/
    } ColourSampling_t;

/**
* @brief Describes bit rate mode.
**/
    typedef enum BitRateMode
    {
        BitRateMode_CBR = HEVC_CBR,         /**<Constant bit rate*/
        BitRateMode_CQT = HEVC_CQT,         /**<Constant quantizer*/
        BitRateMode_VBR = HEVC_VBR,         /**<Variable bit rate*/
        BitRateMode_AQP = HEVC_AQP,
        BitRateMode_CRF = HEVC_CRF,         /**<Constant rate factor*/
    } BitRateMode_t;

/**
* @brief Video Signal Type Present
*/
    typedef enum VideoSignalTypePresent
    {
        VideoSignalTypePresentAuto  = -1, /**<@brief Automatically decides whether video signal type is present or not@hideinitializer*/
        VideoSignalTypeNotPresent   =  0, /**<@brief Video signal type is not present @hideinitializer*/
        VideoSignalTypePresent      =  1, /**<@brief Video signal type is present @hideinitializer*/
    } VideoSignalTypePresent_t;


/**
* @brief Signal range flag
*/
    typedef enum SignalRangeFlag
    {
        RangeAuto         = PIC_SIGNAL_RANGE_AUTO,           /**<@brief Signal range auto*/
        RangeFull         = PIC_SIGNAL_RANGE_FULL,           /**<@brief Signal range full (0-255)*/
        RangeShort        = PIC_SIGNAL_RANGE_SHORT           /**<@brief Signal range short (16-235)*/
    } SignalRangeFlag_t;

/**
*   @brief Describes colour primaries
**/
    typedef enum ColourPrimaries
    {
        ColourPrimaries_ITU_R_BT_709        = 1, ///<@brief ITU-R Rec. BT.709-5
        ColourPrimaries_Unspecified         = 2, ///<@brief Unspecified
        ColourPrimaries_ITU_R_BT_470_M      = 4, ///<@brief ITU-R Rec. BT.470-6 System M
        ColourPrimaries_ITU_R_BT_601_625    = 5, ///<@brief ITU-R Rec. BT.601-6 625
        ColourPrimaries_ITU_R_BT_601_525    = 6, ///<@brief ITU-R Rec. BT.601-6 525
        ColourPrimaries_SMPTE_240M          = 7, ///<@brief SMPTE 240M
        ColourPrimaries_ITU_R_BT_2020       = 9  ///<@brief ITU-R Rec. BT.2020
    } ColourPrimaries_t;

/**
*   @brief Describes matrix coefficients
**/
    typedef enum MatrixCoefficients
    {
        MatrixCoefficients_ITU_R_BT_709     = 1, ///<@brief ITU-R Rec. BT.709-5
        MatrixCoefficients_Unspecified      = 2, ///<@brief Unspecified
        MatrixCoefficients_ITU_R_BT_601_625 = 5, ///<@brief ITU-R Rec. BT.601-6 625
        MatrixCoefficients_ITU_R_BT_601_525 = 6, ///<@brief ITU-R Rec. BT.601-6 525
        MatrixCoefficients_SMPTE_240M       = 7, ///<@brief SMPTE 240M
        MatrixCoefficients_BT2020_non_const = 9  ///<@brief ITU-R Rec. BT.2020 non-constant luminance
    } MatrixCoefficients_t;

/**
*   @brief Describes transfer characteristics
**/
    typedef enum TransferCharacteristics
    {
        TransferCharacteristics_ITU_R_BT_709                = 1,    ///<@brief ITU-R Rec. BT.709-5
        TransferCharacteristics_Unspecified                 = 2,    ///<@brief Unspecified
        TransferCharacteristics_ITU_R_BT_470_M              = 4,    ///<@brief ITU-R Rec. BT.470-6 System M
        TransferCharacteristics_ITU_R_BT_470_B_G            = 5,    ///<@brief ITU-R Rec. BT.470-6 System B, G
        TransferCharacteristics_ITU_R_BT_601_525            = 6,    ///<@brief ITU-R Rec. BT.601-6 525 or 625
        TransferCharacteristics_SMPTE_240M                  = 7,    ///<@brief SMPTE 240M
        TransferCharacteristics_ITU_R_BT_2020_10bit         = 14,   ///<@brief ITU-R Rec. BT.2020 for 10 bit system
        TransferCharacteristics_ST_SMPTE_2084_BT_2100_PQ    = 16,   ///<@brief SMPTE ST 2084 for 10, 12, 14 and 16-bit systems, and ITU-R Rec. BT.2100 PQ for 10 bit system
        TransferCharacteristics_ITU_R_BT_2100_HLG_10bit     = 18    ///<@brief ITU-R Rec. BT.2100 HLG for 10 bit system
    } TransferCharacteristics_t;

/**
* @brief Describes CPU optimization mode.
**/
    typedef enum CpuOptimization
    {
        CPU_Auto    = HEVC_CPU_OPT_AUTO,           /**<@brief Auto*/
        CPU_PlainC  = HEVC_CPU_OPT_PLAIN_C,        /**<@brief Plain-C*/
        CPU_SSE4    = HEVC_CPU_OPT_SSE4,           /**<@brief SSE4*/
        CPU_AVX2    = HEVC_CPU_OPT_AVX2            /**<@brief AVX2*/
    } CpuOptimization_t;

/**
* @brief Enable/disable video scene change detection.
**/
    typedef enum VSCDMode
    {
        VSCDMode_OFF    = 0,    /**<@brief Scene change detection OFF */
        VSCDMode_IDR    = 1	    /**<@brief Scene change detection ON*/
    } VSCDMode_t;

/**
* @brief Pyramid B picture structure
**/
    typedef enum PyramidB
    {
        PyramidB_OFF        = HEVC_PYRAMID_B_OFF,       /**<@brief  No reference dependence for consecutive B pictures */
        PyramidB_ON         = HEVC_PYRAMID_B_ON        /**<@brief  Fixed pyramid structure of reference dependence for consecutive B pictures */
    } PyramidB_t;

/**
* @brief Describes TU/CU size.
**/
    typedef enum UnitSize {
        Unit_4x4 = 2,       /**<@brief 4x4 OFF */
        Unit_8x8,           /**<@brief 8x8 OFF */
        Unit_16x16,         /**<@brief 16x16 OFF */
        Unit_32x32,         /**<@brief 32x32 OFF */
        Unit_64x64,         /**<@brief 64x64 OFF */
    } UnitSize_t;

/**
* @brief Describes motion search precision.
**/
    typedef enum MotionSearchPrecision
    {
        Precision_Full            = HEVC_SEARCH_PRECISION_FULL_PEL,             /**<@brief Full pixel */
        Precision_Half_P          = HEVC_SEARCH_PRECISION_HALF_P,               /**<@brief Half pixel on P frames */
        Precision_Half_PB         = HEVC_SEARCH_PRECISION_HALF_PB,              /**<@brief Half pixel on P and B frames */
        Precision_Quart_P_half_B  = HEVC_SEARCH_PRECISION_QUARTER_P_HALF_B,     /**<@brief Quarter pixel on P frames and half pixel on B */
        Precision_Quart_P_half_Bb = HEVC_SEARCH_PRECISION_QUARTER_P_HALF_Bb,    /**<@brief Quarter pixel on P frames and half pixel on B and b */
        Precision_Quart_PB_half_b = HEVC_SEARCH_PRECISION_QUARTER_PB_HALF_b,    /**<@brief Quarter pixel on P and B frames and half pixel on b */
        Precision_Quart_PBb       = HEVC_SEARCH_PRECISION_QUARTER_PBb           /**<@brief Quarter pixel */
    } MotionSearchPrecision_t;

/**
* @brief Describes inter partitioning modes.
**/
    typedef enum InterPartMode
    {
        InterPart_off           = HEVC_INTER_PARTITIONING_OFF,                  /**<@brief Off */
        InterPart_symmetric     = HEVC_INTER_PARTITIONING_SYMMETRIC,            /**<@brief Symmetric */
        InterPart_asymmetric    = HEVC_INTER_PARTITIONING_ASYMMETRIC            /**<@brief Asymmetric */
    } InterPartMode_t;

/**
* @brief Describes adaptive quantization modes.
**/
    typedef enum AQMode {
        AQMode_off      = HEVC_AQ_MODE_OFF,             /**<@brief Disable AQ */
        AQMode_external = HEVC_AQ_MODE_EXTERNAL,        /**<@brief AQ according to an external map */
        AQMode_temporal = HEVC_AQ_MODE_TEMPORAL,        /**<@brief Temporal AQ */
        AQMode_rdo      = HEVC_AQ_MODE_RDO              /**<@brief RDO-driven AQ */
    } AQmode_t;

/**
* @brief Describes hardware acceleration types.
**/
    typedef enum HWAccel {
        HWAccel_off          = HEVC_HW_ACCELERATION_NONE,           /**<@brief Acceleration mode off*/
        HWAccel_iqsv         = HEVC_HW_ACCELERATION_IQSV,           /**<@brief IQSV acceleration*/
        HWAccel_nvenc        = HEVC_HW_ACCELERATION_NVENC,          /**<@brief NVENC acceleration */
    } HWAccel_t;

/**
* @brief Describes hardware acceleration modes.
**/
    typedef enum HWAccelMode {
        HWAccelMode_full         = HEVC_HW_ACCELERATION_MODE_FULL,        /**<@brief Full hardware acceleration*/
        HWAccelMode_driven       = HEVC_HW_ACCELERATION_MODE_DRIVEN,      /**<@brief Driven acceleration*/
        HWAccelMode_hybrid       = HEVC_HW_ACCELERATION_MODE_HYBRID,      /**<@brief Hybrid acceleration*/
    } HWAccelMode_t;

/**
* @brief Describes sample aspect ratio.
**/
typedef enum SampleAspectRatio
{
    SAR_Unspecified = 0,     /**<@brief Unspecified*/
    SAR_1_1         = 1,     /**<@brief 1:1*/
    SAR_12_11       = 2,     /**<@brief 12:11*/
    SAR_10_11       = 3,     /**<@brief 10:11*/
    SAR_16_11       = 4,     /**<@brief 16:11*/
    SAR_40_33       = 5,     /**<@brief 40:33*/
    SAR_24_11       = 6,     /**<@brief 24:11*/
    SAR_20_11       = 7,     /**<@brief 20:11*/
    SAR_32_11       = 8,     /**<@brief 32:11*/
    SAR_80_33       = 9,     /**<@brief 80:33*/
    SAR_18_11       = 10,    /**<@brief 18:11*/
    SAR_15_11       = 11,    /**<@brief 15:11*/
    SAR_64_33       = 12,    /**<@brief 64:33*/
    SAR_160_99      = 13,    /**<@brief 160:99*/
    SAR_4_3         = 14,    /**<@brief 4:3*/
    SAR_3_2         = 15,    /**<@brief 3:2*/
    SAR_2_1         = 16,    /**<@brief 2:1*/
    SAR_Extended    = 255,   /**<@brief Extended*/
    SAR_Auto        = 300    /**<@brief Auto*/
} SampleAspectRatio_t;

/**
* @brief RDO quantization modes.
**/
typedef enum RDOQmode
{
    RDOQ_off        = HEVC_RDOQ_OFF,        /**<@brief Off*/
    RDOQ_dct_only   = HEVC_RDOQ_DCT,        /**<@brief DCT only*/
    RDOQ_dct_and_ts = HEVC_RDOQ_DCT_TS      /**<@brief DCT and TS*/
} RDOQmode_t;

/**
* @brief Describes stream types.
**/
typedef enum StreamTypes
{
    StreamTypeI          = HEVC_STREAM_TYPE_I,         /**<@brief VCL NALUs + filler data */
    StreamTypeIplusSEI   = HEVC_STREAM_TYPE_I_SEI,     /**<@brief VCL NALUs + filler data + SEI messages */
    StreamTypeII         = HEVC_STREAM_TYPE_II,        /**<@brief all NALU types */
    StreamTypeIIminusSEI = HEVC_STREAM_TYPE_II_NO_SEI  /**<@brief all NALU types except SEI */
} StreamTypes_t;

/**
* @brief Input filtering types.
**/
typedef enum InputFilter
{
    Filter_off    = HEVC_INPUT_FILTER_OFF,      /**<@brief Disable*/
    Filter_median = HEVC_INPUT_FILTER_MEDIAN,   /**<@brief Apply median filter*/
    Filter_mean   = HEVC_INPUT_FILTER_MEAN      /**<@brief Apply mean filter*/
} InputFilter_t;

/**
* @brief HRD conformance models
**/

typedef enum HRDconformance
{
    HRD_off    = HEVC_HRD_OFF,          /**<@brief HRD off */
    HRD_strict = HEVC_HRD_STRICT,       /**<@brief HRD strict*/
    HRD_fast   = HEVC_HRD_FAST          /**<@brief HRD fast*/
} HRDconformance_t;

/**
* @brief Slicing modes
**/

typedef enum SliceMode
{
    SliceModeNumber = HEVC_SLICE_MODE_NUMBER,       /**<@brief Specify number of slices per picture */
    SliceModeCtuRows = HEVC_SLICE_MODE_CTU_ROWS,    /**<@brief Specify number of CTU rows per slice */
} SliceMode_t;

typedef int (* setMediaTypeCallback)(PIN_DIRECTION direction, const CMediaType * pmt);                              /**<@brief Callback on media type set */ 
typedef int (* startCallback)(hevc_v_settings * enc_settings);                                                      /**<@brief Callback on encoding start */ 
typedef int (* receiveCallback)(IMediaSample * psample, hevc_user_data_tt** seq_ud, hevc_user_data_tt** pic_ud);    /**<@brief Callback on data receive */ 

/**
* @brief Describes Callback methods.
**/    
typedef struct
{
    setMediaTypeCallback    onSetMediaType;         /**<@brief Callback on media type set */ 
    startCallback           onStartStreaming;       /**<@brief Callback on encoding start */ 
    receiveCallback         onReceive;             /**<@brief Callback on data receive */ 

} hevc_dshow_callback_t;

/**
* DS HEVC Encoder parameters GUID
* @{
*/

// {49788278-4F65-442D-9968-A4B1ACA87502}
static const GUID MCH265VE_MAX_DEC_PIC_BUFFERING = 
{ 0x49788278, 0x4f65, 0x442d, { 0x99, 0x68, 0xa4, 0xb1, 0xac, 0xa8, 0x75, 0x2 } };

// {49626A7E-F8F9-4372-A8C9-60380F1649EF}
static const GUID MCH265VE_MAX_SRC_PIC_BUFFERING = 
{ 0x49626a7e, 0xf8f9, 0x4372, { 0xa8, 0xc9, 0x60, 0x38, 0xf, 0x16, 0x49, 0xef } };

// {A2AB2EBD-8BD4-46D6-A4AA-EAADBDE2F06D}
static const GUID MCH265VE_MIN_SRC_PIC_BUFFERING = 
{ 0xa2ab2ebd, 0x8bd4, 0x46d6, { 0xa4, 0xaa, 0xea, 0xad, 0xbd, 0xe2, 0xf0, 0x6d } };

// {E962C6D2-AB50-4180-A25F-8B0CCC06D427}
static const GUID MCH265VE_LUMA_BIT_DEPTH = 
{ 0xe962c6d2, 0xab50, 0x4180, { 0xa2, 0x5f, 0x8b, 0xc, 0xcc, 0x6, 0xd4, 0x27 } };

// {555FC459-3943-4397-BC3C-0AEB8C21C56D}
static const GUID MCH265VE_CHROMA_BIT_DEPTH = 
{ 0x555fc459, 0x3943, 0x4397, { 0xbc, 0x3c, 0xa, 0xeb, 0x8c, 0x21, 0xc5, 0x6d } };

// {B5593899-A292-4D62-B927-35C7243B2447}
static const GUID MCH265VE_FRAME_RATE = 
{ 0xb5593899, 0xa292, 0x4d62, { 0xb9, 0x27, 0x35, 0xc7, 0x24, 0x3b, 0x24, 0x47 } };

// {EF268544-2AA9-4FBD-A577-D13C061D9737}
static const GUID MCH265VE_MAX_POC = 
{ 0xef268544, 0x2aa9, 0x4fbd, { 0xa5, 0x77, 0xd1, 0x3c, 0x6, 0x1d, 0x97, 0x37 } };

// {01F6FFF9-B279-4817-ABC8-E18ED63E0452}
static const GUID MCH265VE_VIDEO_SIGNAL_TYPE = 
{ 0x1f6fff9, 0xb279, 0x4817, { 0xab, 0xc8, 0xe1, 0x8e, 0xd6, 0x3e, 0x4, 0x52 } };

// {994B055A-A3D4-4152-8A70-0E306EFEB51C}
static const GUID MCH265VE_IN_SIGNAL_RANGE_FLAG =
{ 0x994b055a, 0xa3d4, 0x4152, { 0x8a, 0x70, 0xe, 0x30, 0x6e, 0xfe, 0xb5, 0x1c } };

// {006F69F6-6D06-4BB4-BD37-963FFBD2DA9A}
static const GUID MCH265VE_OUT_SIGNAL_RANGE_FLAG =
{ 0x6f69f6, 0x6d06, 0x4bb4, { 0xbd, 0x37, 0x96, 0x3f, 0xfb, 0xd2, 0xda, 0x9a } };

// {B6A9403E-7DB4-4562-AED8-B0D2228325E9}
static const GUID MCH265VE_CPU_OPT = 
{ 0xb6a9403e, 0x7db4, 0x4562, { 0xae, 0xd8, 0xb0, 0xd2, 0x22, 0x83, 0x25, 0xe9 } };

// {EFAD61A2-DC80-4153-A31D-5F23140DCD03}
static const GUID MCH265VE_NUM_THREADS = 
{ 0xefad61a2, 0xdc80, 0x4153, { 0xa3, 0x1d, 0x5f, 0x23, 0x14, 0xd, 0xcd, 0x3 } };

// {59C23DC4-AFE8-4D0E-B19E-3EAFB6563CF7}
static const GUID MCH265VE_NUM_PARALLEL_PICS = 
{ 0x59c23dc4, 0xafe8, 0x4d0e, { 0xb1, 0x9e, 0x3e, 0xaf, 0xb6, 0x56, 0x3c, 0xf7 } };

// {B412459B-330B-487B-9D54-98D6F4354C15}
static const GUID MCH265VE_MAX_NUM_REENCODINGS = 
{ 0xb412459b, 0x330b, 0x487b, { 0x9d, 0x54, 0x98, 0xd6, 0xf4, 0x35, 0x4c, 0x15 } };

// {D9A66C1D-1A5A-4131-90DD-FE8FC501B3C8}
static const GUID MCH265VE_MAX_INTRA_PERIOD = 
{ 0xd9a66c1d, 0x1a5a, 0x4131, { 0x90, 0xdd, 0xfe, 0x8f, 0xc5, 0x1, 0xb3, 0xc8 } };

// {BA0F78BF-8004-4805-83D8-2D763EC0039D}
static const GUID MCH265VE_MIN_INTRA_PERIOD = 
{ 0xba0f78bf, 0x8004, 0x4805, { 0x83, 0xd8, 0x2d, 0x76, 0x3e, 0xc0, 0x3, 0x9d } };

// {85A9C105-2801-46E6-A34E-D92DDC065530}
static const GUID MCH265VE_IRAP_PERIOD = 
{ 0x85a9c105, 0x2801, 0x46e6, { 0xa3, 0x4e, 0xd9, 0x2d, 0xdc, 0x6, 0x55, 0x30 } };

// {C218FE14-B3C7-4BC5-AF7F-6FC53C3C2A3D}
static const GUID MCH265VE_FIXED_I_POS = 
{ 0xc218fe14, 0xb3c7, 0x4bc5, { 0xaf, 0x7f, 0x6f, 0xc5, 0x3c, 0x3c, 0x2a, 0x3d } };

// {3B6BFF70-F528-48B9-A773-67176A586B32}
static const GUID MCH265VE_VSCD_MODE = 
{ 0x3b6bff70, 0xf528, 0x48b9, { 0xa7, 0x73, 0x67, 0x17, 0x6a, 0x58, 0x6b, 0x32 } };

// {8AE00BE5-5A73-457A-A152-57C3BC7FDCCB}
static const GUID MCH265VE_ADAPT_NUM_B_PICS = 
{ 0x8ae00be5, 0x5a73, 0x457a, { 0xa1, 0x52, 0x57, 0xc3, 0xbc, 0x7f, 0xdc, 0xcb } };

// {95A2EDA0-479E-440A-8961-8927412C71EB}
static const GUID MCH265VE_NUM_B_PICS = 
{ 0x95a2eda0, 0x479e, 0x440a, { 0x89, 0x61, 0x89, 0x27, 0x41, 0x2c, 0x71, 0xeb } };

// {F754AE13-6EA9-4573-BFE7-EA42BD9CE6E2}
static const GUID MCH265VE_PYRAMID_B_PICS = 
{ 0xf754ae13, 0x6ea9, 0x4573, { 0xbf, 0xe7, 0xea, 0x42, 0xbd, 0x9c, 0xe6, 0xe2 } };

// {A75D4D49-03D3-4092-824F-8FE9BC11C170}
static const GUID MCH265VE_MAX_NUM_P_PICS = 
{ 0xa75d4d49, 0x3d3, 0x4092, { 0x82, 0x4f, 0x8f, 0xe9, 0xbc, 0x11, 0xc1, 0x70 } };

// {38C13460-ECFE-49C5-848F-93608AE83002}
static const GUID MCH265VE_MAX_NUM_B_PICS_L0 = 
{ 0x38c13460, 0xecfe, 0x49c5, { 0x84, 0x8f, 0x93, 0x60, 0x8a, 0xe8, 0x30, 0x2 } };

// {8B4C1CE2-3F27-4D3F-A0DF-C86055B68379}
static const GUID MCH265VE_MAX_NUM_B_PICS_L1 = 
{ 0x8b4c1ce2, 0x3f27, 0x4d3f, { 0xa0, 0xdf, 0xc8, 0x60, 0x55, 0xb6, 0x83, 0x79 } };

// {82793675-F3E3-4A1B-91AB-E8B62C45AE3B}
static const GUID MCH265VE_TIER = 
{ 0x82793675, 0xf3e3, 0x4a1b, { 0x91, 0xab, 0xe8, 0xb6, 0x2c, 0x45, 0xae, 0x3b } };

// {BB21077D-EF4E-4CAB-A02D-54543466B81D}
static const GUID MCH265VE_WPP = 
{ 0xbb21077d, 0xef4e, 0x4cab, { 0xa0, 0x2d, 0x54, 0x54, 0x34, 0x66, 0xb8, 0x1d } };

// {5C3965BC-2147-4554-9B48-AC3E7494CE04}
static const GUID MCH265VE_SLICE_MODE =
{ 0x5c3965bc, 0x2147, 0x4554, { 0x9b, 0x48, 0xac, 0x3e, 0x74, 0x94, 0xce, 0x4 } };

// {2AFD24DB-1F62-4A49-B07B-DDECA40017D1}
static const GUID MCH265VE_SLICE_DATA = 
{ 0x2afd24db, 0x1f62, 0x4a49, { 0xb0, 0x7b, 0xdd, 0xec, 0xa4, 0x0, 0x17, 0xd1 } };

// {27DEDBF5-A14E-4D2F-85A0-627919D46244}
static const GUID MCH265VE_MIN_CU = 
{ 0x27dedbf5, 0xa14e, 0x4d2f, { 0x85, 0xa0, 0x62, 0x79, 0x19, 0xd4, 0x62, 0x44 } };

// {E7761DEF-F2C5-4235-8375-9BEB453702C6}
static const GUID MCH265VE_MAX_CU = 
{ 0xe7761def, 0xf2c5, 0x4235, { 0x83, 0x75, 0x9b, 0xeb, 0x45, 0x37, 0x2, 0xc6 } };

// {01A88AA9-27EC-4314-85BE-1E92A314FFA6}
static const GUID MCH265VE_MIN_TU = 
{ 0x1a88aa9, 0x27ec, 0x4314, { 0x85, 0xbe, 0x1e, 0x92, 0xa3, 0x14, 0xff, 0xa6 } };

// {40435F03-9E76-447A-BDE6-E5C852421961}
static const GUID MCH265VE_MAX_TU = 
{ 0x40435f03, 0x9e76, 0x447a, { 0xbd, 0xe6, 0xe5, 0xc8, 0x52, 0x42, 0x19, 0x61 } };

// {5E3BA67C-7B74-480C-8DAC-48F2C2201339}
static const GUID MCH265VE_MAX_TU_DEPTH_INTRA = 
{ 0x5e3ba67c, 0x7b74, 0x480c, { 0x8d, 0xac, 0x48, 0xf2, 0xc2, 0x20, 0x13, 0x39 } };

// {4C492A7E-8595-4807-A86B-3F68A5007F87}
static const GUID MCH265VE_MAX_TU_DEPTH_INTER = 
{ 0x4c492a7e, 0x8595, 0x4807, { 0xa8, 0x6b, 0x3f, 0x68, 0xa5, 0x0, 0x7f, 0x87 } };

// {1066C7D3-AB58-4F90-B206-134DC1DFEC89}
static const GUID MCH265VE_INTRA_PARTNG = 
{ 0x1066c7d3, 0xab58, 0x4f90, { 0xb2, 0x6, 0x13, 0x4d, 0xc1, 0xdf, 0xec, 0x89 } };

// {4F61595C-EACA-4CBC-B102-BC62C12B2123}
static const GUID MCH265VE_INTRA_CHROMA = 
{ 0x4f61595c, 0xeaca, 0x4cbc, { 0xb1, 0x2, 0xbc, 0x62, 0xc1, 0x2b, 0x21, 0x23 } };

// {23F05709-530F-408F-B2CE-748C337E771A}
static const GUID MCH265VE_INTRA_SMOOTH = 
{ 0x23f05709, 0x530f, 0x408f, { 0xb2, 0xce, 0x74, 0x8c, 0x33, 0x7e, 0x77, 0x1a } };

// {7AAD94A3-7814-4054-8534-F43ABF9E3190}
static const GUID MCH265VE_MOTION_RANGE = 
{ 0x7aad94a3, 0x7814, 0x4054, { 0x85, 0x34, 0xf4, 0x3a, 0xbf, 0x9e, 0x31, 0x90 } };

// {DAACA6CE-0986-409F-842D-C5DCB98A1871}
static const GUID MCH265VE_MOTION_PRECISION = 
{ 0xdaaca6ce, 0x986, 0x409f, { 0x84, 0x2d, 0xc5, 0xdc, 0xb9, 0x8a, 0x18, 0x71 } };

// {4E814935-4A4A-4C4E-9BFE-678CFFBDE07C}
static const GUID MCH265VE_OUT_OF_PIC_MV = 
{ 0x4e814935, 0x4a4a, 0x4c4e, { 0x9b, 0xfe, 0x67, 0x8c, 0xff, 0xbd, 0xe0, 0x7c } };

// {53E2825A-F5CD-4D90-BBD7-0609ADA14B05}
static const GUID MCH265VE_MERGE_CANDS = 
{ 0x53e2825a, 0xf5cd, 0x4d90, { 0xbb, 0xd7, 0x6, 0x9, 0xad, 0xa1, 0x4b, 0x5 } };

// {237B2E0E-122D-417E-B4BC-AD07E0D2AD1D}
static const GUID MCH265VE_INTER_PARTNG = 
{ 0x237b2e0e, 0x122d, 0x417e, { 0xb4, 0xbc, 0xad, 0x7, 0xe0, 0xd2, 0xad, 0x1d } };

// {AF6A69A1-6972-4839-8FCD-AC9088DF1998}
static const GUID MCH265VE_TMVP = 
{ 0xaf6a69a1, 0x6972, 0x4839, { 0x8f, 0xcd, 0xac, 0x90, 0x88, 0xdf, 0x19, 0x98 } };

// {BC0887B1-3B23-4A4E-BA0B-CA82F8D00F34}
static const GUID MCH265VE_INTER_CHROMA = 
{ 0xbc0887b1, 0x3b23, 0x4a4e, { 0xba, 0xb, 0xca, 0x82, 0xf8, 0xd0, 0xf, 0x34 } };

// {EBA994DB-7CE0-4F1E-8E34-8B2922D6CBA2}
static const GUID MCH265VE_DEBLOCK = 
{ 0xeba994db, 0x7ce0, 0x4f1e, { 0x8e, 0x34, 0x8b, 0x29, 0x22, 0xd6, 0xcb, 0xa2 } };

// {EFA2B4B5-E67D-4F05-A0D9-3E740D81607A}
static const GUID MCH265VE_BETA_OFFS = 
{ 0xefa2b4b5, 0xe67d, 0x4f05, { 0xa0, 0xd9, 0x3e, 0x74, 0xd, 0x81, 0x60, 0x7a } };

// {6667FD0A-5D6E-4B7B-B8E8-39609C2F6176}
static const GUID MCH265VE_TC_OFFS = 
{ 0x6667fd0a, 0x5d6e, 0x4b7b, { 0xb8, 0xe8, 0x39, 0x60, 0x9c, 0x2f, 0x61, 0x76 } };

// {5C4B1CC3-B23E-49B4-A7CC-0CA00C8EE145}
static const GUID MCH265VE_SAO_LUMA = 
{ 0x5c4b1cc3, 0xb23e, 0x49b4, { 0xa7, 0xcc, 0xc, 0xa0, 0xc, 0x8e, 0xe1, 0x45 } };

// {E30CD4BE-E8F1-4411-BD69-2CE20F8A052C}
static const GUID MCH265VE_SAO_CHROMA = 
{ 0xe30cd4be, 0xe8f1, 0x4411, { 0xbd, 0x69, 0x2c, 0xe2, 0xf, 0x8a, 0x5, 0x2c } };

// {94327A44-FC99-44E3-B604-0C8E0F184C80}
static const GUID MCH265VE_QP_I = 
{ 0x94327a44, 0xfc99, 0x44e3, { 0xb6, 0x4, 0xc, 0x8e, 0xf, 0x18, 0x4c, 0x80 } };

// {29D26D67-B419-418E-9130-76CD45A92AB8}
static const GUID MCH265VE_QP_P = 
{ 0x29d26d67, 0xb419, 0x418e, { 0x91, 0x30, 0x76, 0xcd, 0x45, 0xa9, 0x2a, 0xb8 } };

// {68DF2D89-6EA5-4AD8-879A-27848C190EB8}
static const GUID MCH265VE_QP_B = 
{ 0x68df2d89, 0x6ea5, 0x4ad8, { 0x87, 0x9a, 0x27, 0x84, 0x8c, 0x19, 0xe, 0xb8 } };

// {6F32A58B-8F6D-46FF-92B6-41E271D029FB}
static const GUID MCH265VE_RATE_FACTOR =
{ 0x6f32a58b, 0x8f6d, 0x46ff,{ 0x92, 0xb6, 0x41, 0xe2, 0x71, 0xd0, 0x29, 0xfb } };

// {C5674DDE-7814-461E-A107-B6F1B7236F0F}
static const GUID MCH265VE_MIN_QP = 
{ 0xc5674dde, 0x7814, 0x461e, { 0xa1, 0x7, 0xb6, 0xf1, 0xb7, 0x23, 0x6f, 0xf } };

// {68F95FFD-6EF6-4EFF-BE11-F974C3D93D63}
static const GUID MCH265VE_MAX_QP = 
{ 0x68f95ffd, 0x6ef6, 0x4eff, { 0xbe, 0x11, 0xf9, 0x74, 0xc3, 0xd9, 0x3d, 0x63 } };

// {E2E8D2AC-D640-4BF1-ACE2-A31DC2C5C1B6}
static const GUID MCH265VE_CPB_SIZE = 
{ 0xe2e8d2ac, 0xd640, 0x4bf1, { 0xac, 0xe2, 0xa3, 0x1d, 0xc2, 0xc5, 0xc1, 0xb6 } };

// {C5B6CCD8-A972-47C1-9837-3A4B0F4AEFC3}
static const GUID MCH265VE_HRD = 
{ 0xc5b6ccd8, 0xa972, 0x47c1, { 0x98, 0x37, 0x3a, 0x4b, 0xf, 0x4a, 0xef, 0xc3 } };

// {F3283C53-6020-4B26-B607-86C281070F81}
static const GUID MCH265VE_INIT_CPB_FULLNESS = 
{ 0xf3283c53, 0x6020, 0x4b26, { 0xb6, 0x7, 0x86, 0xc2, 0x81, 0x7, 0xf, 0x81 } };

// {DFF23806-7DF4-468A-99C7-591FAD744D2F}
static const GUID MCH265VE_CPB_FULLNESS_UNITS = 
{ 0xdff23806, 0x7df4, 0x468a, { 0x99, 0xc7, 0x59, 0x1f, 0xad, 0x74, 0x4d, 0x2f } };

// {2E7E93E7-FFD5-44FE-B7A1-CF9AAE677939}
static const GUID MCH265VE_SIGN_HIDING = 
{ 0x2e7e93e7, 0xffd5, 0x44fe, { 0xb7, 0xa1, 0xcf, 0x9a, 0xae, 0x67, 0x79, 0x39 } };

// {27811EAD-AE52-439D-917E-CE57AC57DFEA}
static const GUID MCH265VE_TRFM_SKIP = 
{ 0x27811ead, 0xae52, 0x439d, { 0x91, 0x7e, 0xce, 0x57, 0xac, 0x57, 0xdf, 0xea } };

// {47F03015-F29C-462C-B63D-F91D649BB8F5}
static const GUID MCH265VE_CB_QP_OFFS = 
{ 0x47f03015, 0xf29c, 0x462c, { 0xb6, 0x3d, 0xf9, 0x1d, 0x64, 0x9b, 0xb8, 0xf5 } };

// {95AFE183-16C7-48BF-9DBF-DB6237AB71C9}
static const GUID MCH265VE_CR_QP_OFFS = 
{ 0x95afe183, 0x16c7, 0x48bf, { 0x9d, 0xbf, 0xdb, 0x62, 0x37, 0xab, 0x71, 0xc9 } };

// {27197051-5713-4480-8F46-2B4C7CE1A186}
static const GUID MCH265VE_RDOQ = 
{ 0x27197051, 0x5713, 0x4480, { 0x8f, 0x46, 0x2b, 0x4c, 0x7c, 0xe1, 0xa1, 0x86 } };

// {CABDC08D-34C7-438D-8BFF-3A5F61474922}
static const GUID MCH265VE_SAR = 
{ 0xcabdc08d, 0x34c7, 0x438d, { 0x8b, 0xff, 0x3a, 0x5f, 0x61, 0x47, 0x49, 0x22 } };

// {179DBC3C-15B4-40DB-B1CC-B58CE1BFA9E6}
static const GUID MCH265VE_SAR_X = 
{ 0x179dbc3c, 0x15b4, 0x40db, { 0xb1, 0xcc, 0xb5, 0x8c, 0xe1, 0xbf, 0xa9, 0xe6 } };

// {A529E578-CC73-43C0-88BD-58DDA0935786}
static const GUID MCH265VE_SAR_Y = 
{ 0xa529e578, 0xcc73, 0x43c0, { 0x88, 0xbd, 0x58, 0xdd, 0xa0, 0x93, 0x57, 0x86 } };

// {4E970599-52EE-4825-B4BD-D32D1E1C5E7C}
static const GUID MCH265VE_ANNEX_B = 
{ 0x4e970599, 0x52ee, 0x4825, { 0xb4, 0xbd, 0xd3, 0x2d, 0x1e, 0x1c, 0x5e, 0x7c } };

// {2ADE44A7-F4C4-4EC2-8867-BCA5F2E19FFA}
static const GUID MCH265VE_STREAM_TYPE = 
{ 0x2ade44a7, 0xf4c4, 0x4ec2, { 0x88, 0x67, 0xbc, 0xa5, 0xf2, 0xe1, 0x9f, 0xfa } };

// {15E97698-369E-4D01-A99D-7980D915851B}
static const GUID MCH265VE_AUD = 
{ 0x15e97698, 0x369e, 0x4d01, { 0xa9, 0x9d, 0x79, 0x80, 0xd9, 0x15, 0x85, 0x1b } };

// {841EAE89-DEE9-4620-B581-9A52204A93DD}
static const GUID MCH265VE_SEQ_END = 
{ 0x841eae89, 0xdee9, 0x4620, { 0xb5, 0x81, 0x9a, 0x52, 0x20, 0x4a, 0x93, 0xdd } };

// {BCF2FAF6-9A28-4006-AF6E-3CA4C41C354B}
static const GUID MCH265VE_SINGLE_SEI = 
{ 0xbcf2faf6, 0x9a28, 0x4006, { 0xaf, 0x6e, 0x3c, 0xa4, 0xc4, 0x1c, 0x35, 0x4b } };

// {C3427FFB-130E-4621-89A7-8574AB94EDCF}
static const GUID MCH265VE_TIMING_INFO = 
{ 0xc3427ffb, 0x130e, 0x4621, { 0x89, 0xa7, 0x85, 0x74, 0xab, 0x94, 0xed, 0xcf } };

// {D78F896D-C810-4CAD-AB5A-675C81681233}
static const GUID MCH265VE_SET_DEFAULT_VALUES = 
{ 0xd78f896d, 0xc810, 0x4cad, { 0xab, 0x5a, 0x67, 0x5c, 0x81, 0x68, 0x12, 0x33 } };

// {8E2A1E30-EDBD-4E6E-AA6B-59DE6398DF28}
static const GUID MCH265VE_IS_RUNNING = 
{ 0x8e2a1e30, 0xedbd, 0x4e6e, { 0xaa, 0x6b, 0x59, 0xde, 0x63, 0x98, 0xdf, 0x28 } };

// {AE81DE95-1E15-4460-B0FF-8FD9D799EAF3}
static const GUID MCH265VE_IS_INPUT_CONNECTED =
{ 0xae81de95, 0x1e15, 0x4460,{ 0xb0, 0xff, 0x8f, 0xd9, 0xd7, 0x99, 0xea, 0xf3 } };

// {9D17DC93-4942-4441-82B3-2A793E059BFE}
static const GUID MCH265VE_INPUT_PICTURE_HEIGHT = 
{ 0x9d17dc93, 0x4942, 0x4441, { 0x82, 0xb3, 0x2a, 0x79, 0x3e, 0x5, 0x9b, 0xfe } };

// {CADF61D4-984F-4DEA-8364-80A5DCE86747}
static const GUID MCH265VE_INPUT_PICTURE_WIDTH = 
{ 0xcadf61d4, 0x984f, 0x4dea, { 0x83, 0x64, 0x80, 0xa5, 0xdc, 0xe8, 0x67, 0x47 } };

// {69A2A759-B9FE-4767-8CAC-A81D0AE2B99C}
static const GUID MCH265VE_OUTPUT_PICTURE_HEIGHT =
{ 0x69a2a759, 0xb9fe, 0x4767,{ 0x8c, 0xac, 0xa8, 0x1d, 0xa, 0xe2, 0xb9, 0x9c } };

// {2B54E728-F815-40D1-92F8-3EA0D952E1B2}
static const GUID MCH265VE_OUTPUT_PICTURE_WIDTH =
{ 0x2b54e728, 0xf815, 0x40d1,{ 0x92, 0xf8, 0x3e, 0xa0, 0xd9, 0x52, 0xe1, 0xb2 } };

// {EC24F1C7-744C-4070-B0C4-5949570ED6BB}
static const GUID MCH265VE_RESIZE_OUTPUT_PICTURE =
{ 0xec24f1c7, 0x744c, 0x4070,{ 0xb0, 0xc4, 0x59, 0x49, 0x57, 0xe, 0xd6, 0xbb } };

// {BEB10BBD-1A90-4130-91CF-14558D080448}
static const GUID MCH265VE_INPUT_FRAME_RATE = 
{ 0xbeb10bbd, 0x1a90, 0x4130, { 0x91, 0xcf, 0x14, 0x55, 0x8d, 0x8, 0x4, 0x48 } };

// {63C7E71E-4049-4AA7-86ED-9F5239821A2C}
static const GUID MCH265VE_INPUT_INTERLACE = 
{ 0x63c7e71e, 0x4049, 0x4aa7, { 0x86, 0xed, 0x9f, 0x52, 0x39, 0x82, 0x1a, 0x2c } };

// {FC3C34AE-AB34-4279-A5DE-135B88F54D79}
static const GUID MCH265VE_INPUT_COLOUR_SPACE = 
{ 0xfc3c34ae, 0xab34, 0x4279, { 0xa5, 0xde, 0x13, 0x5b, 0x88, 0xf5, 0x4d, 0x79 } };

// {24FB42C6-0937-4545-A0C3-0F042725B9D0}
static const GUID MCH265VE_INPUT_BIT_DEPTH = 
{ 0x24fb42c6, 0x937, 0x4545, { 0xa0, 0xc3, 0xf, 0x4, 0x27, 0x25, 0xb9, 0xd0 } };

// {9ECC6500-7C8C-4B78-985F-122A6B3671F9}
static const GUID MCH265VE_PERFORMANCE_LEVEL = 
{ 0x9ecc6500, 0x7c8c, 0x4b78, { 0x98, 0x5f, 0x12, 0x2a, 0x6b, 0x36, 0x71, 0xf9 } };

// {211BB76E-A078-4E61-9DCA-653C1B6723AB}
static const GUID MCH265VE_PERFORMANCE_LEVEL_AVG =
{ 0x211bb76e, 0xa078, 0x4e61,{ 0x9d, 0xca, 0x65, 0x3c, 0x1b, 0x67, 0x23, 0xab } };

// {6C9F732E-1209-42BB-9446-D0C104C3F4A0}
static const GUID MCH265VE_AQ_MODE = 
{ 0x6c9f732e, 0x1209, 0x42bb, { 0x94, 0x46, 0xd0, 0xc1, 0x4, 0xc3, 0xf4, 0xa0 } };

// {EF4CEE64-F2AB-4BC0-B9E0-691E46369850}
static const GUID MCH265VE_INPUT_FILTERING =
{ 0xef4cee64, 0xf2ab, 0x4bc0, { 0xb9, 0xe0, 0x69, 0x1e, 0x46, 0x36, 0x98, 0x50 } };

// {A4B36949-C97C-4322-96A6-35092D4B067C}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_XO = 
{ 0xa4b36949, 0xc97c, 0x4322, { 0x96, 0xa6, 0x35, 0x9, 0x2d, 0x4b, 0x6, 0x7c } };

// {6D86FDC2-BDC9-4CA0-9F4D-B1CDB040786E}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_X1 = 
{ 0x6d86fdc2, 0xbdc9, 0x4ca0, { 0x9f, 0x4d, 0xb1, 0xcd, 0xb0, 0x40, 0x78, 0x6e } };

// {603DF0AA-0273-46AD-A8A1-3EA3480456CD}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_X2 = 
{ 0x603df0aa, 0x273, 0x46ad, { 0xa8, 0xa1, 0x3e, 0xa3, 0x48, 0x4, 0x56, 0xcd } };

// {8AD46264-A366-4178-81D4-9E8D6009AD58}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_YO = 
{ 0x8ad46264, 0xa366, 0x4178, { 0x81, 0xd4, 0x9e, 0x8d, 0x60, 0x9, 0xad, 0x58 } };

// {DD9DC58F-FDB5-4844-9460-7D7664396641}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_Y1 = 
{ 0xdd9dc58f, 0xfdb5, 0x4844, { 0x94, 0x60, 0x7d, 0x76, 0x64, 0x39, 0x66, 0x41 } };

// {C3DC5E15-098F-4368-AA80-77B0263954D3}
static const GUID MCH265VE_SMPTE_ST_2086_PRIM_Y2 = 
{ 0xc3dc5e15, 0x98f, 0x4368, { 0xaa, 0x80, 0x77, 0xb0, 0x26, 0x39, 0x54, 0xd3 } };

// {F247D82F-7E31-40F1-9FB4-047A983E9E8A}
static const GUID MCH265VE_SMPTE_ST_2086_WHITE_POINT_X = 
{ 0xf247d82f, 0x7e31, 0x40f1, { 0x9f, 0xb4, 0x4, 0x7a, 0x98, 0x3e, 0x9e, 0x8a } };

// {05913738-4259-44AA-8330-64967AC2BF8C}
static const GUID MCH265VE_SMPTE_ST_2086_WHITE_POINT_Y = 
{ 0x5913738, 0x4259, 0x44aa, { 0x83, 0x30, 0x64, 0x96, 0x7a, 0xc2, 0xbf, 0x8c } };

// {2E6808A4-1C40-4A64-91A3-A39EED74F513}
static const GUID MCH265VE_SMPTE_ST_2086_MAX_LUMINANCE = 
{ 0x2e6808a4, 0x1c40, 0x4a64, { 0x91, 0xa3, 0xa3, 0x9e, 0xed, 0x74, 0xf5, 0x13 } };

// {FA96064C-1104-497D-BA78-249D3551531B}
static const GUID MCH265VE_SMPTE_ST_2086_MIN_LUMINANCE = 
{ 0xfa96064c, 0x1104, 0x497d, { 0xba, 0x78, 0x24, 0x9d, 0x35, 0x51, 0x53, 0x1b } };

// {034FC55D-AD84-49bf-9F37-4353EA398EAE}
static const GUID MCH265VE_MAX_CLL = 
{ 0x34fc55d, 0xad84, 0x49bf, { 0x9f, 0x37, 0x43, 0x53, 0xea, 0x39, 0x8e, 0xae } };

// {1F24F808-9C20-45cd-833B-17FEA071617C}
static const GUID MCH265VE_MAX_PALL = 
{ 0x1f24f808, 0x9c20, 0x45cd, { 0x83, 0x3b, 0x17, 0xfe, 0xa0, 0x71, 0x61, 0x7c } };

// {CD43FABD-B01B-4CD6-BDFC-27EB11DAAE07}
static const GUID MCH265VE_SKIPPED_FRAMES = 
{ 0xcd43fabd, 0xb01b, 0x4cd6, { 0xbd, 0xfc, 0x27, 0xeb, 0x11, 0xda, 0xae, 0x07 } };

// {ECFDFC2B-80D4-4C85-910E-A48F358F38D2}
static const GUID MCH265VE_BUF_FULLNESS =
{ 0xecfdfc2b, 0x80d4, 0x4c85, { 0x91, 0xe, 0xa4, 0x8f, 0x35, 0x8f, 0x38, 0xd2 } };

// {1788F065-41F3-46CF-BE7C-389A47569491}
static const GUID MCH265VE_BUF_MAXIMUM =
{ 0x1788f065, 0x41f3, 0x46cf, { 0xbe, 0x7c, 0x38, 0x9a, 0x47, 0x56, 0x94, 0x91 } };

// {A5D33534-6EA2-48AB-94E6-4CE7BC317D5C}
static const GUID MCH265VE_FRAMES_RECEIVED =
{ 0xa5d33534, 0x6ea2, 0x48ab,{ 0x94, 0xe6, 0x4c, 0xe7, 0xbc, 0x31, 0x7d, 0x5c } };

// {86C6B9FE-FAC5-4745-B44B-9CF40B6459B3}
static const GUID MCH265VE_HW_ACCEL =
{ 0x86c6b9fe, 0xfac5, 0x4745,{ 0xb4, 0x4b, 0x9c, 0xf4, 0xb, 0x64, 0x59, 0xb3 } };

// {E23F2284-6963-445B-896E-93FAEC84261D}
static const GUID MCH265VE_HW_ACCEL_MODE =
{ 0xe23f2284, 0x6963, 0x445b,{ 0x89, 0x6e, 0x93, 0xfa, 0xec, 0x84, 0x26, 0x1d } };

// {460705D8-6B77-4B48-92FF-43AB333CC957}
static const GUID MCH265VE_HW_ACCEL_IDX =
{ 0x460705d8, 0x6b77, 0x4b48, { 0x92, 0xff, 0x43, 0xab, 0x33, 0x3c, 0xc9, 0x57 } };

// {98380CE4-4EDF-4FBF-8A79-F4C65FD52EE5}
static const GUID MCH265VE_STATUS_MSG =
{ 0x98380ce4, 0x4edf, 0x4fbf,{ 0x8a, 0x79, 0xf4, 0xc6, 0x5f, 0xd5, 0x2e, 0xe5 } };

// {7887479C-114F-4B55-A238-ABF9FCFA5B5E}
static const GUID MCH265VE_LIVE = 
{ 0x7887479c, 0x114f, 0x4b55, { 0xa2, 0x38, 0xab, 0xf9, 0xfc, 0xfa, 0x5b, 0x5e } };

/**@}*/

}

#endif // __PROPID_H264ENC_HEADER__
