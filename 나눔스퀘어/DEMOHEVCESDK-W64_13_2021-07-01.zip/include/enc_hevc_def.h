/**
@file: enc_hevc_def.h
@brief HEVC/H.265 Encoder API defines

@verbatim
File: enc_hevc_def.h
Desc: HEVC/H.265 Encoder API defines

Copyright (c) 2019 MainConcept GmbH or its affiliates.  All rights reserved.

MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.  
This software is protected by copyright law and international treaties.  Unauthorized 
reproduction or distribution of any portion is prohibited by law.
@endverbatim
 **/


#if !defined (__ENC_HEVC_DEF_INCLUDED__)
#define __ENC_HEVC_DEF_INCLUDED__

#include <mcprofile.h>

/**
 *@name Useful defines
 *@{
**/
#define HEVC_MAX_LAYERS                                     12      /**< @brief  Maximum number of layers @hideinitializer*/
#define HEVC_MAX_TEMP_SUB_LAYERS                            3       /**< @brief  Maximum number of temporal sub-layers @hideinitializer*/
#define HEVC_MAX_UUID_SIZE                                  16      /**< @brief  UUID size @hideinitializer*/
#define HEVC_MAX_HW_DEVICES                                 8       /**< @brief  Maximum number of devices used for encoding @hideinitializer*/

#define HEVC_INFINITE_GOP                                   0x7FFFFFFF  /**< @brief  Infinite GOP*/
/** @}*/


/**
 * @brief Predefined encoder settings
**/
typedef enum 
{
    HEVC_MULTI =                                           -1,      /**< @brief  Preset for encoding several layers */
    HEVC_MAIN =                                             0,      /**< @brief  Similar to ISO/IEC 13818-1/2 */
    HEVC_MAIN_10 =                                          1,      /**< @brief  Similar to ISO/IEC 13818-1/2 */
    HEVC_4K =                                               4,      /**< @brief  Preset for 4k 8-bit encoding on a dual socket system */
    HEVC_4K_10 =                                            5,      /**< @brief  Preset for 4k 10-bit encoding on a dual socket system */

    HEVC_MAIN_422_10 =                                      100,    /**< @brief  Preset for Main 4:2:2 10-bit encoding */

    HEVC_HLS_L1 =                                           MCPROFILE_HLS_L1,               /**< @brief HEVC HLS for Apple Devices Profile Level 1. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L2 =                                           MCPROFILE_HLS_L2,               /**< @brief HEVC HLS for Apple Devices Profile Level 2. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L3 =                                           MCPROFILE_HLS_L3,               /**< @brief HEVC HLS for Apple Devices Profile Level 3. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L4 =                                           MCPROFILE_HLS_L4,               /**< @brief HEVC HLS for Apple Devices Profile Level 4. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L5 =                                           MCPROFILE_HLS_L5,               /**< @brief HEVC HLS for Apple Devices Profile Level 5. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L6 =                                           MCPROFILE_HLS_L6,               /**< @brief HEVC HLS for Apple Devices Profile Level 6. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L7 =                                           MCPROFILE_HLS_L7,               /**< @brief HEVC HLS for Apple Devices Profile Level 7. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L8 =                                           MCPROFILE_HLS_L8,               /**< @brief HEVC HLS for Apple Devices Profile Level 8. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L9 =                                           MCPROFILE_HLS_L9,               /**< @brief HEVC HLS for Apple Devices Profile Level 9. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L10 =                                          MCPROFILE_HLS_L10,              /**< @brief HEVC HLS for Apple Devices Profile Level 10. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L11 =                                          MCPROFILE_HLS_L11,              /**< @brief HEVC HLS for Apple Devices Profile Level 11. Please refer to @ref HEVC_HLS_PRESETS for details. */
    HEVC_HLS_L12 =                                          MCPROFILE_HLS_L12,              /**< @brief HEVC HLS for Apple Devices Profile Level 12. Please refer to @ref HEVC_HLS_PRESETS for details. */

    HEVC_DASH_L1 =                                          MCPROFILE_DASH_L1,              /**< @brief HEVC DASH Profile Level 1.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L2 =                                          MCPROFILE_DASH_L2,              /**< @brief HEVC DASH Profile Level 2.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L3 =                                          MCPROFILE_DASH_L3,              /**< @brief HEVC DASH Profile Level 3.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L4 =                                          MCPROFILE_DASH_L4,              /**< @brief HEVC DASH Profile Level 4.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L5 =                                          MCPROFILE_DASH_L5,              /**< @brief HEVC DASH Profile Level 5.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L6 =                                          MCPROFILE_DASH_L6,              /**< @brief HEVC DASH Profile Level 6.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L7 =                                          MCPROFILE_DASH_L7,              /**< @brief HEVC DASH Profile Level 7.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L8 =                                          MCPROFILE_DASH_L8,              /**< @brief HEVC DASH Profile Level 8.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L9 =                                          MCPROFILE_DASH_L9,              /**< @brief HEVC DASH Profile Level 9.  Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L10 =                                         MCPROFILE_DASH_L10,             /**< @brief HEVC DASH Profile Level 10. Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L11 =                                         MCPROFILE_DASH_L11,             /**< @brief HEVC DASH Profile Level 11. Please refer to @ref HEVC_DASH_PRESETS for details. */
    HEVC_DASH_L12 =                                         MCPROFILE_DASH_L12,             /**< @brief HEVC DASH Profile Level 12. Please refer to @ref HEVC_DASH_PRESETS for details. */

    HEVC_ARIB_8K =                                          MCPROFILE_ARIB_STD_B32_8K,      /**< @brief Preset for ARIB STD-B32 8K encoding */
} hevc_preset_t;

/**
 *@brief Profile defines
 **/
typedef enum 
{
    HEVC_PROFILE_MAIN =                                     1,      /**< @brief  Main Profile @hideinitializer */
    HEVC_PROFILE_MAIN_10 =                                  2,      /**< @brief  Main 10 Profile @hideinitializer */
    HEVC_PROFILE_MAIN_422_10 =                              3,      /**< @brief  Main 4:2:2 10 Profile @hideinitializer */
} hevc_profile_t;


/**
 *@brief Slicing modes (hevc_v_layer::slice_mode allowed values)
 *@{
 **/
#define HEVC_SLICE_MODE_NUMBER                              0       /**< @brief  Picture is partitioned into N slices, where N = hevc_v_layer::slice_number */
#define HEVC_SLICE_MODE_CTU_ROWS                            1       /**< @brief  Picture is partitioned into slices of N CTU rows each, where N = hevc_v_layer::slice_height */
/** @}*/

/**
*@name Options for hevcOutVideoChkSettings function.
*@{
**/
#define HEVC_ADJUST_MAIN                                    0       /**< @brief Minimal settings adjustment for HEVC profile, level and tier conformance (default) @hideinitializer */
#define HEVC_ADJUST_PRESET                                  1       /**< @brief Adjust settings for specified preset conformance @hideinitializer */
/** @}*/

/**
 *@name Level defines
 *@{
**/
#define HEVC_LEVEL_1                                        30      /**< @brief  Level 1 @hideinitializer */
#define HEVC_LEVEL_2                                        60      /**< @brief  Level 2 @hideinitializer */
#define HEVC_LEVEL_21                                       63      /**< @brief  Level 2.1 @hideinitializer */
#define HEVC_LEVEL_3                                        90      /**< @brief  Level 3 @hideinitializer */
#define HEVC_LEVEL_31                                       93      /**< @brief  Level 3.1 @hideinitializer */
#define HEVC_LEVEL_4                                        120     /**< @brief  Level 4 @hideinitializer */
#define HEVC_LEVEL_41                                       123     /**< @brief  Level 4.1 @hideinitializer */
#define HEVC_LEVEL_5                                        150     /**< @brief  Level 5 @hideinitializer */
#define HEVC_LEVEL_51                                       153     /**< @brief  Level 5.1 @hideinitializer */
#define HEVC_LEVEL_52                                       156     /**< @brief  Level 5.2 @hideinitializer */
#define HEVC_LEVEL_6                                        180     /**< @brief  Level 6 @hideinitializer */
#define HEVC_LEVEL_61                                       183     /**< @brief  Level 6.1 @hideinitializer */
#define HEVC_LEVEL_62                                       186     /**< @brief  Level 6.2 @hideinitializer */
#define HEVC_LEVEL_AUTO                                     1000    /**< @brief  Auto level identification @hideinitializer */
/** @}*/

/**
 *@name Chroma format defines
 *@{
**/
#define HEVC_CHROMA_400                                     0       /**< @brief Chroma Format 4:0:0 (Currently unsupported) @hideinitializer */
#define HEVC_CHROMA_420                                     1       /**< @brief Chroma Format 4:2:0  @hideinitializer */
#define HEVC_CHROMA_422                                     2       /**< @brief Chroma Format 4:2:2  @hideinitializer */
#define HEVC_CHROMA_444                                     3       /**< @brief Chroma Format 4:4:4 (Currently unsupported) @hideinitializer */
/** @}*/

/**
 *@name Stream types defines
 *@{
**/
#define HEVC_STREAM_TYPE_I                                  0       /**< @brief  VCL NALUs + filler data @hideinitializer */
#define HEVC_STREAM_TYPE_I_SEI                              1       /**< @brief  VCL NALUs + filler data + SEI messages @hideinitializer */
#define HEVC_STREAM_TYPE_II                                 2       /**< @brief  all NALU types @hideinitializer */
#define HEVC_STREAM_TYPE_II_NO_SEI                          3       /**< @brief  all NALU types except SEI @hideinitializer */
/** @}*/

/**
 *@name Video standard defines
 *@{
**/
#define HEVC_NTSC                                           0       /**< @brief  NTSC framerates  @hideinitializer */
#define HEVC_PAL                                            1       /**< @brief  PAL (25 fps) based material  @hideinitializer */
/** @}*/

/**
 *@name Bit-rate control modes
 *@{
**/
#define HEVC_CBR                                            0       /**< @brief  Constant bit rate @hideinitializer */
#define HEVC_CQT                                            1       /**< @brief  Constant quantization @hideinitializer */
#define HEVC_VBR                                            2       /**< @brief  Variable bit rate @hideinitializer */
#define HEVC_AQP                                            3       /**< @brief  Average quantization @hideinitializer */
#define HEVC_CRF                                            4       /**< @brief  Constant rate factor @hideinitializer */
/** @}*/

/**
  *@name HRD buffer units defines
 *@{
**/
#define HEVC_CPB_FULLNESS_PERCENT                           0       /**< @brief  CPB fullness in %  @hideinitializer */
#define HEVC_CPB_FULLNESS_BIT                               1       /**< @brief  CPB fullness in bits @hideinitializer */
#define HEVC_CPB_FULLNESS_90K                               2       /**< @brief  CPB fullness in 90 kHz units @hideinitializer */
/** @}*/

/**
 *@name QP schemes
 *@{
**/
#define HEVC_QP_SCHEME_DEFAULT                              0       /**< @brief  Default qp distribution among IPB pictures @hideinitializer*/
#define HEVC_QP_SCHEME_FLAT                                 1       /**< @brief  Flat qps for all pictures in GOP @hideinitializer*/
#define HEVC_QP_SCHEME_FIXED                                2       /**< @brief  Fixed qps for picture type @hideinitializer*/
/** @}*/

/**
 *@name CPU type defines
 *@{
**/
#define HEVC_CPU_OPT_AUTO                                   0       /**< @brief  Automatically choose CPU optimization  @hideinitializer */
#define HEVC_CPU_OPT_PLAIN_C                                1       /**< @brief  No optimization (Plain C Code only)  @hideinitializer */
#define HEVC_CPU_OPT_SSE4                                   3       /**< @brief  SSE4 Assembler optimizations  @hideinitializer */
#define HEVC_CPU_OPT_AVX2                                   4       /**< @brief  AVX2 Assembler optimizations  @hideinitializer */
#define HEVC_CPU_OPT_NEON                                   2       /**< @brief  ARM NEON optimizations @hideinitializer */
/** @}*/

/**
 *@name Motion search precision defines
 *@{
**/
#define HEVC_SEARCH_PRECISION_FULL_PEL                      0       /**< @brief  Full pixel precision only @hideinitializer */
#define HEVC_SEARCH_PRECISION_HALF_P                        1       /**< @brief  Half-pixels precision for P pictures only @hideinitializer */
#define HEVC_SEARCH_PRECISION_HALF_PB                       2       /**< @brief  Half-pixels precision for ref. pictures only @hideinitializer */
#define HEVC_SEARCH_PRECISION_QUARTER_P_HALF_B              3       /**< @brief  Quarter pixel positions for P pictures only. Half-pixels precision for ref. B pictures @hideinitializer */
#define HEVC_SEARCH_PRECISION_QUARTER_P_HALF_Bb             4       /**< @brief  Quarter pixel positions for P pictures only. Half-pixels precision for all B pictures @hideinitializer */
#define HEVC_SEARCH_PRECISION_QUARTER_PB_HALF_b             5       /**< @brief  Quarter pixel positions for ref. pictures only. Half-pixels precision for non-ref. pictures  @hideinitializer */
#define HEVC_SEARCH_PRECISION_QUARTER_PBb                   6       /**< @brief  Quarter pixel precision for all pictures @hideinitializer */
/** @}*/

/**
*@name Motion search pattern defines
*@{
**/
#define HEVC_SEARCH_PATTERN_LARGE_DIAMOND                   0       /**< @brief  Large diamond pattern @hideinitializer */
#define HEVC_SEARCH_PATTERN_HEX_HOR_FLAT                    1       /**< @brief  Flat hexagon pattern @hideinitializer */
#define HEVC_SEARCH_PATTERN_HEX_HOR                         2       /**< @brief  Hexagon pattern @hideinitializer */
#define HEVC_SEARCH_PATTERN_SMALL_DIAMOND                   3       /**< @brief  Small diamond pattern @hideinitializer */
/** @}*/


/**
 *@def INTER_PARTITIONONG
 *@name Inter partitioning
 *@{
**/
#define HEVC_INTER_PARTITIONING_OFF                         0       /**< @brief  No inter partitioning @hideinitializer */
#define HEVC_INTER_PARTITIONING_SYMMETRIC                   1       /**< @brief  Symmetric partitioning only @hideinitializer */
#define HEVC_INTER_PARTITIONING_ASYMMETRIC                  2       /**< @brief  Symmetric and asymmetric partitioning @hideinitializer */

/** @}*/

/**
 *@def TIME_STAMP
 *@name Time stamp to specify mode parameter in sample_info_struct
 *@{
**/
#define HEVC_TIMESTAMP_100NS                                0       /**< @brief  DirectShow style, 100 ns units (10 Mhz clock) @hideinitializer */
#define HEVC_TIMESTAMP_27MHZ                                1       /**< @brief  MPEG style, 27 Mhz clock @hideinitializer */
/** @}*/

/**
 *@name Level for the hevcOutVideoPerformance function
 *@{
**/
#define HEVC_PERF_FASTEST                                   1       /**< @brief  Pre-defined performance level: Fastest performance, least quality @hideinitializer */
#define HEVC_PERF_FAST                                      8       /**< @brief  Pre-defined performance level: Fast performance, less quality @hideinitializer */
#define HEVC_PERF_BALANCED                                  15      /**< @brief  Pre-defined performance level: Recommended default values, balanced between speed and quality @hideinitializer */
#define HEVC_PERF_BETTER_QUALITY                            20      /**< @brief  Pre-defined performance level: Good image quality, reduced speed @hideinitializer */
#define HEVC_PERF_BEST_QUALITY                              30      /**< @brief  Best quality configuration, least possible speed @hideinitializer */

#define HEVC_INITIAL_PERF_LEVEL                             0       /**< @brief  Initial performance level for encoding with auto-adjustment */
/** @}*/

/**
*@name Acceleration options for the hevcOutVideoDefaults function
*@{
**/
#define HEVC_HW_ACCELERATION_NONE                           0       /**< @brief  Pure software mode @hideinitializer */
#define HEVC_HW_ACCELERATION_IQSV                           1       /**< @brief  IQSV (Intel) acceleration @hideinitializer */
#define HEVC_HW_ACCELERATION_NVENC                          2       /**< @brief  NVENC (NVIDIA) acceleration @hideinitializer */
/** @}*/

/**
*@name Available hardware acceleration modes
*@{
**/
#define HEVC_HW_ACCELERATION_MODE_FULL                      0       /**< @brief  Hardware analysis, hardware encoding */
#define HEVC_HW_ACCELERATION_MODE_DRIVEN                    1       /**< @brief  Software analysis, hardware encoding */
#define HEVC_HW_ACCELERATION_MODE_HYBRID                    2       /**< @brief  Software analysis, hybrid (HW/SW) encoding */
/** @}*/

/**
*@name Inque acceleration modes
*@{
**/
#define HEVC_INQ_ACCELERATION_NONE                          0       /**< @brief  Pure software implementation @hideinitializer */
#define HEVC_INQ_ACCELERATION_CUDA                          1       /**< @brief  Enables intra and inter analysis acceleration with CUDA @hideinitializer */
/** @}*/

/**
*@name Inque numa node index
*@{
**/
#define HEVC_INQ_NUMA_NODE_CURRENT_THREAD                  -1       /**< @brief  Current thread NUMA node id */
#define HEVC_INQ_NUMA_NODE_AUTO                            -2       /**< @brief  Selects the best NUMA node id*/
/** @}*/

/**
 *@name Error codes
 *@{
**/
#define HEVC_ERROR_NONE                                     0       /**< @brief  No error @hideinitializer */
#define HEVC_ERROR_FAILED                                   1       /**< @brief  General error  @hideinitializer */
#define HEVC_ERROR_NOT_IMPLEMENTED                          2       /**< @brief  Feature not supported or not yet implemented @hideinitializer */
#define HEVC_ERROR_INVALID_ARGUMENT                         3       /**< @brief  One of the arguments is NULL  @hideinitializer */
#define HEVC_ERROR_NOT_ENOUGH_SPACE                         4       /**< @brief  Not enough space in memory or memory buffer @hideinitializer */
#define HEVC_ERROR_OPTIONS_IGNORED                          5       /**< @brief  Passed options are incompatible, thus ignored @hideinitializer */
#define HEVC_ERROR_UNABLE_TO_TRANSFER_DATA                  6       /**< @brief  Unable to transfer data to the output stream @hideinitializer */
#define HEVC_ERROR_UNSUPPORTED_COLORSPACE                   7       /**< @brief  Selected colorspace is not supported @hideinitializer */
#define HEVC_ERROR_VALIDATION_FAILED                        8       /**< @brief  Failed validation @hideinitializer */
/** @}*/

/**
 *@name Pyramid B pictures
 *@{
**/
#define HEVC_PYRAMID_B_OFF                                  0       /**< @brief  No reference dependences for consecutive B pictures @hideinitializer */
#define HEVC_PYRAMID_B_ON                                   1       /**< @brief  Fixed pyramid structure for consecutive B pictures @hideinitializer */
/** @}*/

/**
 *@name RDO quantization
 *@{
**/
#define HEVC_RDOQ_OFF                                       0       /**< @brief  Normal quantization @hideinitializer */
#define HEVC_RDOQ_DCT                                       1       /**< @brief  RDO quantization for DCT only  @hideinitializer */
#define HEVC_RDOQ_DCT_TS                                    2       /**< @brief  RDO quantization for DCT and TS  @hideinitializer */
/** @}*/

/**
 *@name Chapter flags
 *@{
**/
#define HEVC_CHAPTER_FORCE_IDR                              0x0010     /**<@brief If set then this chapter begins with an IDR-picture, otherwise with an non-IDR picture @hideinitializer*/
#define HEVC_CHAPTER_END_OF_LIST                            0x80000000 /**<@brief If set then this chapter is the last in the list. \warning Last item of list must have this flag, otherwise the encoder may crash or work unpredictable! @hideinitializer*/
/** @}*/

/**
* @name hevc_qp_map formats
* @{
*/
#define HEVC_QP_MAP_FORMAT_8X8_INT8_DELTA                   0       /**<@brief Each 8x8 luminance block must be represented by a byte, the values are interpreted as delta QPs. @hideinitializer*/
/** @}*/


/**
* @name De-interlacing mode
* @{
*/
#define HEVC_DEINTERLACE_NONE                               0       /**<@brief Disable deinterlacing @hideinitializer*/
#define HEVC_DEINTERLACE_AUTO                               1       /**<@brief Enable deinterlacing use first field interpolate the other @hideinitializer*/
#define HEVC_DEINTERLACE_USETOPFIELD                        2       /**<@brief Enable deinterlacing use top field @hideinitializer*/
#define HEVC_DEINTERLACE_USEBOTTOMFIELD                     3       /**<@brief Enable deinterlacing use bottom field @hideinitializer*/
#define HEVC_DEINTERLACE_USEBOTHFIELDS                      4       /**<@brief Enable deinterlacing blend fields @hideinitializer*/
/**@}*/


/**
* @name Video signal type present mode
* @{
*/
#define HEVC_VIDEO_SIGNAL_TYPE_PRESENT_AUTO                -1       /**<@brief Automaticly decides whether video signal type is present or not. @hideinitializer*/
#define HEVC_VIDEO_SIGNAL_TYPE_PRESENT                      0       /**<@brief Video signal type is present @hideinitializer*/
#define HEVC_VIDEO_SIGNAL_TYPE_NOT_PRESENT                  1       /**<@brief Video signal type is not present @hideinitializer*/
/**@}*/

/**
* @name Adaptive quantization
* @{
*/
#define HEVC_AQ_MODE_OFF                                    0       /**<@brief Disable adaptive quantization @hideinitializer*/
#define HEVC_AQ_MODE_EXTERNAL                               1       /**<@brief Adaptive quantization according to an external map @hideinitializer*/
#define HEVC_AQ_MODE_TEMPORAL                               2       /**<@brief Temporal adaptive quantization @hideinitializer*/
#define HEVC_AQ_MODE_RDO                                    3       /**<@brief Adaptive quantization without additional input, RDO only@hideinitializer*/
/**@}*/

/**
* @name Weighted pictures processing
* @{
*/
#define HEVC_WEIGHTED_REFS_NONE                             0       /**<@brief Disable weighted pictures processing @hideinitializer*/
#define HEVC_WEIGHTED_REFS_SAD_AC                           1       /**<@brief Enable weighted pictures processing @hideinitializer*/
/**@}*/

/**
* @name Input filtering
* @{
*/
#define HEVC_INPUT_FILTER_OFF                               0       /**<@brief Disable input filtering @hideinitializer*/
#define HEVC_INPUT_FILTER_MEDIAN                            1       /**<@brief Apply median filter by 3x3 kernel @hideinitializer*/
#define HEVC_INPUT_FILTER_MEAN                              2       /**<@brief Apply mean   filter by 3x3 kernel @hideinitializer*/

/**@}*/

/**
* @name HRD modes
* @{
*/
#define HEVC_HRD_OFF                                        0       /**<@brief Do not provide HRD conformance @hideinitializer*/
#define HEVC_HRD_STRICT                                     1       /**<@brief Provide strict HRD conformance, reencode on underflows until @ref hevc_v_layer::max_qp is reached (regardless of @ref hevc_v_settings::max_num_reencodings) @hideinitializer*/
#define HEVC_HRD_FAST                                       2       /**<@brief Try to provide HRD conformance, reencode on underflows until @ref hevc_v_layer::max_qp or @ref hevc_v_settings::max_num_reencodings is reached @hideinitializer*/

/**@}*/

/**
 *@name Wide ref options
 *@{
**/
#define HEVC_WIDE_REF_OFF                                   0       /**< @brief Referenced B-pictures have ordinary number of reference pictures @hideinitializer*/
#define HEVC_WIDE_REF_HIGH_ONLY                             1       /**< @brief High priority B-pictures have extended reference picture set @hideinitializer*/
#define HEVC_WIDE_REF_ALL                                   2       /**< @brief Referenced B-pictures have extended reference picture set @hideinitializer*/
/** @}*/

#endif // #if !defined (__ENC_HEVC_DEF_INCLUDED__)

