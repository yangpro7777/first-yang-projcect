/*****************************************************************************
 Created: 2019/12/04
 File name: sample_enc_hevc.cpp
 Purpose: command-line sample for H.265/HEVC encoder

 Copyright (c) 2020 MainConcept GmbH or its affiliates.  All rights reserved.

 MainConcept and its logos are registered trademarks of MainConcept GmbH or
 its affiliates. This software is protected by copyright law and international
 treaties. Unauthorized reproduction or distribution of any portion is
 prohibited by law.

*****************************************************************************/

#include "pass_controller.h"

#include <memory>

int main(int argc, char* argv[]) {
    // Random number generator is needed for dynamic IDR and user data
    // demonstration.
    srand(0);

    user_settings settings;
    if (settings.parse_command_line(argc, argv) < -1) {
        print_usage_info();
        return RETURN_CODE_NO_ARGUMENTS;
    }

    // If pass id = 0, when it's single pass mode. Values more than 0 means
    // that encoding will be launched in multi-pass.
    const int32_t start_pass = settings.multi_pass ? 1 : settings.run_pass;
    const int32_t pass_count = settings.multi_pass ? 2 : settings.run_pass;

    for (int32_t i = start_pass; i <= pass_count; ++i) {
        // Pass object requires a sufficiently large amount of memory,
        // so the best solution would be to allocate memory on the heap.
        std::unique_ptr<pass_controller_c> pass(new pass_controller_c(settings, i));
        int32_t result = pass->init_encoder_settings(argc, argv);
        if (HEVC_ERROR_NONE != result) {
            return result;
        }
        result = pass->run();
        if (HEVC_ERROR_NONE != result) {
            return result;
        }
    }
    return HEVC_ERROR_NONE;
}
