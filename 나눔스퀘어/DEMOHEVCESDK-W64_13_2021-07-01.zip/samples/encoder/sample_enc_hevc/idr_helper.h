#ifndef SAMPLE_ENC_HEVC_IDR_HELPER_H_
#define SAMPLE_ENC_HEVC_IDR_HELPER_H_

#include <set>

#include "auxinfo.h"
#include "bufstrm.h"
#include "user_settings.h"

using idr_list_t = std::set<int32_t>;

struct bufstream_multi : bufstream_tt {
    bufstream_multi();
    ~bufstream_multi();

    void update_force_idr_flag(int32_t frame_count, enc_options_storage& options);
    void check_requested_idr();

    static bufstream_multi* open_file_buf_write(const char* bs_filename, uint32_t bufsize,
        uint32_t layers, void (*DisplayError)(char* txt));
    static uint32_t hevc_auxinfo(bufstream_tt* bs, uint32_t offs, uint32_t info_id,
        void* info_ptr, uint32_t info_size);

    // Inheritance from bufstream_tt allows saving important objects inside and
    // support all functionality of base class.
    auxinfo_t      org_auxinfo = nullptr;
    gop_start_info last_gop_info;
    pic_start_info pic_info;
    idr_list_t     idr_pos_actual;
    idr_list_t     idr_pos_expected;
};

#endif // SAMPLE_ENC_HEVC_IDR_HELPER_H_
