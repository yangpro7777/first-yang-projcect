/********************************************************************
 Created: 2001/05/14 
 File name: buf_file.c
 Purpose: Buffered stream file IO implementation

 Copyright (c) 2015 MainConcept GmbH or its affiliates.  All rights reserved.
 
 MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
 This software is protected by copyright law and international treaties.  Unauthorized
 reproduction or distribution of any portion is prohibited by law.


*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef UNDER_CE
#define WIN32IO
#endif

#ifdef WIN32IO
  #include <windows.h>
#else
  #if !defined(__APPLE__) && !defined(__linux__) && !defined(__QNX__)
    #include <io.h>
  #else
    #include <unistd.h>
  #endif
  #include <fcntl.h>
  #include <sys/stat.h>
  #include <sys/types.h>
#endif

#include "auxinfo.h"
#include "buf_multi_file.h"

struct file_stream
{
#ifdef WIN32IO
    HANDLE io;
#else
    FILE *io;
#endif
    uint8_t *bfr;
    uint32_t idx;       // read-write index
    uint32_t bfr_size;  // allocated size
    uint32_t bfr_count; // filled size (for read)
    uint32_t chunk_size;
    uint64_t bytecount;
    uint64_t file_size;
#ifdef _BS_UNICODE
    wchar_t filename[_BS_MAX_PATH];
    wchar_t basename[_BS_MAX_PATH];
    wchar_t baseext[1024];
#else
    char filename[_BS_MAX_PATH];
    char basename[_BS_MAX_PATH];
    char baseext[1024];
#endif
};

//implementation structure
struct impl_stream
{
  struct file_stream file_struct[MAX_LAYERS];
  int32_t file_struct_idx;
  uint32_t layers;
};


// fw => write to file
// fr => read from file
static uint32_t fw_usable_bytes(bufstream_tt *bs)
{
  struct file_stream* p = &bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx];
  return p->bfr_size-p->idx;
}


//request the buffer with at least numbytes-bytes
static uint8_t *fw_request(bufstream_tt *bs, uint32_t numbytes)
{
  struct file_stream* p = &bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx];

  if (numbytes > p->bfr_size)
    return NULL;

  if(p->idx+numbytes <= p->bfr_size)
    return p->bfr+p->idx;

  if(p->idx)
  {
#ifdef WIN32IO
    DWORD n;
    WriteFile(p->io, p->bfr, p->idx, &n, NULL);
#else
    uint32_t n;
    n = (uint32_t) fwrite(p->bfr, sizeof(uint8_t), p->idx, p->io);
#endif
    if(n != p->idx)
    {
        //NOTE: print failed errno reason
        perror("bs fw_request() file write");
        return NULL;
    }
  }

  p->idx=0;
  return p->bfr;
}



//confirm numbytes-bytes filled in in requested after last "request"-call
static uint32_t fw_confirm(bufstream_tt *bs, uint32_t numbytes)
{
  bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].idx       += numbytes;
  bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].bytecount += numbytes;
  return numbytes;
}


//put/get numbytes-bytes into/from bufsteam
// fifo_w_sampput/fifo_r_sampget
static uint32_t fw_copybytes(bufstream_tt *bs, uint8_t *ptr, uint32_t numbytes)
{
  struct file_stream* p = &bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx];
#ifdef WIN32IO
  DWORD n;
#else
  uint32_t n;
#endif

  if(p->idx)
  {
#ifdef WIN32IO
    WriteFile(p->io, p->bfr, p->idx, &n, NULL);
#else
    n = (uint32_t) fwrite(p->bfr, sizeof(uint8_t), p->idx, p->io);
#endif
    if(n != p->idx)
    {
      p->idx=0;
      return 0;
    }
    p->idx=0;
  }

#ifdef WIN32IO
  WriteFile(p->io, ptr, numbytes, &n, NULL);
#else
  n = (uint32_t) fwrite(ptr, sizeof(uint8_t), numbytes, p->io);
#endif
  bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].bytecount += n;

  if(n != numbytes)
  {
    return 0;
  }

  return numbytes;
}



// maximum chunk-size in buffer-mode (i.e. for "request"-call)
static uint32_t fw_chunksize(bufstream_tt *bs)
{
  return bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].chunk_size;
}


static int32_t flush_buf(bufstream_tt *bs)
{

#ifdef WIN32IO
  if(!FlushFileBuffers(bs->Buf_IO_struct->io))
#else
  if(fflush(bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].io) || fflush(bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx ^ 1].io))
#endif
    return BS_ERROR;

  return BS_OK;
}


//inform bufstream about some additional info - for example
// to inform MUXer about encoding-units
static uint32_t fw_auxinfo(bufstream_tt *bs, uint32_t offs, uint32_t info_ID, void *info_ptr, uint32_t info_size)
{
  uint64_t *ptr;
#ifdef _BS_UNICODE
  wchar_t *ptr2;
#else
  char *ptr2;
#endif

  switch(info_ID)
  {
    case ID_PREFIX_START_CODE:
      {
        struct prefix_start_info *psi = (struct prefix_start_info *) info_ptr;
        bs->Buf_IO_struct->file_struct_idx = (psi->id < bs->Buf_IO_struct->layers && psi->id > 0) ? psi->id : 0;
      }
      break;

    case BYTECOUNT_INFO:
      {
        ptr = (uint64_t*)info_ptr;
        if(ptr && (info_size == sizeof(uint64_t)))
          *ptr = bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].bytecount;
      }
      break;

    case FLUSH_BUFFER:
      flush_buf(bs);
      break;

    case FILENAME_INFO:
      {
#ifdef _BS_UNICODE
        ptr2 = (wchar_t*)info_ptr;
        if(ptr2 && (info_size > wcslen(&bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx]->filename) * 2))
          wcscpy(ptr2, &bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx]->filename);
#else
        ptr2 = (char*)info_ptr;
        if(ptr2 && (info_size > strlen(bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].filename)))
          strcpy(ptr2, bs->Buf_IO_struct->file_struct[bs->Buf_IO_struct->file_struct_idx].filename);
#endif
        else
          return BS_ERROR;
      }
      break;
  }
  return BS_OK;
}

static void fw_done(bufstream_tt *bs, int32_t Abort)
{
  uint32_t idx;
  for(idx = 0; idx < bs->Buf_IO_struct->layers; idx++)
  {
    struct file_stream* p = &bs->Buf_IO_struct->file_struct[idx];
  
#ifdef WIN32IO
    DWORD n;
    WriteFile(p->io, p->bfr, p->idx, &n, NULL);
    CloseHandle(p->io);
#else
    fwrite(p->bfr, sizeof(uint8_t), p->idx, p->io);
    fclose(p->io);
#endif

    free(p->bfr);
//    free(p);
//    bs->Buf_IO_struct[idx] = NULL;
  }
  free(bs->Buf_IO_struct);
  bs->Buf_IO_struct = NULL;
}


static void fw_free(bufstream_tt *bs)
{
  if(bs->Buf_IO_struct)
    bs->done(bs,0);

  free(bs);
}


static int32_t init_write_common(bufstream_tt *bs, uint32_t bufsize)
{
  uint32_t idx;
  for(idx = 0; idx < bs->Buf_IO_struct->layers; idx++)
  {
    bs->Buf_IO_struct->file_struct[idx].bfr = (uint8_t*)malloc(bufsize);
    if(!bs->Buf_IO_struct->file_struct[idx].bfr)
    {
#ifdef WIN32IO
      CloseHandle(bs->Buf_IO_struct[idx]->io);
#else
      fclose(bs->Buf_IO_struct->file_struct[idx].io);
#endif
//      free(bs->Buf_IO_struct->file_struct[idx]);
      return BS_ERROR;
  }

    bs->Buf_IO_struct->file_struct[idx].bfr_size           = bufsize;
    bs->Buf_IO_struct->file_struct[idx].bfr_count          = 0;
    bs->Buf_IO_struct->file_struct[idx].chunk_size         = bufsize;
    bs->Buf_IO_struct->file_struct[idx].idx                = 0;
    bs->Buf_IO_struct->file_struct[idx].bytecount          = 0;

    bs->Buf_IO_struct->file_struct[idx].basename[0] = 0;
    bs->Buf_IO_struct->file_struct[idx].baseext[0]  = 0;
  }
  bs->usable_bytes = fw_usable_bytes;
  bs->request      = fw_request;
  bs->confirm      = fw_confirm;
  bs->copybytes    = fw_copybytes;
  bs->chunksize    = fw_chunksize;
  bs->free         = fw_free;
  bs->auxinfo      = fw_auxinfo;
  bs->done         = fw_done;
  bs->drive_ptr    = NULL;
  bs->drive        = NULL;

  bs->state        = NULL;
  bs->flags        = BS_FLAGS_DST;
  return BS_OK;
}


#ifdef _BS_UNICODE
int32_t init_file_buf_write(bufstream_tt *bs,
                            const wchar_t* bs_filename,
                            uint32_t bufsize, 
                            void (*DisplayError)(char *txt))
#else
int32_t init_file_buf_write(bufstream_tt *bs,
                            const char *bs_filename,
                            uint32_t bufsize, 
                            uint32_t layers,
                            void (*DisplayError)(char *txt))
#endif
{
  uint32_t idx;
  char basename[_BS_MAX_PATH];
  char baseext[_BS_MAX_PATH];
  char *ext;
  char filename[_BS_MAX_PATH];
  int32_t is_nul = strcmp(bs_filename, "nul") == 0;

  strncpy(basename, bs_filename, _BS_MAX_PATH);
  if (basename[_BS_MAX_PATH - 1] != '\0')
      return BS_ERROR;

  ext = strrchr(basename, '.');
  // ignore dots in directory names:
  if (strrchr(basename, '/') > ext || strrchr(basename, '\\') > ext)
      ext = NULL;

  if(ext) {
      strcpy(baseext, ext);
      *ext = '\0'; // terminate basename
  }
  else {
      baseext[0] = '\0';
  }

  bs->Buf_IO_struct = (struct impl_stream*)malloc(sizeof(struct impl_stream));

  if (!bs->Buf_IO_struct)
      return BS_ERROR;

  bs->Buf_IO_struct->file_struct_idx = 0;
  bs->Buf_IO_struct->layers = layers;

  for(idx = 0; idx < layers; idx++)
  {
      if (layers == 1 || is_nul)
          sprintf(filename, "%s%s", basename, baseext);
      else
          sprintf(filename, "%s_%d%s", basename, idx, baseext);

#ifdef WIN32IO
    bs->Buf_IO_struct->file_struct[idx].io = 
#ifdef _BS_UNICODE
      CreateFileW(filename, 
#else
      CreateFile(filename, 
#endif
                 GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS,
                 FILE_ATTRIBUTE_NORMAL,
                 NULL);
     if(bs->Buf_IO_struct->file_struct[idx].io == INVALID_HANDLE_VALUE)
#else
 #ifdef _BS_UNICODE
     bs->Buf_IO_struct->file_struct[idx].io = _wfopen(filename, L"wb");
 #else
  #if !defined(__QNX__)
     bs->Buf_IO_struct->file_struct[idx].io = fopen(filename, "wb");
  #else
     bs->Buf_IO_struct->file_struct[idx].io = fopen64(filename, "wb");
  #endif
 #endif
    if(!bs->Buf_IO_struct->file_struct[idx].io)
#endif
    {
//      free(bs->Buf_IO_struct[idx]);
      return BS_ERROR;
    }

#ifdef _BS_UNICODE
    wcscpy(bs->Buf_IO_struct->file_struct[idx].filename, filename);
#else
    strcpy(bs->Buf_IO_struct->file_struct[idx].filename, filename);
#endif
  }
  
  return init_write_common(bs, bufsize);
}


#ifdef _BS_UNICODE
bufstream_tt *open_file_buf_write(const wchar_t* bs_filename,
                                  uint32_t bufsize,
                                  uint32_t layers,
                                  void (*DisplayError)(char *txt))
#else
bufstream_tt *open_file_buf_write(const char *bs_filename,
                                  uint32_t bufsize,
                                  uint32_t layers,
                                  void (*DisplayError)(char *txt))
#endif
{
  bufstream_tt *p;
  p=(bufstream_tt*)malloc(sizeof(bufstream_tt));
  if(p)
  {
    if(BS_OK != init_file_buf_write(p, bs_filename, bufsize, layers, DisplayError))
    {
      free(p);
      p = NULL;
    }
  }
  return p;
}

void close_file_buf(bufstream_tt* bs,
                    int32_t Abort)
{
  bs->done(bs, Abort);
  bs->free(bs);
}
