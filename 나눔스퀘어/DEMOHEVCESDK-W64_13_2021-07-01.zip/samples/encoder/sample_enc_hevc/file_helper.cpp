/********************************************************************
 Created: 2017/07/17 
 File name: file_helper.cpp
 Purpose: file handling functions

 Copyright (c) 2017 MainConcept GmbH or its affiliates.  All rights reserved.
 
 MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
 This software is protected by copyright law and international treaties.  Unauthorized
 reproduction or distribution of any portion is prohibited by law.

*********************************************************************/

#include "file_helper.h"

#include <string.h>

#if !defined(_WIN32) && !defined(_WIN64)
# include <sys/mman.h>
#endif

void throw_generic_error(const char *message)
{
    throw std::system_error(errno, std::generic_category(), message);
}

#if defined(_WIN32) || defined(_WIN64)
void throw_system_error(const char *message)
{
    throw std::system_error(GetLastError(), std::system_category(), message);
}
#endif



//////////////////////////////////////////////////////////////////////////
// generic file

file_c::file_c(file_c&& f) {
    m_file = f.m_file;
    f.m_file = nullptr;
}

file_c::~file_c() {
    close_();
}

void file_c::close_(void)
{
    if (m_file) {
        if (FILENO(m_file) > 2)
            fclose(m_file);
        m_file = nullptr;
    }
}

bool file_c::open_for_write(const char *file_name)
{
    if (filename_not_empty(file_name)) {
        close_();
        m_file = fopen(file_name, "wb");
        return is_valid();
    }
    return false;
}

bool file_c::is_valid() const {
    return !!m_file;
}

bool file_c::open_for_read(const char *file_name)
{
    if (filename_not_empty(file_name)) {
        close_();

        if (!strcmp(file_name, "-")) {
#if defined(_WIN32) || defined(_WIN64)
            _setmode(_fileno(stdin), _O_BINARY);
#endif
            m_file = stdin;

        }
        else
            m_file = fopen(file_name, "rb");

        return is_valid();
    }
    return false;
}

void file_c::seek(size_t byte)
{
    if (is_valid())
        FSEEK64(m_file, byte, 0);
}

size_t file_c::get_size() const
{
    auto old_pos = FTELL64(m_file);
    FSEEK64(m_file, 0, 1); // go to end
    auto end_pos = FTELL64(m_file);
    FSEEK64(m_file, old_pos, 0); // restore position
    return end_pos;
}

file_c::operator bool() const {
    return is_valid();
}
file_c::operator FILE* () const {
    return m_file;
}

int32_t calc_num_frames(const file_c& file, size_t frame_size)
{
    if (file == stdin)
        return -1;

    size_t file_size = file.get_size();
    return int32_t(file_size / frame_size);
}


//////////////////////////////////////////////////////////////////////////
// reader interface

std::unique_ptr<frame_reader_i> frame_reader_i::create(const char *file_name, int32_t frame_size, int32_t start, int32_t durat, frame_reader_conf_t& config)
{
    try {
        file_c file;

        if (!file.open_for_read(file_name))
            throw_generic_error("Failed to fopen");

        stream_info_t info;
        info.file_name = file_name;
        info.frame_size = frame_size;
        int32_t num_frames = calc_num_frames(file, frame_size);
        
        start = start <= num_frames && start > 0 ? start - 1 : 0;
        info.start_frame = start;
        info.num_frames = num_frames - start;

        if (durat > 0 && durat < info.num_frames)
            info.num_frames = durat;

        if (info.num_frames < 0) { // stdin
            if (config.mmap) {
                printf("Warning: '-mmap' is not compatible with stdin, memory-mapping will not be used.\n");
                config.mmap = 0;
            }

            if (config.loop && !config.precache) {
                printf("Warning: '-loop' can be used with stdin only with '-pcache', stream will not be looped.\n");
                config.loop = 0;
            }

            if (start)
                printf("Warning: '-tstart' can be used with stdin, stream will encode from the very beginning.\n");
        }

        // file / mmap:
        std::unique_ptr<frame_reader_i> reader;
        if (config.mmap)
            reader.reset(new mmap_reader_c(std::move(file), info));
        else
            reader.reset(new file_reader_c(std::move(file), info));

        // precache:
        if (config.precache)
            reader.reset(new pcache_reader_c(std::move(reader)));

        // preload:
        if (config.preload)
            reader.reset(new preload_reader_c(std::move(reader), config.preload));

        bool inside_loop = config.loop && (reader->get_num_frames() < durat || durat <= 0);

        // async:
        if (config.async)
            reader.reset(new async_reader_c(std::move(reader), 15, inside_loop)); // test shows that buffering of 15 frames is enough

        // loop:
        if (inside_loop)
            reader.reset(new loop_reader_c(std::move(reader), durat));

        return reader;
    }
    catch (const std::system_error& e) {
        printf("\n%s error, code %d: %s\n", e.code().category().name(), e.code().value(), e.what());
        return nullptr;
    }
    catch (const std::exception& e) {
        printf("\nException occurred: %s\n", e.what());
        return nullptr;
    }
}


//////////////////////////////////////////////////////////////////////////
// file reader

file_reader_c::file_reader_c(file_c file, const stream_info_t& info):
    frame_reader_i(info), m_file(std::move(file))
{
    // allocate at least one buffer:
    m_free_buffers.push(alloc_buffer());
    if (start_frame)
        rewind();
}

file_reader_c::~file_reader_c()
{
}

uint8_t *file_reader_c::request()
{
    buffer_t buffer;
    if (!m_free_buffers.try_pop(buffer))
        buffer = alloc_buffer();

    // read frame:
    uint8_t *memory = buffer.get();
    size_t bytes_read = fread(memory, 1, frame_size, m_file);

    if (bytes_read != frame_size) {
        m_free_buffers.push(std::move(buffer));
        return nullptr;
    }

    m_busy_buffers.push(std::move(buffer));
    m_frames_requested++;
    return memory;
}

uint8_t *file_reader_c::release()
{
    buffer_t buffer = nullptr;
    if (m_busy_buffers.try_pop(buffer)) {
        auto result = buffer.get();
        m_free_buffers.push(std::move(buffer));
        m_frames_released++;
        return result;
    }
    return nullptr;
}

void file_reader_c::rewind()
{
    m_file.seek(frame_size*start_frame);
    frame_reader_i::rewind();
}

file_reader_c::buffer_t file_reader_c::alloc_buffer()
{
    uint8_t *memory = new uint8_t[frame_size];
    if (!memory)
        throw std::bad_alloc();
    return buffer_t(memory);
}


//////////////////////////////////////////////////////////////////////////
// memory mapped reader

mmap_reader_c::mmap_reader_c(file_c file, const stream_info_t& info):
    frame_reader_i(info), m_file(std::move(file)), m_mem_size(frame_size * calc_num_frames(m_file, frame_size))
{
    int fd = FILENO(m_file);

#if defined(_WIN32) || defined(_WIN64)
    HANDLE fh = (HANDLE)_get_osfhandle(fd);
    m_map = CreateFileMapping(fh, nullptr, PAGE_READONLY, 0, 0, nullptr);
    if (m_map == nullptr)
        throw_system_error("Failed to CreateFileMapping");

    m_mem = (uint8_t *)MapViewOfFile(m_map, FILE_MAP_READ, 0, 0, m_mem_size);
    if (m_mem == nullptr)
        throw_system_error("Failed to MapViewOfFile");

#else
    m_mem = (uint8_t *)mmap(nullptr, m_mem_size, PROT_READ, MAP_SHARED, fd, 0);
    if (m_mem == MAP_FAILED)
        throw_generic_error("Failed to mmap");
#endif 
}

mmap_reader_c::~mmap_reader_c()
{
#if defined(_WIN32) || defined(_WIN64)
    UnmapViewOfFile(m_mem);
    CloseHandle(m_map);
#else
    munmap(m_mem, m_mem_size);
#endif
}

uint8_t *mmap_reader_c::request()
{
    int32_t index = start_frame + m_frames_requested++;
    return m_mem + index * frame_size;
}

uint8_t *mmap_reader_c::release()
{
    int32_t index = start_frame + m_frames_released++;
    return m_mem + index * frame_size;
}

//////////////////////////////////////////////////////////////////////////
// pre-loading reader

preload_reader_c::preload_reader_c(std::unique_ptr<frame_reader_i> reader, int32_t preload_type) :
    wrapping_reader_c(std::move(reader))
{
    preload = unload = no_action;
    switch (preload_type) {
    case 1:
        preload = will_need;
        unload = dont_need;
        break;
    case 2:
        preload = page_load;
        unload = dont_need;
        break;
    case 3:
        preload = page_lock;
        unload = page_unlock;
        break;
    }
}

uint8_t *preload_reader_c::request()
{
    auto result = m_reader->request_frame();
    if (result) {
        m_frames_requested++;
        preload(result, frame_size);
    }
    return result;
}

uint8_t *preload_reader_c::release()
{
    auto result = m_reader->release_frame();
    if (result) {
        m_frames_released++;
        unload(result, frame_size);
    }
    return result;
}

void preload_reader_c::rewind()
{
    m_reader->rewind();
    frame_reader_i::rewind();
}

int preload_reader_c::no_action(void *memory, size_t size)
{
    return 0;
}

static int page_load_impl(void *memory, size_t size)
{
    constexpr size_t PAGE_SIZE = 4096;

    int sum = 0;
    auto bytes = (const uint8_t *)memory;
    for (size_t offset = 0; offset < size; offset += PAGE_SIZE) {
        sum += bytes[offset];
    }
    return sum;
}

int preload_reader_c::page_load(void *memory, size_t size)
{
    return page_load_impl(memory, size);
}

#if defined(_WIN32) || defined(_WIN64)

struct MEMORY_RANGE {
    PVOID VirtualAddress;
    SIZE_T NumberOfBytes;
};

typedef BOOL (*prefetch_fn)(HANDLE, ULONG_PTR, MEMORY_RANGE *, ULONG);

BOOL page_prefetch(HANDLE, ULONG_PTR, MEMORY_RANGE *entry, ULONG)
{
    return page_load_impl(entry->VirtualAddress, entry->NumberOfBytes);
}

prefetch_fn get_prefetch_fn()
{
    HMODULE dll = GetModuleHandle("Kernel32.dll");
    auto address = GetProcAddress(dll, "PrefetchVirtualMemory");
    if (address) {
        printf("preload: using PrefetchVirtualMemory system call\n");
        return prefetch_fn(address);
    }
    else {
        printf("preload: PrefetchVirtualMemory is not available, using per-page prefetching\n");
        return page_prefetch;
    }
}

int preload_reader_c::will_need(void *memory, size_t size)
{
    static HANDLE process = GetCurrentProcess();
    static prefetch_fn prefetch = get_prefetch_fn();
    MEMORY_RANGE entry = { memory, size };
    return prefetch(process, 1, &entry, 0);
}

int preload_reader_c::dont_need(void *memory, size_t size)
{
    return 0;
}

int preload_reader_c::page_lock(void *memory, size_t size)
{
    return VirtualLock(memory, size);
}

int preload_reader_c::page_unlock(void *memory, size_t size)
{
    return VirtualUnlock(memory, size);
}


#else

int preload_reader_c::will_need(void *memory, size_t size)
{
    return madvise(memory, size, MADV_WILLNEED);
}

int preload_reader_c::dont_need(void *memory, size_t size)
{
    return madvise(memory, size, MADV_DONTNEED);
}

int preload_reader_c::page_lock(void *memory, size_t size)
{
    return mlock(memory, size);
}

int preload_reader_c::page_unlock(void *memory, size_t size)
{
    return munlock(memory, size);
}

#endif


//////////////////////////////////////////////////////////////////////////
// pre-caching reader

pcache_reader_c::pcache_reader_c(std::unique_ptr<frame_reader_i> reader):
    wrapping_reader_c(std::move(reader))
{
    if (num_frames > 0) {
        // read known number of frames:
        m_frames.reserve(num_frames);
        for (int32_t i = 0; i < num_frames; i++) {
            uint8_t *buffer = m_reader->request_frame();
            if (!buffer)
                throw std::runtime_error("Could not read all necessary frames");
            m_frames.push_back(buffer);
        }
    }
    else {
        // read unknown number of frames:
        while (uint8_t *buffer = m_reader->request_frame()) {
            m_frames.push_back(buffer);
        }
        num_frames = (int32_t) m_frames.size();
    }
}

pcache_reader_c::~pcache_reader_c()
{
}

uint8_t *pcache_reader_c::request()
{
    return m_frames[m_frames_requested++];
}

uint8_t *pcache_reader_c::release()
{
    // underlying reader frames are actually released only on destruction
    // this allows to effectively loop across them
    return m_frames[m_frames_released++];
}


//////////////////////////////////////////////////////////////////////////
// asynchronous reader

async_reader_c::async_reader_c(std::unique_ptr<frame_reader_i> reader, int32_t num_async_frames, bool inside_loop) :
    wrapping_reader_c(std::move(reader)), m_looped(inside_loop), m_length(num_async_frames)
{
    // start reading thread:
    m_thread = std::thread([this] { this->read_ahead(); });
}

async_reader_c::~async_reader_c()
{
    m_frames.abort();
    m_thread.join();
}

void async_reader_c::read_ahead()
{
    try {
        while (true) {
            // read frame:
            uint8_t *buffer = m_reader->request_frame();

            // rewind if looped
            if (!buffer && m_looped) {
                m_reader->rewind();
                buffer = m_reader->request_frame();
            }

            if (!buffer) {
                break;
            }

            // save frame in a queue:
            m_frames.push(std::move(buffer), m_length);
        }
    }
    catch (const std::exception&) {
        // pass
    }
}

uint8_t *async_reader_c::request()
{
    auto result = m_frames.pop();
    m_frames_requested += result != nullptr;
    return result;
}

uint8_t *async_reader_c::release()
{
    auto result = m_reader->release_frame();
    m_frames_released += result != nullptr;
    return result;
}


//////////////////////////////////////////////////////////////////////////
// looping reader

loop_reader_c::loop_reader_c(std::unique_ptr<frame_reader_i> reader, int32_t duration):
    wrapping_reader_c(std::move(reader))
{
    num_frames = duration;
}

loop_reader_c::~loop_reader_c()
{
}

uint8_t *loop_reader_c::request()
{
    if (m_frames_requested % m_reader->get_num_frames() == 0)
        m_reader->rewind();

    auto result = m_reader->request_frame();
    m_frames_requested += result != nullptr;
    return result;
}

uint8_t *loop_reader_c::release()
{
    auto result = m_reader->release_frame();
    m_frames_released += result != nullptr;
    return result;
}
