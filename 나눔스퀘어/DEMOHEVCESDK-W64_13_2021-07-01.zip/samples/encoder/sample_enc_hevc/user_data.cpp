#include "user_data.h"
#include <algorithm>

const unsigned char RANDOM_UUID[16] = { 0x25,0x06,0x03,0x14,0x49,0xE6,0x4B,0x18,0x8D,0x06,0x19,0xB2,0xE2,0x26,0x61,0x1C };
const unsigned char PIC_NUMBER_UUID[16] = { 0xD4,0xDA,0xD3,0xAC,0x93,0xE6,0x4E,0x51,0xBE,0x6C,0x9E,0xB3,0x0E,0x82,0x0C,0x05 };

unregistered_user_data_t::unregistered_user_data_t() {
    memset(reserved, 0, sizeof(reserved));
    type = USER_DATA_UNREGISTERED;
    size = sizeof(storage);
    flags = 0;
    lock = 0;
    data = storage;
}

void unregistered_user_data_t::init_random_ud() {
    memcpy(storage, RANDOM_UUID, sizeof(RANDOM_UUID));
    *(int32_t*)(storage + sizeof(RANDOM_UUID)) = (int32_t)rand();
}

void unregistered_user_data_t::init_pic_number_ud(const int32_t number) {
    memcpy(storage, PIC_NUMBER_UUID, sizeof(PIC_NUMBER_UUID));
    *(int32_t*)(storage + sizeof(PIC_NUMBER_UUID)) = number;
}

void unregistered_user_data_t::print_pic_number_info() {
    const int32_t picture_nr = *(int32_t*)(storage + sizeof(PIC_NUMBER_UUID));
    char buffer[256];
    int32_t off = sprintf(buffer, "\nPicture %d SEI unregistered hex:", picture_nr);
    for (uint32_t i = 0; i < size; ++i) {
        off += sprintf(buffer + off, "%x", storage[i]);
    }
    off += sprintf(buffer + off, "\n");
    fflush(stdout);
    fputs(buffer, stdout);
    fflush(stdout);
}

unregistered_user_data_t* unregistered_user_data_t::get_vacant_user_data(user_data_pool_t& pool) {
    unregistered_user_data_t* data = nullptr;
    auto it = std::find_if(pool.begin(), pool.end(),
        [](const unregistered_user_data_t& data) { return (0 == data.lock); });
    if (pool.end() == it) {
        pool.emplace_back();
        data = &pool.back();
    } else {
        data = &(*it);
    }
    data->lock++;
    return data;
}

void unregistered_user_data_t::process_pool(user_data_pool_t& pool, int32_t frame_count, enc_options_storage& options) {
    auto first_ud = get_vacant_user_data(pool);
    auto second_ud = get_vacant_user_data(pool);
    auto third_ud = get_vacant_user_data(pool);

    first_ud->init_random_ud();
    second_ud->init_random_ud();
    third_ud->init_pic_number_ud(frame_count);
    third_ud->print_pic_number_info();

    options.push_back(EXT_OPT_PARAM_PIC_UD, first_ud);
    options.push_back(EXT_OPT_PARAM_PIC_UD, second_ud);
    options.push_back(EXT_OPT_PARAM_PIC_UD, third_ud);

    first_ud->lock--;
    second_ud->lock--;
    third_ud->lock--;
}
