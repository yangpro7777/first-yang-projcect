#include "user_settings.h"

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>

#include <string>

#include "enc_hevc.h"
#include "sample_common_args.h"

enum custom_idc_e {
    IDC_CHAPTER_LIST_FILE = IDC_CUSTOM_START_ID + 1,
    IDC_QP_MAP_FILE,
    IDC_DYNAMIC_IDR,
    IDC_MPASS_STAT_FILE,
    IDC_INFINITE_LOOP,
    IDC_PRECACHE_INPUT,
    IDC_PREF_LVL_FIRST_PASS,
    IDC_TWO_PASS_ENCODING,
    IDC_ASYNC_READER,
    IDC_USER_DATA,
    IDC_MEMORY_MAP_READER,
    IDC_PRELOAD_READING,
    IDC_STRICT_PRESET,
};

static const arg_item_desc_t HEVC_ARGS[] = {
    { IDI_PRESET, { "main",        "" }, ItemTypeNoArg, HEVC_MAIN,        "HEVC Main Profile" },
    { IDI_PRESET, { "main10",      "" }, ItemTypeNoArg, HEVC_MAIN_10,     "HEVC Main 10 Profile" },
    { IDI_PRESET, { "4k",          "" }, ItemTypeNoArg, HEVC_4K,          "HEVC 4K Profile" },
    { IDI_PRESET, { "4k10",        "" }, ItemTypeNoArg, HEVC_4K_10,       "HEVC 4K 10-bit Profile" },
    { IDI_PRESET, { "main_422_10", "" }, ItemTypeNoArg, HEVC_MAIN_422_10, "HEVC Main 4:2:2 10 Profile"},

    { IDI_PRESET, { "hls1",        "" }, ItemTypeNoArg, HEVC_HLS_L1,  "HLS Video for Apple Devices Level 1 Profile" },
    { IDI_PRESET, { "hls2",        "" }, ItemTypeNoArg, HEVC_HLS_L2,  "HLS Video for Apple Devices Level 2 Profile" },
    { IDI_PRESET, { "hls3",        "" }, ItemTypeNoArg, HEVC_HLS_L3,  "HLS Video for Apple Devices Level 3 Profile" },
    { IDI_PRESET, { "hls4",        "" }, ItemTypeNoArg, HEVC_HLS_L4,  "HLS Video for Apple Devices Level 4 Profile" },
    { IDI_PRESET, { "hls5",        "" }, ItemTypeNoArg, HEVC_HLS_L5,  "HLS Video for Apple Devices Level 5 Profile" },
    { IDI_PRESET, { "hls6",        "" }, ItemTypeNoArg, HEVC_HLS_L6,  "HLS Video for Apple Devices Level 6 Profile" },
    { IDI_PRESET, { "hls7",        "" }, ItemTypeNoArg, HEVC_HLS_L7,  "HLS Video for Apple Devices Level 7 Profile" },
    { IDI_PRESET, { "hls8",        "" }, ItemTypeNoArg, HEVC_HLS_L8,  "HLS Video for Apple Devices Level 8 Profile" },
    { IDI_PRESET, { "hls9",        "" }, ItemTypeNoArg, HEVC_HLS_L9,  "HLS Video for Apple Devices Level 9 Profile" },
    { IDI_PRESET, { "hls10",       "" }, ItemTypeNoArg, HEVC_HLS_L10, "HLS Video for Apple Devices Level 10 Profile" },
    { IDI_PRESET, { "hls11",       "" }, ItemTypeNoArg, HEVC_HLS_L11, "HLS Video for Apple Devices Level 11 Profile" },
    { IDI_PRESET, { "hls12",       "" }, ItemTypeNoArg, HEVC_HLS_L12, "HLS Video for Apple Devices Level 12 Profile" },

    { IDI_PRESET, { "dash1",       "" }, ItemTypeNoArg, HEVC_DASH_L1,  "DASH Level 1 Profile" },
    { IDI_PRESET, { "dash2",       "" }, ItemTypeNoArg, HEVC_DASH_L2,  "DASH Level 2 Profile" },
    { IDI_PRESET, { "dash3",       "" }, ItemTypeNoArg, HEVC_DASH_L3,  "DASH Level 3 Profile" },
    { IDI_PRESET, { "dash4",       "" }, ItemTypeNoArg, HEVC_DASH_L4,  "DASH Level 4 Profile" },
    { IDI_PRESET, { "dash5",       "" }, ItemTypeNoArg, HEVC_DASH_L5,  "DASH Level 5 Profile" },
    { IDI_PRESET, { "dash6",       "" }, ItemTypeNoArg, HEVC_DASH_L6,  "DASH Level 6 Profile" },
    { IDI_PRESET, { "dash7",       "" }, ItemTypeNoArg, HEVC_DASH_L7,  "DASH Level 7 Profile" },
    { IDI_PRESET, { "dash8",       "" }, ItemTypeNoArg, HEVC_DASH_L8,  "DASH Level 8 Profile" },
    { IDI_PRESET, { "dash9",       "" }, ItemTypeNoArg, HEVC_DASH_L9,  "DASH Level 9 Profile" },
    { IDI_PRESET, { "dash10",      "" }, ItemTypeNoArg, HEVC_DASH_L10, "DASH Level 10 Profile" },
    { IDI_PRESET, { "dash11",      "" }, ItemTypeNoArg, HEVC_DASH_L11, "DASH Level 11 Profile" },
    { IDI_PRESET, { "dash12",      "" }, ItemTypeNoArg, HEVC_DASH_L12, "DASH Level 12 Profile" },

    { IDI_PRESET, { "arib_8k",     "" }, ItemTypeNoArg, HEVC_ARIB_8K, "ARIB STD-B32 8K encoding" },

    { IDC_CHAPTER_LIST_FILE,   { "chl",          "chapter_list" }, ItemTypeString, 0, "Chapter list file"},
    { IDC_QP_MAP_FILE,         { "qp_map",       ""             }, ItemTypeString, 0, "External QP map file"},
    { IDC_DYNAMIC_IDR,         { "dynamic_idr",  ""             }, ItemTypeNoArg,  1, "Dynamic IDR check" },
    { IDC_MPASS_STAT_FILE,     { "mpstat",       "mpass_stat"   }, ItemTypeString, 0, "Multi pass statistics file" },
    { IDC_INFINITE_LOOP,       { "loop",         ""             }, ItemTypeNoArg,  1, "Infinite loop" },
    { IDC_PRECACHE_INPUT,      { "pcache",       ""             }, ItemTypeNoArg,  1, "Pre-cache input" },
    { IDC_PREF_LVL_FIRST_PASS, { "perf1",        ""             }, ItemTypeInt,    1, "Performance level for first pass" },
    { IDC_TWO_PASS_ENCODING,   { "2pass",        ""             }, ItemTypeNoArg,  1, "Run two-pass encoding" },
    { IDC_ASYNC_READER,        { "async_reader", "async"        }, ItemTypeNoArg,  1, "Use asynchronous frame reading" },
    { IDC_USER_DATA,           { "user_data",    "ud"           }, ItemTypeNoArg,  1, "Put user data" },
    { IDC_MEMORY_MAP_READER,   { "mmap_reader",  "mmap"         }, ItemTypeNoArg,  1, "Use memory-mapped frame reading" },
    { IDC_PRELOAD_READING,     { "preload",      ""             }, ItemTypeInt,    1, "Use preload frame reading" },
    { IDC_STRICT_PRESET,       { "strict",       ""             }, ItemTypeNoArg,  1, "Strict preset validation" },
};

static const int32_t HEVC_ARGS_COUNT = sizeof(HEVC_ARGS) / sizeof(HEVC_ARGS[0]);

static const char* CONSOLE_USAGE_MESSAGE =
    "Usage:"
    "  sample_enc_hevc -<fourcc> -w <width> -h <height> -f <frame_rate>\n"
    "-v <input_file> -o <output_file> [options]\n"
    "\n"
    "Options:\n"
    "  -b <bitrate>           target bit rate.\n"
    "  -<preset>              predefined preset:\n"
    "                           main [default];\n"
    "                           main10;\n"
    "                           4k;\n"
    "                           4k10;\n"
    "                           main_422_10;\n"
    "                           hls1; hls2; hls3; hls4; hls5; hls6; hls7;\n"
    "                           hls8; hls9; hls10; hls11; hls12;\n"
    "                           dash1; dash2; dash3; dash4; dash5; dash6;\n"
    "                           dash7; dash8; dash9; dash10; dash11; dash12;\n"
    "                           arib_8k;\n"
    "  -perf <level>          a performance level [0-31].\n"
    "                         Predefined performance levels:\n"
    "                           1:  Fastest;\n"
    "                           8:  Fast;\n"
    "                           15: Balanced [default];\n"
    "                           20: Better;\n"
    "                           30: Best quality;\n"
    "  -c <file path>         an configuration file path.\n"
    "  -lf  <file path>       CFL license file path.\n"
    "  -chl <file path>       an external chapter list file path.\n"
    "  -qp_map <file path>    an external qp_maps file path.\n"
    "  -st <file path>        coding statistics file path.\n"
    "  -preview <file path>   reconstructed pictures file path.\n"
    "  -original <file path>  original pictures file path.\n"
    "  -mpass <pass>          specifies the pass to run for multi-pass\n"
    "                         encoding.\n"
    "  -mpstat <file path>    specifies a statistics file for multi-pass\n"
    "                         encoding.\n"
    "  -perf1 <level>         performance level for the first run at 2-pass\n"
    "                         encoding.\n"
    "  -2pass                 two-pass encoding in a single run.\n"
    "  -async_reader          use asynchronous reader.\n"
    "  -user_data             put per-frame user data.\n";


void print_usage_info() {
    printf("%s", CONSOLE_USAGE_MESSAGE);

    const char* acc_type[] = { "NONE", "IQSV", "NVENC" };
    const char* acc_mode[] = { "FULL", "DRIVEN", "HYBRID" };

    int32_t num_acc = hevcOutVideoEnumAcceleration(nullptr, 0);
    auto acc_list = std::unique_ptr<hevc_acceleration_info_tt[]>(new hevc_acceleration_info_tt[num_acc]);
    num_acc = hevcOutVideoEnumAcceleration(acc_list.get(), num_acc);
    if (num_acc == 0) {
        printf("hevcOutVideoEnumAcceleration: invalid argument\n");
        return;
    }

    printf("\nAvailable accelerations:\n%-32s %s\t%s\t%s\n", "ACCELERATION TITLE", "TYPE", "MODE", "DEVICE ID");
    for (int32_t i = 0; i < num_acc; i++)
        printf("%-32s %s\t%s\t%d\n", acc_list[i].title, acc_type[acc_list[i].acceleration], acc_mode[acc_list[i].mode], acc_list[i].device_idx);
}


void user_settings::apply_default_settings() {
    apply_default_single(mode);
    apply_default_single(frames_to_enc);
    apply_default_single(start_frame_to_enc);
    apply_default_single(dynamic_idr_check);
    apply_default_single(run_pass);
    apply_default_single(multi_pass);
    apply_default_single(put_user_data);
    apply_default_single(reader_conf.async);
    apply_default_single(reader_conf.mmap);
    apply_default_single(reader_conf.loop);
    apply_default_single(reader_conf.preload);
    apply_default_single(reader_conf.precache);
    apply_default_single(ext_mem_alloc);
}

inline void user_settings::apply_default_single(int32_t& item) {
    if (item == ITEM_NOT_INIT) {
        item = 0;
    }
}

int32_t user_settings::parse_command_line(int32_t argc, char* argv[]) {
    arg_item_t params[] = {
        { IDS_LIC_FILE,            0, &license_filename },
        { IDS_EXT_MEM_ALLOC,       0, &ext_mem_alloc },
        { IDS_VIDEO_FILE,          1, &in_file },
        { IDS_OUTPUT_FILE,         1, &out_file },
        { IDI_BITRATE,             0, &bit_rate },
        { IDS_CONFIG_FILE,         0, &cfg_file },
        { IDI_PRESET,              0, &video_type },
        { IDS_REC_FILE,            0, &rec_file },
        { IDS_ORG_FILE,            0, &org_file },
        { IDS_STAT_FILE,           0, &stat_file },
        { IDI_V_WIDTH,             1, &width },
        { IDI_V_HEIGHT,            1, &height },
        { IDN_V_FOURCC,            1, &fourcc },
        { IDD_V_FRAMERATE,         0, &frame_rate },
        { IDI_V_PERFORMANCE,       0, &perf },
        { IDI_V_MULTIPASS_MODE,    0, &run_pass },
        { IDI_V_START_FRAME,       0, &start_frame_to_enc },
        { IDI_V_DURATION,          0, &frames_to_enc },
        { IDI_MODE,                0, &mode },
        { IDC_CHAPTER_LIST_FILE,   0, &chl_file },
        { IDC_QP_MAP_FILE,         0, &qp_map_file_name },
        { IDC_DYNAMIC_IDR,         0, &dynamic_idr_check },
        { IDC_MPASS_STAT_FILE,     0, &pass_stat_file },
        { IDC_INFINITE_LOOP,       0, &reader_conf.loop },
        { IDC_PRECACHE_INPUT,      0, &reader_conf.precache },
        { IDC_PREF_LVL_FIRST_PASS, 0, &perf1 },
        { IDC_TWO_PASS_ENCODING,   0, &multi_pass },
        { IDC_ASYNC_READER,        0, &reader_conf.async },
        { IDC_USER_DATA,           0, &put_user_data },
        { IDC_MEMORY_MAP_READER,   0, &reader_conf.mmap },
        { IDC_PRELOAD_READING,     0, &reader_conf.preload },
        { IDC_STRICT_PRESET,       0, &strict_preset },
    };
    const int32_t params_count = sizeof(params) / sizeof(params[0]);
    const int32_t result = parse_args(argc - 1, argv + 1, params_count, params, HEVC_ARGS, HEVC_ARGS_COUNT);
    apply_default_settings();
    return result;
}

void enc_options_storage::push_back(ext_opt_id id, void* data) {
    if (m_cur_option < MAX_FRAME_OPTIONS - 1) {
        m_frame_options[m_cur_option++] = { id, data };
    }
}

enc_option_t* enc_options_storage::get_options() {
    return m_frame_options;
}
