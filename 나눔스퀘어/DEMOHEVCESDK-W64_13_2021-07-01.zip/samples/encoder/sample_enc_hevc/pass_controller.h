#ifndef SAMPLE_ENC_HEVC_PASS_CONTROLLER_H_
#define SAMPLE_ENC_HEVC_PASS_CONTROLLER_H_

#include <limits.h>

#include "dump_features.h"
#include "idr_helper.h"
#include "meta_file.h"
#include "user_settings.h"

class callback_handler_c {
public:
    ~callback_handler_c();

    static void progress_printf(context_t context, int32_t percent, const char* fmt, ...);
    static void message_printf(context_t context, const char* fmt, ...);
    static void statistics_printf(context_t context, const char* fmt, ...);
    static void* mmalloc(context_t context, size_t size);
    static void  mfree(context_t context, void* ptr);
    static void* mrealloc(context_t context, void* ptr, size_t size);
    static int32_t get_license_data(context_t context, void* pData);

protected:
    FILE* m_stat_file = nullptr;
    std::string m_license_filename;
};

class pass_controller_c : public callback_handler_c {
public:
    pass_controller_c(const user_settings& user_settings, int32_t pass);
    ~pass_controller_c();

    int32_t init_encoder_settings(int32_t argc, char* argv[]);
    int32_t run();

private:
    void init_callbacks();

    static hevc_chapter_tt* read_and_make_chapter_list_from_file(const char* fn);

    int32_t read_input(int32_t argc, char* argv[]);
    int32_t read_params_from_command_line(int32_t argc, const char* const argv[]);
    int32_t attach_features();
    int32_t process_frames(std::unique_ptr<frame_reader_i>& frame_reader);
    void print_error(const char* message, ...);
    bool attach_chapter_list(int32_t& opt_num);
    bool attach_mpass_metadata(int32_t& opt_num);
    void attach_auxinfo(int32_t& opt_num);

    // input parameters
    const user_settings&     m_user_settings;
    frame_colorspace_info_tt m_cs_info;
    callbacks_t              m_callbacks;
    int32_t                  m_pass;

    frame_reader_conf_t m_reader_conf;
    hevc_v_settings     m_v_settings;
    hevc_v_encoder*     m_v_encoder = nullptr;
    file_c              m_qp_maps_file;

    // run
    enc_option_t         m_options[10];
    metadata_storage_tt* m_md_storage = nullptr;
    hevc_chapter_tt*     m_chapter_list = nullptr;
    bufstream_multi*     m_videobs = nullptr;
    dump_c               m_org_dump;
    dump_c               m_rec_dump;
};

#endif // SAMPLE_ENC_HEVC_PASS_CONTROLLER_H_
