/*****************************************************************************
 Created: 2017/07/17 
 File name: file_helper.cpp
 Purpose: file handling functions

 Copyright (c) 2019 MainConcept GmbH or its affiliates. All rights reserved.
 
 MainConcept and its logos are registered trademarks of MainConcept GmbH or
 its affiliates. This software is protected by copyright law and international
 treaties. Unauthorized reproduction or distribution of any portion is
 prohibited by law.

*****************************************************************************/
#ifndef SAMPLE_ENC_HEVC_FILE_HELPER_H_
#define SAMPLE_ENC_HEVC_FILE_HELPER_H_

#include <atomic>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <thread>
#include <vector>

#if defined(_WIN32) || defined(_WIN64)
#include <fcntl.h>
#include <io.h>
#include <Windows.h>
#endif

#if defined(_WIN32) || defined(_WIN64)
#define FTELL64(f)          _ftelli64(f)
#define FSEEK64(f, offset, end)  _fseeki64(f, offset, end ? SEEK_END : SEEK_SET)
#define FILENO(f)           _fileno(f)
#else
#define FTELL64(f)          ftello(f)
#define FSEEK64(f, offset, end)  fseeko(f, offset, end ? SEEK_END : SEEK_SET)
#define FILENO(f)           fileno(f)
#endif

static inline bool filename_not_empty(const char* str) {
    if (str) {
        return str[0];
    }
    return false;
}

class file_c
{
private:
    FILE *m_file;
    void close_(void);

public:
    file_c() : m_file(nullptr) {}
    file_c(const file_c& f) = delete;
    file_c(file_c&& f);
    ~file_c();

    bool open_for_write(const char *file_name);
    bool open_for_read(const char *file_name);
    bool is_valid() const;

    void seek(size_t byte = 0);
    size_t get_size() const;

    operator bool() const;
    operator FILE* () const;
};

template <typename T>
class shared_queue
{
public:

    shared_queue() {
        aborted = 0;
    }

    T pop() {
        std::unique_lock<std::mutex> lock(mutex);
        while (queue.empty()) {
            pushed.wait(lock);
            check_abort();
        }
        T item = std::move(queue.front());
        queue.pop();
        popped.notify_all();
        return item;
    }

    void pop(T& item) {
        std::unique_lock<std::mutex> lock(mutex);
        while (queue.empty()) {
            pushed.wait(lock);
            check_abort();
        }
        item = std::move(queue.front());
        queue.pop();
        popped.notify_all();
    }

    bool try_pop(T& item) {
        std::unique_lock<std::mutex> lock(mutex);
        if (queue.empty())
            return false;
        item = std::move(queue.front());
        queue.pop();
        popped.notify_all();
        return true;
    }

    void push(T&& item) {
        std::unique_lock<std::mutex> lock(mutex);
        queue.push(std::move(item));
        lock.unlock();
        pushed.notify_all();
    }

    void push(T&& item, int max_size) {
        std::unique_lock<std::mutex> lock(mutex);
        while (queue.size() >= max_size) {
            popped.wait(lock);
            check_abort();
        }
        queue.push(std::move(item));
        lock.unlock();
        pushed.notify_all();
    }

    void abort()
    {
        aborted = 1;
        pushed.notify_all();
        popped.notify_all();
    }

private:
    std::queue<T> queue;
    std::mutex mutex;
    std::condition_variable pushed;
    std::condition_variable popped;
    std::atomic<int> aborted;

    void check_abort() {
        if (aborted)
            throw std::logic_error("shared_queue aborted");
    }
};


//
// frame reader interface
//

struct stream_info_t
{
    const char *file_name;
    size_t      frame_size;
    int32_t     num_frames;
    int32_t     start_frame;
};

struct frame_reader_conf_t
{
    int32_t mmap;
    int32_t precache;
    int32_t preload;
    int32_t async;
    int32_t loop;
};

class frame_reader_i : protected stream_info_t
{
public:
    frame_reader_i(const stream_info_t& info) :
        stream_info_t(info) {}
    virtual        ~frame_reader_i() {}

    // returns non-nullptr on success, nullptr on failure
    inline uint8_t *request_frame() {
        if (m_frames_requested >= num_frames && num_frames > 0)
            return nullptr;
        return request();
    }

    // returns true on success, false on failure
    inline uint8_t *release_frame() {
        if (m_frames_released >= num_frames && num_frames > 0)
            return nullptr;
        return release();
    }

    virtual void rewind() {
        m_frames_requested = 0;
        m_frames_released  = 0;
    }

    virtual bool is_valid() { return true; }
    virtual int32_t get_num_frames() { return num_frames; }

    // factory method:
    static std::unique_ptr<frame_reader_i> create(const char *file_name,
        int32_t frame_size, int32_t start, int32_t durat,
        frame_reader_conf_t& config);

protected:

    virtual uint8_t *request() = 0;
    virtual uint8_t *release() = 0;

    int32_t         m_frames_requested = 0;
    int32_t         m_frames_released = 0;
};

//
// simple file reader
//

// implementation allows two usage variants:
// 1) single thread calls both request_frame and release_frame
// 2) one thread calls request_frame, another thread calls release_frame
class file_reader_c : public frame_reader_i
{
public:
    file_reader_c(file_c file, const stream_info_t& info);
    virtual        ~file_reader_c();

    uint8_t *       request() override;
    uint8_t *       release() override;
    void            rewind() override;
    bool            is_valid() override { return m_file.is_valid(); }

private:
    file_c          m_file;

    typedef std::unique_ptr<uint8_t[]> buffer_t;

    shared_queue<buffer_t>  m_free_buffers;
    shared_queue<buffer_t>  m_busy_buffers;

    buffer_t alloc_buffer();
};

//
// memory mapped reader
//

class mmap_reader_c : public frame_reader_i
{
public:
    mmap_reader_c(file_c file, const stream_info_t& info);
    virtual        ~mmap_reader_c();

    uint8_t *       request() override;
    uint8_t *       release() override;

private:
    file_c          m_file;
    uint8_t *       m_mem;
    size_t          m_mem_size;
    
#if defined(_WIN32) || defined(_WIN64)
    HANDLE          m_map;
#endif
};


//
// abstract reader wrapper
//

class wrapping_reader_c : public frame_reader_i
{
public:
    wrapping_reader_c(std::unique_ptr<frame_reader_i> reader) :
        frame_reader_i(*reader), m_reader(std::move(reader)) {}
    virtual ~wrapping_reader_c() {}

    bool            is_valid() override { return m_reader->is_valid(); }

    // other functions should be implemented by successor classes

protected:
    std::unique_ptr<frame_reader_i> m_reader;
};


//
// pre-loading reader
//

class preload_reader_c : public wrapping_reader_c
{
public:
    preload_reader_c(std::unique_ptr<frame_reader_i> reader,
        int32_t preload_type);
    virtual        ~preload_reader_c() {}

    uint8_t *       request() override;
    uint8_t *       release() override;
    void            rewind()  override;

private:

    // return value can be arbitrary and is not used
    using preload_fn = int(*)(void *memory, size_t size);
    preload_fn      preload;
    preload_fn      unload;

    static int no_action(void *memory, size_t size);
    static int will_need(void *memory, size_t size);
    static int dont_need(void *memory, size_t size);
    static int page_load(void *memory, size_t size);
    static int page_lock(void *memory, size_t size);
    static int page_unlock(void *memory, size_t size);
};


//
// pre-caching reader
//

class pcache_reader_c : public wrapping_reader_c
{
public:
    pcache_reader_c(std::unique_ptr<frame_reader_i> reader);
    virtual        ~pcache_reader_c();

    uint8_t *       request() override;
    uint8_t *       release() override;

private:
    std::vector<uint8_t *>      m_frames;
};


//
// asynchronous reader
//

class async_reader_c : public wrapping_reader_c
{
public:
    async_reader_c(std::unique_ptr<frame_reader_i> reader,
        int32_t num_async_frames, bool inside_loop);
    virtual        ~async_reader_c();

    uint8_t *       request() override;
    uint8_t *       release() override;

private:
    void            read_ahead();

    bool                        m_looped;
    std::atomic<int32_t>        m_length;
    shared_queue<uint8_t *>     m_frames;
    std::thread                 m_thread;
};


//
// looping reader
//

class loop_reader_c : public wrapping_reader_c
{
public:
    loop_reader_c(std::unique_ptr<frame_reader_i> reader, int32_t duration);
    virtual        ~loop_reader_c();

    uint8_t *       request() override;
    uint8_t *       release() override;
    void            rewind()  override {
        throw std::logic_error("loop rewind is not supported");
    }
};

#endif // SAMPLE_ENC_HEVC_FILE_HELPER_H_
