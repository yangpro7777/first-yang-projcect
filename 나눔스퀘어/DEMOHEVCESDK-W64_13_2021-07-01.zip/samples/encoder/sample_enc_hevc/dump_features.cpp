#include "dump_features.h"

#include "mccolorspace.h"

using std::string;

void dump_c::write_pic(FILE* file, const video_out_frame_tt* img_data) {
    frame_colorspace_info_tt cs_info;
    int32_t error = get_frame_colorspace_info(&cs_info, img_data->width, img_data->height, img_data->four_cc, 0);
    if (error) {
        printf("\nErrors during get_frame_colorspace_info(). Terminating...\n");
        exit(0);
    }

    uint8_t* rec_buffer = nullptr;
    int32_t  byte_pp = ((uint8_t*)&img_data->four_cc)[0] == 'X' ? 2 : 1;

    for (int32_t plane = 0; plane < 3; ++plane) {
        rec_buffer = img_data->plane[plane];
        for (uint32_t i = 0; i < cs_info.plane_height[plane]; ++i, rec_buffer += img_data->stride[plane]) {
            fwrite(rec_buffer, cs_info.plane_width[plane] * byte_pp, 1, file);
        }
    }
}

string dump_c::create_filename(std::string base_filename, int32_t layer, int32_t sub_layer) {
    size_t ext_pos = base_filename.find_last_of(".");
    string ext = "";
    if (ext_pos != string::npos) {
        ext = base_filename.substr(ext_pos);
        base_filename = base_filename.substr(0, ext_pos);
    }
    string out = base_filename + "_" + std::to_string(layer);
    if (sub_layer >= 0) {
        out += "_" + std::to_string(sub_layer);
    }
    out += ext;
    return out;
}

bool dump_c::attach_frame(ext_opt_id id, const char* filename, const hevc_v_settings& v_settings,
        int32_t& opt_num, enc_option_t* options) {
    const string id_type = id == EXT_OPT_PARAM_FRM_ORG ? "original" : "reconstruct";
    for (int32_t layer = 0; layer < v_settings.max_layers; layer++) {
        const int32_t last_sub_layer = v_settings.temporal_sub_layers - 1;
        for (int32_t sub_layer = 0; sub_layer < last_sub_layer; sub_layer++) {
            const string file_name_sub = create_filename(filename, layer, sub_layer);
            if (!m_dump_file[layer][sub_layer].open_for_write(file_name_sub.c_str())) {
                printf("\nError: Invalid %s output file specified for layer %d, sublayer %d!\n",
                    id_type.c_str(), layer, sub_layer);
                return false;
            }
        }
        const string file_name = create_filename(filename, layer);
        if (!m_dump_file[layer][last_sub_layer].open_for_write(file_name.c_str())) {
            printf("\nError: Invalid %s output file specified for layer %d!\n",
                id_type.c_str(), layer);
            return false;
        }
    }
    m_frame.reserved1 = this;
    m_frame.done = save;
    options[opt_num++] = { id, &m_frame };
    return true;
}

void dump_c::save(void* this_object) {
    video_out_frame_tt* frame = (video_out_frame_tt*)this_object;
    // reserved1 field is not overwritten from inside, so it can be used for passing context.
    dump_c* ctx = (dump_c*)frame->reserved1;
    for (int32_t sub = frame->temp_id; sub < HEVC_MAX_TEMP_SUB_LAYERS; ++sub) {
        if (ctx->m_dump_file[frame->layer][sub]) {
            write_pic(ctx->m_dump_file[frame->layer][sub], frame);
        }
    }
}
