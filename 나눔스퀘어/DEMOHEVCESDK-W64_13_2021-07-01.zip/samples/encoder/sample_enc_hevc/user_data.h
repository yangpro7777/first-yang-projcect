#ifndef SAMPLE_ENC_HEVC_USER_DATA_H_
#define SAMPLE_ENC_HEVC_USER_DATA_H_

#include <queue>

#include "enc_hevc.h"
#include "user_settings.h"

struct unregistered_user_data_t;
using user_data_pool_t = std::deque<unregistered_user_data_t>;

struct unregistered_user_data_t : public hevc_user_data_tt {
    unsigned char storage[20];

    unregistered_user_data_t(const unregistered_user_data_t &) = delete;
    unregistered_user_data_t &operator = (const unregistered_user_data_t &) = delete;
    unregistered_user_data_t();

    void init_random_ud();
    void init_pic_number_ud(const int32_t number);
    void print_pic_number_info();

    static unregistered_user_data_t* get_vacant_user_data(user_data_pool_t& pool);
    static void process_pool(user_data_pool_t& pool, int32_t frame_count, enc_options_storage& options);
};

#endif // SAMPLE_ENC_HEVC_USER_DATA_H_
