#ifndef SAMPLE_ENC_HEVC_DUMP_FEATURES_H_
#define SAMPLE_ENC_HEVC_DUMP_FEATURES_H_

#include <string>

#include "enc_hevc.h"
#include "file_helper.h"

class dump_c {
public:
    bool attach_frame(ext_opt_id id, const char* filename, const hevc_v_settings& v_settings, int32_t& opt_num, enc_option_t* options);
    static void save(void* this_object);

private:
    static std::string create_filename(std::string base_filename, int32_t layer, int32_t sub_layer = -1);
    static void write_pic(FILE* file, const video_out_frame_tt* img_data);

    video_out_frame_tt m_frame;
    file_c             m_dump_file[HEVC_MAX_LAYERS][HEVC_MAX_TEMP_SUB_LAYERS];
};

#endif
