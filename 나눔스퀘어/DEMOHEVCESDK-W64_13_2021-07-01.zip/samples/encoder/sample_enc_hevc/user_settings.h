#ifndef SAMPLE_ENC_HEVC_USER_SETTINGS_H_
#define SAMPLE_ENC_HEVC_USER_SETTINGS_H_

#include "file_helper.h"
#include "mcdefs.h"
#include "common_video.h"
#include "enc_hevc_def.h"

enum return_code_t {
    RETURN_CODE_NO_ARGUMENTS = 200,
    RETURN_CODE_CANT_OPEN_CONFIG_FILE,
    RETURN_CODE_CANT_OPEN_STAT_FILE,
    RETURN_CODE_CANT_OPEN_INPUT_FILE,
    RETURN_CODE_CANT_OPEN_OUTPUT_FILE,
    RETURN_CODE_CANT_ATTACH_ORG_FRAME,
    RETURN_CODE_CANT_ATTACH_REC_FRAME,
    RETURN_CODE_CANT_ATTACH_CHAPTER_LIST,
    RETURN_CODE_CANT_ATTACH_MPASS_METADATA,
    RETURN_CODE_CANT_ATTACH_QP_MAP,
    RETURN_CODE_OUT_VIDEO_NEW_FAILED
};

void print_usage_info();

struct user_settings {
    int32_t     ext_mem_alloc      = 0;
    const char* license_filename   = nullptr;
    const char* in_file            = nullptr;
    const char* out_file           = nullptr;
    int32_t     bit_rate           = 0;
    const char* cfg_file           = nullptr;
    int32_t     video_type         = 0;
    const char* rec_file           = nullptr;
    const char* org_file           = nullptr;
    const char* stat_file          = nullptr;
    int32_t     width              = 0;
    int32_t     height             = 0;
    int32_t     fourcc             = 0;
    double      frame_rate         = 29.97;
    int32_t     perf               = -1;
    int32_t     run_pass           = 0;
    int32_t     start_frame_to_enc = 0;
    int32_t     frames_to_enc      = -1;
    int32_t     mode               = 0;
    const char* chl_file           = nullptr;
    const char* qp_map_file_name   = nullptr;
    int32_t     dynamic_idr_check  = 0;
    const char* pass_stat_file     = nullptr;
    int32_t     perf1              = -1;
    int32_t     multi_pass         = 0;
    int32_t     put_user_data      = 0;
    int32_t     strict_preset      = 0;
    frame_reader_conf_t reader_conf = frame_reader_conf_t();
    const char* default_stat_file  = "twopass";

    static void apply_default_single(int32_t& item);
    int32_t parse_command_line(int32_t argc, char* argv[]);
    void apply_default_settings();
};

class enc_options_storage {
public:
    void push_back(ext_opt_id id, void* data);
    enc_option_t* get_options();

private:
    static const int32_t MAX_FRAME_OPTIONS = 16;
    int32_t      m_cur_option = 0;
    enc_option_t m_frame_options[MAX_FRAME_OPTIONS] = { {EXT_OPT_PARAM_NULL, nullptr} };
};

#endif // SAMPLE_ENC_HEVC_USER_SETTINGS_H_
