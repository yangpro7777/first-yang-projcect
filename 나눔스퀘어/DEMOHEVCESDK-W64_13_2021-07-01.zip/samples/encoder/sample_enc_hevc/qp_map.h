#ifndef SAMPLE_ENC_HEVC_QP_MAP_H_
#define SAMPLE_ENC_HEVC_QP_MAP_H_

#include <stdint.h>
#include <queue>

#include "enc_hevc.h"
#include "file_helper.h"
#include "user_settings.h"

class qp_map_c;
using qp_map_pool_t = std::deque<qp_map_c>;

class qp_map_c {
public:
    qp_map_c() = delete;
    qp_map_c(int32_t src_width, int32_t src_height);
    ~qp_map_c();

    bool read(FILE* i);
    static void process_pool(qp_map_pool_t& pool, const hevc_v_layer& last_layer,
        file_c& qp_maps_file, enc_options_storage& options);

public:
    void*             m_buffer;
    int32_t           m_buffer_size;
    hevc_user_data_tt m_user_data;
    hevc_qp_map_tt    m_qp_map;
};

#endif // SAMPLE_ENC_HEVC_QP_MAP_H_
