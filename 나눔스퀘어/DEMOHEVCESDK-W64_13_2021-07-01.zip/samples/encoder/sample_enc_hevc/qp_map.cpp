#include "qp_map.h"

#include <string.h>

qp_map_c::qp_map_c(int32_t src_width, int32_t src_height)
    : m_buffer(nullptr)
    , m_user_data()
    , m_qp_map() {
    const int32_t grid_size = 8;
    src_width = (src_width + grid_size - 1) / grid_size;
    src_height = (src_height + grid_size - 1) / grid_size;

    m_buffer_size = src_width * src_height;
    m_buffer = m_buffer_size ? malloc(m_buffer_size) : nullptr;
    if (m_buffer == nullptr) {
        return;
    }

    // fill hevc_user_data_tt struct
    m_user_data.type = USER_DATA_VAM;
    m_user_data.size = sizeof(m_qp_map);
    m_user_data.data = (unsigned char*)&m_qp_map;
    m_user_data.lock = 0;
    m_user_data.flags = 0;

    // fill hevc_qp_map_tt struct
    m_qp_map.format = HEVC_QP_MAP_FORMAT_8X8_INT8_DELTA;
    m_qp_map.data = m_buffer;
    m_qp_map.size = m_buffer_size;
}

qp_map_c::~qp_map_c() {
    if (m_buffer) {
        free(m_buffer);
        m_buffer = nullptr;
    }
}

bool qp_map_c::read(FILE* f) {
    const size_t n = fread(m_buffer, sizeof(int8_t), m_buffer_size, f);
    return n == m_buffer_size;
}

void qp_map_c::process_pool(qp_map_pool_t& pool, const hevc_v_layer& last_layer,
        file_c& qp_maps_file, enc_options_storage& options) {
    auto i = pool.begin();
    const auto& end = pool.end();
    for (; i != end; ++i) {
        if (!i->m_user_data.lock) {
            break;
        }
    }
    if (end == i) {
        i = pool.emplace(i, last_layer.width, last_layer.height);
    }

    const bool send_ud = i->read(qp_maps_file);
    if (send_ud) {
        options.push_back(EXT_OPT_PARAM_PIC_UD, &i->m_user_data);
    }
}
