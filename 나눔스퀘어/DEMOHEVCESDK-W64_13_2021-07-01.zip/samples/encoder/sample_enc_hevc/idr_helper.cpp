#include "idr_helper.h"

#include <stdio.h>
#include <string.h>

#include <algorithm>
#include <iterator>

#include "buf_multi_file.h"

bufstream_multi::bufstream_multi() {
    memset(&pic_info, 0, sizeof(pic_info));
}

bufstream_multi::~bufstream_multi() {
    if (done) {
        done(this, 0);
    }
}

bufstream_multi* bufstream_multi::open_file_buf_write(const char* bs_filename,
        uint32_t bufsize, uint32_t layers, void (*DisplayError)(char* txt)) {
    bufstream_multi* p = new bufstream_multi();
    if (p) {
        p->done = nullptr;
        if (BS_OK != init_file_buf_write(p, bs_filename, bufsize, layers, DisplayError)) {
            delete p;
            p = nullptr;
        }
    }
    return p;
}

uint32_t bufstream_multi::hevc_auxinfo(bufstream_tt* bs, uint32_t offs,
        uint32_t info_id, void* info_ptr, uint32_t info_size) {
    bufstream_multi* multi = (bufstream_multi*)bs;

    // handle input information by info_id
    switch (info_id) {
    case ID_GOP_START_CODE:
        // save last received gop info to know IDR state
        memcpy(&multi->last_gop_info, info_ptr, sizeof(gop_start_info));
        break;
    case ID_PICTURE_START_CODE:
        multi->pic_info = *((pic_start_info*)info_ptr);
        break;
    case STATISTIC_INFO: {
            encode_stat_struct* encode_stat = (encode_stat_struct*)info_ptr;
            printf("\r %d frames encoded @ %.2f fps", encode_stat->frames_encoded, encode_stat->average_speed);
        }
        break;
    case VIDEO_AU_CODE:
        // save present picture number if picture is IDR-picture
        // and clear gop info for next picture
        if (multi->last_gop_info.IDR) {
            multi->idr_pos_actual.insert(multi->pic_info.temp_ref);
        }
        memset(&multi->last_gop_info, 0, sizeof(gop_start_info));
        break;
    default:
        break;
    }

    return multi->org_auxinfo(bs, offs, info_id, info_ptr, info_size);
}

// compare force IDRs with encoded IDRs
void bufstream_multi::check_requested_idr() {
    idr_list_t idrs_dismatched;
    std::set_difference(idr_pos_actual.begin(),   idr_pos_actual.end(),
                        idr_pos_expected.begin(), idr_pos_expected.end(),
                        std::inserter(idrs_dismatched, idrs_dismatched.end()));

    const size_t dismatched_count = idrs_dismatched.size() - (idr_pos_actual.size() - idr_pos_expected.size());
    printf("Dynamic IDR's count: \t%d\n", static_cast<int32_t>(idr_pos_expected.size()));
    printf("Incorrect IDR's count: \t%d\n", static_cast<int32_t>(dismatched_count));
}

void bufstream_multi::update_force_idr_flag(int32_t frame_count, enc_options_storage& options) {
    idr_pos_expected.insert(frame_count);
    options.push_back(EXT_OPT_PARAM_FORCE_IDR, nullptr);
}
