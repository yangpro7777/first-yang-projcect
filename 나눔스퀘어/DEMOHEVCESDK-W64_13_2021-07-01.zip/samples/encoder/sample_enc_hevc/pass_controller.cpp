#include "pass_controller.h"

#include <limits.h>

#include <fstream>
#include <memory>
#include <string>
#include <stdarg.h>

#include "qp_map.h"
#include "mccolorspace.h"
#include "sample_common_args.h"
#include "user_data.h"


#ifdef WIN32
#include <conio.h>
static inline int32_t has_pressed_key(const char* text) {
    if (_kbhit()) {
        _getch();
        return 1;
    }
    return 0;
}
#else
static inline int32_t has_pressed_key(const char* text) {
    return 0;
}
#endif


callback_handler_c::~callback_handler_c() {
    if (m_stat_file) {
        fclose(m_stat_file);
        m_stat_file = nullptr;
    }
}

void callback_handler_c::progress_printf(context_t context, int32_t percent, const char* fmt, ...) {
    char lst[256];
    va_list marker;
    va_start(marker, fmt);
    vsnprintf(lst, sizeof(lst), fmt, marker);
    va_end(marker);
    printf(" %d - %s\n", percent, lst);
}

void callback_handler_c::message_printf(context_t context, const char* fmt, ...) {
    char lst[2048];
    va_list marker;
    va_start(marker, fmt);
    vsnprintf(lst, sizeof(lst), fmt, marker);
    va_end(marker);
    printf("%s\n", lst);
}

void* callback_handler_c::mmalloc(context_t context, size_t size) {
    return malloc(size);
}

void callback_handler_c::mfree(context_t context, void* ptr) {
    free(ptr);
}

void* callback_handler_c::mrealloc(context_t context, void* ptr, size_t size) {
    return realloc(ptr, size);
}

void callback_handler_c::statistics_printf(context_t context, const char* fmt, ...) {
    callback_handler_c* app = reinterpret_cast<callback_handler_c*>(context.p);
    va_list va;
    if (app->m_stat_file) {
        fseek(app->m_stat_file, 0, SEEK_END);
        va_start(va, fmt);
        vfprintf(app->m_stat_file, fmt, va);
        va_end(va);
        fprintf(app->m_stat_file, "\n");
        fflush(app->m_stat_file);
    }
}

int32_t callback_handler_c::get_license_data(context_t context, void* data) {
    callback_handler_c* app = reinterpret_cast<callback_handler_c*>(context.p);

    if (!app->m_license_filename.c_str()) {
        return 0;
    }
    std::ifstream file(app->m_license_filename.c_str(), std::ios::binary);
    if (!file.is_open()) {
        return 0;
    }

    uint32_t rsize = 0;
    file.seekg(0, file.end);
    int64_t read_bytes = file.tellg();
    file.seekg(0, file.beg);
    read_bytes -= file.tellg();

    if ((read_bytes > 0) && (read_bytes <= UINT_MAX)) {
        rsize = static_cast<uint32_t>(read_bytes);
        if (data) {
            file.read((char*)data, rsize);
        } else {
            return rsize;
        }
    }
    return 0;
}


pass_controller_c::pass_controller_c(const user_settings& user_settings, int32_t pass) :
        m_user_settings(user_settings),
        m_pass(pass) {
    m_reader_conf = m_user_settings.reader_conf;
    init_callbacks();
}

pass_controller_c::~pass_controller_c() {
    if (m_v_encoder) {
        hevcOutVideoFree(m_v_encoder);
        m_v_encoder = nullptr;
    }
    if (m_chapter_list) {
        delete[] m_chapter_list;
        m_chapter_list = nullptr;
    }
    if (m_videobs) {
        delete m_videobs;
        m_videobs = nullptr;
    }
}

void pass_controller_c::print_error(const char* message, ...) {
    char printed_message[2048];
    va_list marker;
    va_start(marker, message);
    vsnprintf(printed_message, sizeof(printed_message), message, marker);
    va_end(marker);

    context_t ctx;
    ctx.p = this;
    m_callbacks.err_printf(ctx, "\nH.265/HEVC error: %s\n", printed_message);
}

int32_t pass_controller_c::run() {
    // create frame reader
    auto frame_reader = frame_reader_i::create(m_user_settings.in_file, m_cs_info.frame_size,
        m_user_settings.start_frame_to_enc, m_user_settings.frames_to_enc, m_reader_conf);
    if (!frame_reader) {
        print_error("Failed to create frame reader. File: '%s'", m_user_settings.in_file);
        return RETURN_CODE_CANT_OPEN_INPUT_FILE;
    }
    const int32_t file_frames_count = frame_reader->get_num_frames();

    // open input file
    m_videobs = bufstream_multi::open_file_buf_write(m_user_settings.out_file, 65536, m_v_settings.max_layers, nullptr);
    if (!m_videobs) {
        print_error("Can't open output file '%s'", m_user_settings.out_file);
        return RETURN_CODE_CANT_OPEN_OUTPUT_FILE;
    }

    int32_t status = attach_features();
    if (HEVC_ERROR_NONE != status) {
        return status;
    }

    m_v_encoder = hevcOutVideoNew(&m_callbacks, &m_v_settings, 0, 0xFFFFFFFF, 0, file_frames_count);
    if (!m_v_encoder) {
        print_error("hevcOutVideoNew failed.");
        return RETURN_CODE_OUT_VIDEO_NEW_FAILED;
    }
    status = hevcOutVideoInit(m_v_encoder, m_videobs, m_options);
    if (HEVC_ERROR_NONE != status) {
        print_error("hevcOutVideoInit failed.");
        return status;
    }

    status = process_frames(frame_reader);
    if (HEVC_ERROR_NONE != status) {
        print_error("Errors during frames processing.");
        return status;
    }

    if (m_user_settings.dynamic_idr_check) {
        printf("\nSample information:\n");
        m_videobs->check_requested_idr();
    }
    return HEVC_ERROR_NONE;
}

int32_t pass_controller_c::attach_features() {
    int32_t opt_num = 0;
    if (m_user_settings.org_file) {
        if (!m_org_dump.attach_frame(EXT_OPT_PARAM_FRM_ORG, m_user_settings.org_file, m_v_settings, opt_num, m_options)) {
            print_error("Can't attach org frame. File: '%s'", m_user_settings.org_file);
            return RETURN_CODE_CANT_ATTACH_ORG_FRAME;
        }
    }
    if (m_user_settings.rec_file) {
        if (!m_rec_dump.attach_frame(EXT_OPT_PARAM_FRM_ENC, m_user_settings.rec_file, m_v_settings, opt_num, m_options)) {
            print_error("Can't attach rec frame. File: '%s'", m_user_settings.rec_file);
            return RETURN_CODE_CANT_ATTACH_REC_FRAME;
        }
    }
    if (m_user_settings.chl_file) {
        if (!attach_chapter_list(opt_num)) {
            print_error("Can't attach chapter list.");
            return RETURN_CODE_CANT_ATTACH_CHAPTER_LIST;
        }
    }
    if (!attach_mpass_metadata(opt_num)) {
        print_error("Can't attach multi-pass metadata.");
        return RETURN_CODE_CANT_ATTACH_MPASS_METADATA;
    }
    const char* qp_file = m_user_settings.qp_map_file_name;
    if (qp_file && !m_qp_maps_file.open_for_read(qp_file)) {
        print_error("Can't open the QP maps file for reading. File: '%s'", qp_file);
        return RETURN_CODE_CANT_ATTACH_QP_MAP;
    }

    attach_auxinfo(opt_num);
    m_options[opt_num++] = { EXT_OPT_PARAM_NULL, nullptr };
    return HEVC_ERROR_NONE;
}

void pass_controller_c::attach_auxinfo(int32_t& opt_num) {
    m_videobs->org_auxinfo = m_videobs->auxinfo;
    m_videobs->auxinfo = bufstream_multi::hevc_auxinfo;
}

int32_t pass_controller_c::read_params_from_command_line(int32_t argc, const char* const argv[]) {
    for (int32_t i = 1; i < argc; ++i) {
        if (argv[i][0] != '-') {
            continue;
        }
        const char* name = &argv[i][1];
        const char* value = i + 1 < argc ? argv[i + 1] : "";
        int32_t status = hevcOutVideoSetSettingByName(nullptr, &m_v_settings, name, value);
        if (HEVC_ERROR_NONE != status) {
            return status;
        }
        for (int32_t i = 0; i < m_v_settings.max_layers; ++i) {
            status = hevcOutVideoSetLayerSettingByName(nullptr, &m_v_settings.layers[i], name, value);
            if (HEVC_ERROR_NONE != status) {
                return status;
            }
        }
    }
    return HEVC_ERROR_NONE;
}

hevc_chapter_tt* pass_controller_c::read_and_make_chapter_list_from_file(const char* fn) {
    std::ifstream f(fn, std::ifstream::in);
    std::string line;
    hevc_chapter_tt* chp = nullptr;

    if (!f.is_open()) {
        return nullptr;
    }

    std::getline(f, line);
    int32_t lines = atoi(line.c_str());
    lines = lines < SHRT_MAX ? lines : SHRT_MAX;
    if (lines <= 0) {
        return nullptr;
    }
    chp = new hevc_chapter_tt[lines];
    if (!chp) {
        return nullptr;
    }

    int32_t c = 0;
    while (f.good() && c < lines) {
        std::getline(f, line);
        line = line.substr(0, line.find_first_of(";#"));
        if (line.length()) {
            const int32_t pos = atoi(line.c_str());
            if (pos) {
                chp[c].flags = 0;
                if (pos < 0) {
                    chp[c].flags = HEVC_CHAPTER_FORCE_IDR;
                }
                chp[c++].frame_nr = abs(pos) - 1;
            }
        }
    }

    if (!c) {
        delete[] chp;
        return nullptr;
    }

    chp[c - 1].flags |= HEVC_CHAPTER_END_OF_LIST;
    if (c < lines) {
        hevc_chapter_tt* newchp = new hevc_chapter_tt[c];
        while (--c >= 0) {
            newchp[c] = chp[c];
        }
        delete[] chp;
        chp = newchp;
    }
    return chp;
}

bool pass_controller_c::attach_chapter_list(int32_t& opt_num) {
    m_chapter_list = read_and_make_chapter_list_from_file(m_user_settings.chl_file);
    if (m_chapter_list) {
        m_options[opt_num++] = { EXT_OPT_CHAPTER_LIST, m_chapter_list };
        return true;
    }
    return false;
}

bool pass_controller_c::attach_mpass_metadata(int32_t& opt_num) {
    if (!m_pass) {
        return true;
    }

    if (m_md_storage) {
        free(m_md_storage);
        m_md_storage = nullptr;
    }
    m_md_storage = new_metadata_file(const_cast<char*>(m_user_settings.pass_stat_file ?
        m_user_settings.pass_stat_file : m_user_settings.default_stat_file));
    if (m_md_storage) {
        for (int32_t i = 0; i < m_v_settings.max_layers; ++i) {
            m_v_settings.layers[i].multi_pass = m_pass;
        }
        m_options[opt_num++] = { EXT_OPT_METADATA_MPASS, m_md_storage };
    } else {
        printf("\nError: Invalid statistics file for multi-pass encoding!\n");
        return false;
    }
    return true;
}

int32_t pass_controller_c::read_input(int32_t argc, char* argv[]) {
    // set to default and allow to override
    // max_layers      - in the config file
    // presets         - both in the config file and in the command line
    // hw_acceleration - in the command line
    if (m_user_settings.cfg_file) {
        file_c file;
        file.open_for_read(m_user_settings.cfg_file);
        if (!file) {
            print_error("HEVC error: config file '%s' cannot be opened.", m_user_settings.cfg_file);
            return RETURN_CODE_CANT_OPEN_CONFIG_FILE;
        }
        const size_t size = file.get_size();
        std::unique_ptr<char []> cfg_buf(new char[size]);
        fread(cfg_buf.get(), 1, size, file);
        const int32_t result = hevcOutVideoSetSettings(&m_callbacks, &m_v_settings, cfg_buf.get(), size);
        if (HEVC_ERROR_NONE != result) {
            print_error("HEVC error: error while reading config file '%s'.", m_user_settings.cfg_file);
            return result;
        }
    }
    const int32_t result = read_params_from_command_line(argc, argv);
    if (HEVC_ERROR_NONE != result) {
        print_error("Invalid input from command line!");
    }
    return result;
}

int32_t pass_controller_c::init_encoder_settings(int32_t argc, char* argv[]) {
    memset(&m_v_settings, 0, sizeof(m_v_settings));

    const int32_t error = get_frame_colorspace_info(&m_cs_info, m_user_settings.width,
        m_user_settings.height, m_user_settings.fourcc, 0);
    if (error) {
        print_error("Invalid frame resolution for selected fourCC!");
        return HEVC_ERROR_UNSUPPORTED_COLORSPACE;
    }

    m_v_settings.max_layers = 1;
    int32_t status = read_input(argc, argv);
    if (HEVC_ERROR_NONE != status) {
        return status;
    }

    // override presets from the command line
    if (m_user_settings.video_type != ITEM_NOT_INIT) {
        for (int32_t i = 0; i < m_v_settings.max_layers; ++i) {
            m_v_settings.layers[i].preset = (hevc_preset_t)m_user_settings.video_type;
        }
    }
    if (!hevcOutVideoDefaults(&m_callbacks, &m_v_settings, HEVC_MULTI, m_v_settings.hw_acceleration)) {
        print_error("Invalid settings, hevcOutVideoDefaults failed.");
        return HEVC_ERROR_VALIDATION_FAILED;
    }

    m_v_settings.layers[0].width = m_user_settings.width;
    m_v_settings.layers[0].height = m_user_settings.height;
    if (m_user_settings.multi_pass && m_pass == 1 &&
            m_user_settings.perf1 != ITEM_NOT_INIT &&
            m_user_settings.perf1 != -1) {
        hevcOutVideoPerformance(&m_callbacks, &m_v_settings, m_user_settings.mode, m_user_settings.perf1, 0);
    } else if (m_user_settings.perf != ITEM_NOT_INIT &&
            m_user_settings.perf != -1) {
        hevcOutVideoPerformance(&m_callbacks, &m_v_settings, m_user_settings.mode, m_user_settings.perf, 0);
    }

    // Input reading for second time is needed for SABET - it needs to know initial resolutions.
    status = read_input(argc, argv);
    if (HEVC_ERROR_NONE != status) {
        print_error("Invalid input!");
        return status;
    }

    if (m_user_settings.bit_rate != ITEM_NOT_INIT && m_v_settings.max_layers == 1) {
        m_v_settings.layers[0].bit_rate = m_user_settings.bit_rate;
    }

    if (m_user_settings.frame_rate != ITEM_NOT_INIT) {
        m_v_settings.time_scale = (m_user_settings.frame_rate >= 15.0) ?
            27000000 :
            static_cast<int32_t>(1800000 * m_user_settings.frame_rate + 0.5);
        m_v_settings.num_units_in_tick = static_cast<int32_t>(m_v_settings.time_scale / m_user_settings.frame_rate);
    }

    if (m_user_settings.stat_file) {
        if (m_v_settings.statistics_level <= 0) {
            m_v_settings.statistics_level = 1;
        }
        m_stat_file = fopen(m_user_settings.stat_file, "wb");
        if (!m_stat_file) {
            print_error("Can't open stat file.");
            return RETURN_CODE_CANT_OPEN_STAT_FILE;
        }
    }
    m_license_filename = m_user_settings.license_filename ? m_user_settings.license_filename : "";
    status = hevcOutVideoChkSettings(&m_callbacks, &m_v_settings, m_user_settings.strict_preset ? HEVC_ADJUST_PRESET : HEVC_ADJUST_MAIN);
    if (HEVC_ERROR_NONE != status) {
        print_error("Invalid settings, hevcOutVideoChkSettings failed.");
        return status;
    }
    return HEVC_ERROR_NONE;
}

void pass_controller_c::init_callbacks() {
    memset(&m_callbacks, 0, sizeof(m_callbacks));
    m_callbacks.err_printf = message_printf;
    m_callbacks.prg_printf = progress_printf;
    m_callbacks.wrn_printf = message_printf;
    m_callbacks.inf_printf = message_printf;
    m_callbacks.stat_printf = statistics_printf;
    m_callbacks.get_license_data = get_license_data;

    m_callbacks.malloc = mmalloc;
    m_callbacks.free = mfree;
    m_callbacks.realloc = mrealloc;
    m_callbacks.context.p = this;
}

int32_t pass_controller_c::process_frames(std::unique_ptr<frame_reader_i>& frame_reader) {
    int32_t          frame_count = 0;
    qp_map_pool_t    qp_maps_pool;
    user_data_pool_t user_data_pool;
    int32_t          manual_abort = 0;

    while (frame_reader->is_valid()) {
        unsigned char* input_video_buffer = frame_reader->request_frame();
        if (!input_video_buffer) {
            break;
        }
        enc_options_storage options;

        if (m_user_settings.dynamic_idr_check) {
            if (rand() % 100 < 10) {
                m_videobs->update_force_idr_flag(frame_count, options);
            }
        }
        const auto& last_layer = m_v_settings.layers[m_v_settings.max_layers - 1];
        if (m_qp_maps_file) {
            qp_map_c::process_pool(qp_maps_pool, last_layer, m_qp_maps_file, options);
        }

        if (m_user_settings.put_user_data) {
            unregistered_user_data_t::process_pool(user_data_pool, frame_count, options);
        }
        // Set end of frame options.
        options.push_back(EXT_OPT_PARAM_NULL, nullptr);

        // Give a frame to the encoder and release buffer after work completion.
        const int32_t status = hevcOutVideoPutFrame(m_v_encoder, input_video_buffer + m_cs_info.plane_offset[0], m_cs_info.stride[0],
            m_user_settings.width, m_user_settings.height, m_user_settings.fourcc, options.get_options());
        if (HEVC_ERROR_NONE != status) {
            frame_reader->release_frame();
            return status;
        }
        if (!frame_reader->release_frame()) {
            break;
        }
        ++frame_count;

        // Break manual abortion.
        if (has_pressed_key(nullptr)) {
            manual_abort = 1;
            break;
        }
    }
    return hevcOutVideoDone(m_v_encoder, manual_abort);
}
