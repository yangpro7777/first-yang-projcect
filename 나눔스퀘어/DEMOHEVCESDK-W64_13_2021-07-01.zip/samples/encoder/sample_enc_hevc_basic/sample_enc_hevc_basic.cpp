/********************************************************************
 Created: 2017/07/27 
 File name: sample_enc_hevc_basic.cpp
 Purpose: command-line simple sample for H.265/HEVC encoder

 Copyright (c) 2017 MainConcept GmbH or its affiliates.  All rights reserved.
 
 MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
 This software is protected by copyright law and international treaties.  Unauthorized
 reproduction or distribution of any portion is prohibited by law.

*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <algorithm>
#include <cstdio>
#include <string.h>

#include "mctypes.h"
#include "mcfourcc.h"
#include "buf_file.h"
#include "enc_hevc.h"

/*
    Auxiliary function for getting feedback from encoder 
*/
void info_printf(context_t context, const char * fmt, ...)
{
    va_list marker;

    va_start(marker, fmt);
    vprintf(fmt, marker);
    va_end(marker);

    printf("\n");
}

void init_hevc_callbacks(callbacks_t* callbacks, void * context)
{
    callbacks->context.p = context;
    callbacks->inf_printf = info_printf;
    callbacks->err_printf = info_printf;
    callbacks->wrn_printf = info_printf;
}

int main(int argc, const char* argv[])
{
    if (argc < 8) {
        printf( "\nUsage:\tsample_enc_hevc_basic <inputfile> <outputfile> <width> <height> <bitrate> <framerate> <colorspace>\n"
                "Available colorspaces: I420, YV12, W010, X010.\n");
        return 1;
    };

    void* app_context       = nullptr;
    callbacks_t callbacks   = {};
    init_hevc_callbacks(&callbacks, app_context);

    const char*   in_file    = argv[1];
    const char*   out_file   = argv[2];
    const int32_t width      = atoi(argv[3]);
    const int32_t height     = atoi(argv[4]);
    const int32_t bit_rate   = atoi(argv[5]);
    const double  frame_rate = atof(argv[6]);
    int32_t preset           = HEVC_MAIN;
    const uint32_t fourcc    = 4 == strlen(argv[7]) ? MAKEFOURCC(argv[7][0], argv[7][1], argv[7][2], argv[7][3]) : 0;

    static const uint32_t supported_fourcc[] = {FOURCC_I420, FOURCC_YV12, FOURCC_W010, FOURCC_X010};
    if (supported_fourcc + 4 == std::find(supported_fourcc, supported_fourcc + 4, fourcc))
    {
        printf("Invalid color space was specified!\n");
        return 1;
    }

    const bool is_10bit = (fourcc == FOURCC_W010 || fourcc == FOURCC_X010);
    if (is_10bit)
        preset = HEVC_MAIN_10;

    const int32_t line_size  = width << (is_10bit ? 1 : 0);
    const int32_t frame_size = line_size * height * 3 / 2;
    unsigned char* input_buffer = new unsigned char[frame_size];
    if (!input_buffer)
    {
        printf("Can't allocate input buffer!\n");
        return 1;
    }
    FILE* input_video_file = fopen(in_file, "rb");
    if (!input_video_file)
    {
        printf("Can't open specified input file!\n");
        return 1;
    }
    /*
    Step 1: The encoder settings initialization.
    -
    Set default values for the encoder settings (hevc_v_settings) by calling hevcOutVideoDefaults.
    There are variety of different presets that can help you to initialize the settings according to your needs.
    It's strongly recommended to use this function, even if you going to load settings from an external file.
    */
    struct hevc_v_settings v_settings;
    if (hevcOutVideoDefaults(&callbacks, &v_settings, preset, HEVC_HW_ACCELERATION_NONE) == NULL)
    {
        printf("\nhevcOutVideoDefaultsEx failed. Terminating...\n");
        return 1;
    }
    /*
    Step 2: The encoder performance adjustment, optional.
    -
    Apply a performance preset by calling hevcOutVideoPerformance.
    The encoder offers a lot of options for the quality/speed optimization. You can turn them on and off manually
    but it's strongly recommended to apply a performance preset instead. By default, the encoder applies the "balanced"
    quality/speed preset during hevc_v_settings initialization.
    */
    hevcOutVideoPerformance(&callbacks, &v_settings, 0, HEVC_PERF_BETTER_QUALITY, 0);
    /*
    Step 3: The encoder settings adjustment.
    -
    Adjust important settings like width, height, bitrate, frame rate, etc.
    */
    v_settings.num_units_in_tick       = 90000;
    v_settings.time_scale              = int32_t(frame_rate * v_settings.num_units_in_tick + 0.5);
    v_settings.layers[0].width         = width;
    v_settings.layers[0].height        = height;
    v_settings.layers[0].bit_rate_mode = HEVC_VBR;
    v_settings.layers[0].bit_rate      = bit_rate;
    /*                                
    Step 4: The encoder settings verification.
    -
    Verify and adjust the settings before the encoder creation by calling hevcOutVideoChkSettings.
    The advantage of hevcOutVideoChkSettings is that you can retrieve adjusted settings. If you skip this step,
    the encoder will verify settings at the creation moment anyway.
    You can handle validation output by providing a custom callbacks as the first argument of the function.
    */
    if (hevcOutVideoChkSettings(&callbacks, &v_settings, 0))
    {
        printf("\nhevcOutVideoChkSettings failed. Terminating...\n");
        return 1;
    }
    /*
    Step 5: An encoder instance creation.
    -
    Create a new encoder instance by calling hevcOutVideoNew.
    You can handle text output by providing a custom callbacks as the first argument of the function.
    */
    hevc_v_encoder* v_encoder = hevcOutVideoNew(&callbacks, &v_settings, 0, 0xFFFFFFFF, 0, 0);
    if (!v_encoder)
    {
        printf("hevcOutVideoNew failed\n");
        return 1;
    }
    /*
    Step 6: The encoder instance initialization.
    -
    Set elementary stream handler by calling hevcOutVideoInit.
    Optionally, original picture handler and reconstructed picture handler can be set here.
    */
    bufstream_tt* videobs = open_file_buf_write(out_file, 65536, NULL);
    if (!videobs)
    {
        hevcOutVideoFree(v_encoder);
        printf("Can't init bufstream.\n");
        return 1;
    }
    if (hevcOutVideoInit(v_encoder, videobs, NULL))
    {
        hevcOutVideoFree(v_encoder);
        printf("hevcOutVideoInit failed.\n");
        return 1;
    }
    /*
    Step 7: Encoding.
    -
    Feed the encoder with input data by calling hevcOutVideoPutFrame or hevcOutVideoPutFrameV.
    */
    while (fread(input_buffer, sizeof(unsigned char), frame_size, input_video_file) == frame_size)
    {
        if (hevcOutVideoPutFrame(v_encoder, input_buffer, line_size, width, height, fourcc, NULL))
            break;
    }
    /*
    Step 8: Flushing and destruction.
    -
    Flush the encoder with hevcOutVideoDone (or hevcOutVideoFlush) and free it.
    hevcOutVideoDone destroys the encoder instance.
    */
    hevcOutVideoDone(v_encoder, 0);
    hevcOutVideoFree(v_encoder);

    videobs->done(videobs, 0);
    videobs->free(videobs);

    delete[] input_buffer;
    fclose(input_video_file);
    return 0;
}
