/********************************************************************
 Created: 2013/03/19 
 File name: sample_fhg_enc_aac.cpp
 Purpose: sample for Fraunhofer AAC encoder

 Copyright (c) 2005-2009 MainConcept GmbH. All rights reserved.

 This software is the confidential and proprietary information of
 MainConcept GmbH and may be used only in accordance with the terms of
 your license from MainConcept GmbH.

*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fhg_enc_aac.h"
#include "mctypes.h"
#include "buf_file.h"
#include "sample_common_args.h"
#include "sample_common_misc.h"


const int idx2bit_rate[] =
{
    0, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 
    112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 640, 768, 896, 1024
};

int32_t bitrate_to_index(int32_t bitrate)
{
    int32_t i;
    for (i=sizeof(idx2bit_rate)/sizeof(int)-1; i>=0; i--)
        if (idx2bit_rate[i] <= bitrate)
        {
            if (idx2bit_rate[i] != bitrate)
                return AAC_AUDIOBITRATE_CUSTOM;
            break;
        }
    return i;
}

const int BUFFER_SIZE = 1024*4;

int main (int argc, char **argv)
{
    fhg_aac_a_settings encodesettings;
    uint8_t sample_buffer[BUFFER_SIZE];
    int32_t sample_rate, n_channels, bps, bit_rate;
    int32_t header_mode = ITEM_NOT_INIT;
    int32_t aot = AAC_LC;
    int32_t ret;
    char * in_file;
    char * out_file;
	FILE * fp_in = NULL;
    char *custom_arg(NULL);

	wav_hdr_param wav_hdr = {0};
	int wav_flag = 0;
  
    arg_item_t params[] =
    {
        { IDS_AUDIO_FILE,      1, &in_file},
        { IDS_OUTPUT_FILE,     1, &out_file},
        { ID_A_SAMPLERATE,     0, &sample_rate},
        { ID_A_CHANNELS,       0, &n_channels},
        { IDI_BITS_PER_SAMPLE, 0, &bps},
        { IDI_BITRATE,         1, &bit_rate},
        { IDI_MODE,            0, &header_mode},
        { IDS_CUSTOM_ARG,      0, &custom_arg}
    };

    ret = parse_args(argc - 1, argv + 1, sizeof(params) / sizeof(params[0]), params);
	if (ret >= 0)
	{
		fp_in  = fopen(in_file, "rb");
		if (!fp_in)
		{
			printf("Error opening input file.\n");
			return 1;
		}

		if (wav_header_read(fp_in, &wav_hdr) != 0)
			wav_flag = 1;	
	}
	if(custom_arg) {
		if (!strcmp(custom_arg, "-LC") || !strcmp(custom_arg, "-lc"))
			aot = AAC_LC;
        else if (!strcmp(custom_arg,"-HE") || !strcmp(custom_arg,"-he")) 
            aot = AAC_HEAAC;
        else if (!strcmp(custom_arg,"-PS") || !strcmp(custom_arg,"-ps"))
            aot = AAC_PS;
		else 
            ret = -1;
	}


	if (ret < 0 || (!wav_flag && (sample_rate == ITEM_NOT_INIT || n_channels == ITEM_NOT_INIT || bps == ITEM_NOT_INIT)))
    {
        printf("\n==== MainConcept Fraunhofer AAC encoder sample ====\n"
            "Usage:\nsample_fhg_enc_aac -a input.pcm -o output.aac -bps 16 -s 48000 -ch 2 -b 256 [-m 1] [-LC/HE/PS]\n"
            "Options:\n-b\ttarget bit rate (kbps)\n-s\tsample rate\n-ch\tnumber of channels\n-bps\tbits per sample\n"
            "-m\theader_mode(0 - raw AAC | 1 - ADTS | 2 - LATM)\n"
            "-LC\tlow complexity mode\n-HE\tHEAAC mode (SBR)\n-PS\tHEAACv2 mode (SBR+PS)\n"
            );
        return 0;
    }

	if (wav_flag)
	{
		if (sample_rate == ITEM_NOT_INIT)
			sample_rate = wav_hdr.sample_rate;
		if (n_channels == ITEM_NOT_INIT)
			n_channels = wav_hdr.num_channels;
		if (bps == ITEM_NOT_INIT)
			bps = wav_hdr.bits_per_sample;
	}

    fhgAacOutAudioDefaults(&encodesettings, MCPROFILE_DEFAULT);
    encodesettings.bits_per_sample = bps;
    encodesettings.input_channels = n_channels;

    encodesettings.audio_bitrate_index = bitrate_to_index(bit_rate);
    if (encodesettings.audio_bitrate_index == AAC_AUDIOBITRATE_CUSTOM)
        encodesettings.audio_bitrate_custom = bit_rate;

    encodesettings.header_type = (header_mode != ITEM_NOT_INIT) ? header_mode : AAC_HEADER_ADTS;
    encodesettings.sbr_signaling = FHG_AAC_SBR_SIG_IMPLICIT;
    encodesettings.quality = FHG_AAC_QUAL_HIGH;
    encodesettings.metadata_mode = FHG_AAC_METADATA_NONE;
    encodesettings.aac_object_type = aot;

    callbacks_t callbacks;
    init_callbacks(callbacks);

    ret = fhgAacOutAudioChkSettings(&callbacks, &encodesettings, MCPROFILE_DEFAULT, sample_rate, 0, NULL);
    if (ret != aacOutErrNone)
    {
        printf("Incorrect input settings. Error code: %d\n", ret);
		fclose(fp_in);
        return 1;
    }   

    bufstream_tt *outputbs = open_file_buf_write (out_file, 65535, NULL);
    if (!outputbs)
    {
        printf("Error opening output file.\n");
        fclose(fp_in);
        return 1;
    }

    fhg_aac_aenc_tt *aenc = fhgAacOutAudioNew (&callbacks, &encodesettings, 0, 0, sample_rate);
    if (!aenc)
    {
        printf ("Unable to get new instance of Fraunhofer AAC Encoder\n");
        close_file_buf(outputbs, 0);
        fclose(fp_in);
        return 1;
    }

    ret = fhgAacOutAudioInit (aenc, outputbs);
    if (ret != aacOutErrNone)
    {
        printf ("Unable to initialize Fraunhofer AAC Encoder instance\n");
        fhgAacOutAudioFree (aenc);
        close_file_buf(outputbs, 0);
        fclose(fp_in);
        return 1;
    }

    int sample_size = bps * n_channels / 8;
    int frame_size = BUFFER_SIZE / sample_size * sample_size;
    while (!feof(fp_in))
    {
        int bytes_read;
		if (wav_flag)
			bytes_read	= (uint32_t)wav_data_read(fp_in, &wav_hdr, sample_buffer, frame_size);
		else
			bytes_read	= (int)fread(sample_buffer, 1, frame_size, fp_in);

		if (bytes_read == 0) break;

        ret = fhgAacOutAudioPutBytes (aenc, sample_buffer, bytes_read);
    }

    fhgAacOutAudioDone (aenc, 0);
    fhgAacOutAudioFree (aenc);
    close_file_buf(outputbs, 0);
    fclose(fp_in);

    return 0;
}
