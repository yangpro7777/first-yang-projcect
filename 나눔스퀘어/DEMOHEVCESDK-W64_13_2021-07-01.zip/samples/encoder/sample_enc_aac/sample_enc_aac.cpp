/********************************************************************
 Created: 2008/01/28 
 File name: sample_enc_aac.cpp
 Purpose: sample for AAC encoder

 Copyright (c) 2005-2009 MainConcept GmbH. All rights reserved.

 This software is the confidential and proprietary information of
 MainConcept GmbH and may be used only in accordance with the terms of
 your license from MainConcept GmbH.

*********************************************************************/

#include <stdio.h>
#include <string.h>
#include <enc_aac.h>
#include <stdlib.h>
#include "buf_file.h"
#include "sample_common_args.h"
#include "sample_common_misc.h"


const int idx2bit_rate[] =
{
    0, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 
    112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 640, 768, 896, 1024
};

int32_t bitrate_to_index(int32_t bitrate)
{
    int32_t i;
    for (i=sizeof(idx2bit_rate)/sizeof(int)-1; i>=0; i--)
        if (idx2bit_rate[i] <= bitrate)
            break;
    return i;
}

const int BUFFER_SIZE = 1024*4;

#define IDC_LFE IDC_CUSTOM_START_ID + 1 

int main (int argc, char **argv)
{
    aac_a_settings encodesettings;
    uint8_t sample_buffer[BUFFER_SIZE];
    int32_t sample_rate, n_channels, bps, bit_rate;
    int32_t header_mode = ITEM_NOT_INIT;
    int32_t lfe = ITEM_NOT_INIT;
    int32_t aot = AAC_LC;
    int32_t ret;
    int32_t restart_interval;
    char * in_file;
    char * out_file;
	FILE * fp_in = NULL;
    char *custom_arg = NULL;
	wav_hdr_param wav_hdr = {0};
	int wav_flag = 0;
  
    const arg_item_desc_t custom_args[] =
    {
        { IDC_LFE,   "LFE",  "",ItemTypeInt,  0, "LFE filtering flag" }
    };

    arg_item_t params[] =
    {
        { IDS_AUDIO_FILE,    1,  &in_file},
        { IDS_OUTPUT_FILE,   1,  &out_file},
        { ID_A_SAMPLERATE,   0,  &sample_rate},
        { ID_A_CHANNELS,     0,  &n_channels},
        { IDI_BITS_PER_SAMPLE, 0,  &bps},
        { IDI_BITRATE, 1,  &bit_rate},
        { IDI_MODE, 0, &header_mode},
        { IDC_LFE, 0, &lfe},
        { ID_A_RESTART_INTERVAL, 0, &restart_interval},
        { IDS_CUSTOM_ARG,      0, &custom_arg}
    };

    ret = parse_args(argc - 1, argv + 1, sizeof(params) / sizeof(params[0]), params, custom_args, sizeof (custom_args) / sizeof(custom_args[0]));
	if (ret >= 0)
	{
		fp_in  = fopen(in_file, "rb");
		if (!fp_in)
		{
			printf("Error opening input file.\n");
			return 1;
		}

		if (wav_header_read(fp_in, &wav_hdr) != 0)
			wav_flag = 1;	
	}

	if (ret < 0 || (!wav_flag && (sample_rate == ITEM_NOT_INIT || n_channels == ITEM_NOT_INIT || bps == ITEM_NOT_INIT)))
    {
        printf("\n==== MainConcept AAC encoder sample ====\n"
            "Usage:\nsample_enc_aac -a input.pcm -o output.aac -bps 16 -s 48000 -ch 2 -b 256 [-m 1]\n"
            "Options:\n-b\ttarget bit rate (kbps)\n-s\tsample rate\n-ch\tnumber of channels\n-bps\tbits per sample\n"
            "-m\theader_mode(0 - raw AAC | 1 - ADTS | 2 - LATM)\n"
            "-LC\tlow complexity mode\n-HE\tHEAAC mode (SBR)\n-PS\tHEAACv2 mode (SBR+PS)\n-restart_interval restart interval in PTS\n"
            "-LFE\tLFE filtering flag (0 to disable, 1 to enable)\n"
            );
        return 0;
    }

	if (wav_flag)
	{
		if (sample_rate == ITEM_NOT_INIT)
			sample_rate = wav_hdr.sample_rate;
		if (n_channels == ITEM_NOT_INIT)
			n_channels = wav_hdr.num_channels;
		if (bps == ITEM_NOT_INIT)
			bps = wav_hdr.bits_per_sample;
	}

    aacOutAudioDefaults(&encodesettings, MCPROFILE_DEFAULT);
    encodesettings.bits_per_sample = bps;
    encodesettings.input_channels = n_channels;
    encodesettings.audio_bitrate_index = bitrate_to_index(bit_rate);
    encodesettings.pts_units = 1000000;
    if (header_mode != ITEM_NOT_INIT)
        encodesettings.header_type = header_mode;
    if (restart_interval != ITEM_NOT_INIT)
        encodesettings.restart_interval = restart_interval;

    if (lfe != ITEM_NOT_INIT)
    {
        if(lfe == 0 || lfe == 1)
            encodesettings.LFE_filtering = lfe;
        else
        {
            printf("Incorrect value for LFE filtering flag, set 0 to disable or 1 to enable filtering.\n");
            return 0;
        }
    }

	if(custom_arg) {
        if (!strcmp(custom_arg, "-LC") || !strcmp(custom_arg, "-lc"))
            encodesettings.he = AAC_HE_NOTUSED;
        else if (!strcmp(custom_arg,"-HE") || !strcmp(custom_arg,"-he")) 
            encodesettings.he = AAC_HE_IMPLICIT;
        else if (!strcmp(custom_arg,"-PS") || !strcmp(custom_arg,"-ps"))
            encodesettings.he = AAC_HE_IMPLICIT_WITH_PS;
        else 
        {
            printf ("Incorrect aac mode, use one of these parameters:\n \
                     -LC\tlow complexity mode\n-HE\tHEAAC mode (SBR)\n-PS\tHEAACv2 mode (SBR+PS)\n");
            return 0;
        }
    }
    callbacks_t callbacks;
    init_callbacks(callbacks);
    ret = aacOutAudioChkSettings(&callbacks, &encodesettings, MCPROFILE_DEFAULT, sample_rate, 0, NULL);
    if (ret != aacOutErrNone)
    {
        printf("Incorrect input settings. Error code: %d\n", ret);
		fclose(fp_in);
        return 1;
    }   

    bufstream_tt *outputbs = open_file_buf_write (out_file, 65535, NULL);
    if (!outputbs)
    {
        printf("Error opening output file.\n");
        fclose(fp_in);
        return 1;
    }

    aacaenc_tt *aenc = aacOutAudioNew (&callbacks, &encodesettings, 0, 0, sample_rate);
    if (!aenc)
    {
        printf ("Unable to get new instance of AAC Encoder\n");
        close_file_buf(outputbs, 0);
        fclose(fp_in);
        return 1;
    }

    ret = aacOutAudioInit (aenc, outputbs);
    if (ret != aacOutErrNone)
    {
        printf ("Unable to initialize AAC Encoder instance\n");
        aacOutAudioFree (aenc);
        close_file_buf(outputbs, 0);
        fclose(fp_in);
        return 1;
    }

    int sample_size = bps * n_channels / 8;
    int frame_size = BUFFER_SIZE / sample_size * sample_size;
    while (!feof(fp_in))
    {
        int bytes_read;
		if (wav_flag)
			bytes_read	= (uint32_t)wav_data_read(fp_in, &wav_hdr, sample_buffer, frame_size);
		else
			bytes_read	= (int)fread(sample_buffer, 1, frame_size, fp_in);

		if (bytes_read == 0) break;

        ret = aacOutAudioPutBytes (aenc, sample_buffer, bytes_read);
    }

    aacOutAudioDone (aenc, 0);
    aacOutAudioFree (aenc);
    close_file_buf(outputbs, 0);
    fclose(fp_in);

    return 0;
}
