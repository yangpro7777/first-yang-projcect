/********************************************************************
 Created: 2005/11/22
 File name: sample_mux_mp4.cpp
 Purpose: command-line sample for MP4 Muxer

 Copyright (c) 2005-2009 MainConcept GmbH. All rights reserved.

 This software is the confidential and proprietary information of
 MainConcept GmbH and may be used only in accordance with the terms of
 your license from MainConcept GmbH.

*********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

#include "mcprofile.h"
#include "auxinfo.h"
#include "buf_file.h"
#include "mux_mp4.h"
#include "sample_common_misc.h"


#define MAX_INPUT_FILES     32


typedef struct _GLOBAL_VARS
{
    mp4_m_settings set;
    mp4_muxer_tt *mp4muxer;
    int32_t input_streams;
    int32_t output_format;
    int32_t compatibility;
    int32_t atom_ordering;
    int keepPS;
    double MJ2_timescale;
    char *output_filename;
    char *input_filenames[MAX_INPUT_FILES];
    bufstream_tt *input_streams_bs[MAX_INPUT_FILES];
    int fragmented;
    int sync_mode;
    int length;
    int sample_rate;
    char *extended_language;
    uint32_t skip_box_size;
    uint32_t reserved_space_for_moov_size;
    int cmaf_chunk_count;
} GLOBAL_VARS;


static void show_usage()
{
    printf("Usage: sample_mux_mp4  <option> -o<output filename> -i<input stream> -i<input stream>...\n");
    printf("\n");
    printf("   <options> is one or more of the following:\n");
    printf("   -f<format> where 0=mp4, 1=3gp, 2=mjp2\n");
    printf("   -c<compatibility> where 0=std, 1=PSP, 2=IPOD, 4=QT, 5=PMC, 6=FLV, 7=iPhone, 8=iPad\n");
    printf("   -a<atom ordering> where 0=MDAT first, 1=MOOV first\n");
    printf("   -t<MJ2 timescale>\n");
    printf("   -d<fragment duration>\n");
    printf("   -l<video sequence lenght>\n");
    printf("   -r<video sample rate in 100ns units>\n");
    printf("   -z<skip box size>\n");
    printf("   -s<reserved size for MOOV atom (bytes)>\n");
    printf("   -k<flags> where 1=save all vps spp and pps units as is, 0=as default\n");
}


static void parse_cmd(GLOBAL_VARS *vars, char *input)
{
    switch (tolower(*input))
    {
        case 'a':
            vars->atom_ordering = atoi(input + 1);
            if ((vars->atom_ordering < 0) || (vars->atom_ordering > 1))
            {
                printf("atom ordering must be 0 .. 1.\n");
                exit(1);
            }
            break;
        case 'b':
            vars->cmaf_chunk_count = atoi(input + 1);
            break;
        case 'c':
            vars->compatibility = atoi(input + 1);
            if ((vars->compatibility < 0) || (vars->compatibility >= COMP_MAX))
            {
                printf("compatibility must be below %d.\n", COMP_MAX);
                exit(1);
            }
            break;

        case 'f':
            vars->output_format = atoi(input + 1);
            if ((vars->output_format < 0) || (vars->output_format > 2))
            {
                printf("format must be 0 .. 2.\n");
                exit(1);
            }
            break;

        case 'h':
            show_usage();
            break;

        case 'i':
            if (vars->input_streams + 1 < MAX_INPUT_FILES)
            {
                vars->input_filenames[vars->input_streams] = input + 1;
                vars->input_streams++;
            }
            else
            {
                printf("too many input streams, max is %d\n", MAX_INPUT_FILES);
                exit(1);
            }
            break;

        case 'o':
            vars->output_filename = input + 1;
            break;

        case 't':
            vars->MJ2_timescale = atof (input + 1);
            break;

        case 'd':
	        vars->fragmented = atoi (input + 1);
	        break;

        case 'l':
            vars->length = atoi (input + 1);
            break;

        case 'g':
            vars->extended_language = input + 1;
            break;

        case 'r':
			vars->sample_rate = atoi (input + 1);
            break;

        case 'z':
            vars->skip_box_size = atoi (input + 1);
            break;

        case 's':
            vars->reserved_space_for_moov_size = atoi (input + 1);
            break;

        case 'k':
            vars->keepPS = atoi(input + 1);
            break;

        default:
            printf ("Unknown input param %s!\n", input);
            show_usage();
            exit(1);
    }
}

int main(int argc, char * argv[])
{
    int32_t i;
    GLOBAL_VARS vars;

    time_t start_time;
    time_t end_time;

    // check arguments
    if (argc < 3)
    {
        show_usage();
        return 0;
    }

    memset(&vars, 0, sizeof(GLOBAL_VARS));

    for (i = 1; i < argc; i++)
    {
        if (*(argv[i]) == '-')
        {
            parse_cmd(&vars, argv[i] + 1);
        }
        else
        {
            show_usage();
            return 0;
        }
    }

    if (vars.input_streams == 0)
    {
        printf("No source streams specified\n");
        return 1;
    }

    if (!vars.output_filename)
    {
        printf("No destination file specified\n");
        return 1;
    }

    // muxer settings
    if (vars.output_format == FILE_FORMAT_3GP)
    {
        if (!mp4MuxDefaults(&vars.set, FILE_FORMAT_3GP))
        {
            printf("Failed to set defaults\n");
            return 1;
        }
    }
    // muxer settings
    // standard = 0, Sony PSP = 1, iPod = 2, ISMA = 3, QT = 4, COMP_SONY_PMC = 5, 6 = flash, 7 = iPhone, 8 = iPad
    const int StreamCompatibility[9] = {0x00000000, 0x00004000, 0x00005000, 0x00006200, 0x4, 0x5, 0x6, 0x7, 0x00005010};

    if (vars.compatibility == COMP_SONY_XAVCS) {
        if (!mp4MuxDefaults(&vars.set, COMP_SONY_XAVCS)) {
            printf("Failed to set defaults\n");
            return 1;
        }
    }else if (!mp4MuxDefaults(&vars.set, StreamCompatibility[vars.compatibility]))
    {
        printf("Failed to set defaults\n");
        return 1;
    }

    if (vars.keepPS)
    {
        if (vars.keepPS > 1)
        {
            printf("Failed to set -k<flags>, it should be 1 or 0\n");
            return 1;
        }
        vars.set.KeepPS = vars.keepPS;
    }

    if (vars.compatibility == COMP_CMAF_LIVE_LL) {
        vars.set.cmaf_settings.fragment = vars.set.cmaf_settings.segment = vars.fragmented;
        vars.set.cmaf_settings.scale = 1e+7;
        vars.set.cmaf_settings.chunk = vars.cmaf_chunk_count ? vars.cmaf_chunk_count : 1;
    }
    // setup the settings structure
    vars.set.atom_ordering = vars.atom_ordering;
    vars.set.InputVideoTimescale = vars.MJ2_timescale;
    vars.set.sync_mode = 2; // set reconstruct time calculation mode
    vars.set.video_sequence_length = vars.length;
    vars.set.skip_box_size = vars.skip_box_size;
    vars.set.reserved_space_for_moov_size = vars.reserved_space_for_moov_size;

    mp4mux_time_code_settings_t qt_time_set;
    memset(&qt_time_set, 0, sizeof(mp4mux_time_code_settings_t));
        qt_time_set.Number_of_frames = 25;
    if (vars.set.stream_compatibility == 4/*QT*/)
        vars.set.time_code_settings = &qt_time_set;

    callbacks_t callbacks;
    init_callbacks(callbacks);
    // create muxer
    vars.mp4muxer = mp4MuxNew(&callbacks, NULL, &vars.set);
    if (vars.mp4muxer == NULL)
    {
        printf("Failed to create a muxer instance\n");
        return 1;
    }

    if (mp4MuxInitFile(vars.mp4muxer, 0, vars.output_filename))
    {
        mp4MuxFree(vars.mp4muxer);
        return 1;
    }

    uint32_t ret = 0;
    // add streams
    for (i  = 0; i < vars.input_streams; i++)
    {
		if (vars.sample_rate > 0)
		{
			mp4mux_stream_settings_t stream_set;
			mc_video_format_t video_format = {0};
			memset(&stream_set, 0, sizeof(mp4mux_stream_settings_t));
			video_format.avg_time_per_frame = vars.sample_rate;
			stream_set._format.pFormat = &video_format;
			stream_set._format.stream_mediatype = mctMinVideoType;
			stream_set._extended_language = vars.extended_language;

			ret = mp4MuxAddFile(vars.mp4muxer, &stream_set, vars.input_filenames[i]);
		}
		else
			ret = mp4MuxAddFile(vars.mp4muxer, NULL, vars.input_filenames[i]);

        if (ret)
    {
            mp4MuxFree(vars.mp4muxer);
            return 1;
    }
        mp4mux_stream_info_t si;
        memset(&si, 0, sizeof(mp4mux_stream_info_t));
        si.file_name = (uint8_t*)vars.input_filenames[i];

        int32_t ret = mp4MuxAuxInfo(vars.mp4muxer, 0, GET_STREAM_INFO, &si, sizeof(mp4mux_stream_info_t));
        printf("stream Id: %d , %s \n", si.track_id, si.file_name );
    }

    time (&start_time);

    printf ("Starting mux ...\n");

    // muxing
    mp4Mux(vars.mp4muxer);

    time (&end_time);

    // cleanup
    if (vars.mp4muxer)
    {
        mp4MuxDone(vars.mp4muxer, 0);
        mp4MuxFree(vars.mp4muxer);
    }

    printf("\nDone.\n");
    printf ("Muxing time <sec> : %4i\n", end_time - start_time);

    return 0;
}
