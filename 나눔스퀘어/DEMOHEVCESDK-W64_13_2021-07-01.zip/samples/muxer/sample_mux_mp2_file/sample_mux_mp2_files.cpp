/**
 @file  sample_mux_mp2_files.cpp
 @brief command-line sample for MPEG muxer
 @verbatim
 File: sample_mux_mp2_files.cpp
 Desc: command-line sample for MPEG muxer
 Copyright (c) 2020 MainConcept GmbH or its affiliates. All rights reserved.
 MainConcept and its logos are registered trademarks of MainConcept GmbH or its affiliates.
 This software is protected by copyright law and international treaties. Unauthorized
 reproduction or distribution of any portion is prohibited by law.
 @endverbatim
 **/

#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mux_mp2.h"
#include "sample_common_args.h"
#include "sample_common_misc.h"

#define N_INPUT_STREAMS 4

#define PROGRAM_NUM_FIRST 1
#define PROGRAM_PID_FIRST 1000
#define PROGRAM_PID_STEP 10

void print_usage()
{
    printf("\n==== MainConcept mpts filemux Muxer Sample ====\n\n"
        "Usage:\n" 
        "sample_mux_mp2_file.exe -i input1.mpg -i input2.mpg -i input3.mpg -i input4.mpg -o output_ts.mpts [-preset xx] [-clock_offset xx] [-vbr_multiplex] [-wrap_field_in_pes] [-dvb_eit xx] [-pcr_frames x] [-au_pack_size x]\n"
        "\n"
        "Supported input formats are:\n"
        "Video: MPEG 1/2, H.264, VC-1, MPEG-4\n"
        "Audio: MPEG Layer 1/2 Audio, AC-3 / AC-3 DDPlus, AAC ADTS / LATM, WAV. \n"
        "\n"
        "If present the pairs of streams [1,2] and [3,4] are coupled into Programs in the output MPTS\n"
        "\n"
        "- Specify -preset and a decimal preset value to initialize the muxer for a \n"
        "  specific preset, by default the DVB preset is used\n"
        "- Specify -wrap_field_in_pes option to create one PES header per field \n"
        "  for field-encoded AVC\n"
        "- Specify -dvb_eit xx option to insert extra DVB EIT tables \n"
        "  (table_id's 0x50-0x5F on PID 0x0012),\n"
        "  xx - is the number of tables, range is 1..16\n"
        "- Specify -dvb_eit_disable to disable insert Event Information Table (EIT) default feature\n"
        "- Specify -clock_offset to set a starting value of the SCR/PCR in ms\n"
        "- Specify -vbr_multiplex to force VBR multiplex overwriting the presets default\n"
        "- Specify -single-thread to enable single-threading mode (no locks) \n"
        "- Specify -smoothing to enable to enable packet rate smoothing \n"
        "- Specify -pcr_frames to force PCR on particular frames\n"
        "- Specify -au_pack_size to set the number of access units in a single PES packet\n"
        "- x can be: 0 - None, 1 - all frames, 2 - I frames, 3 - IDR frames\n"
        "\n"
        );
}

int32_t init_eit_tables(mp2muxer_tt* mp2muxer, int32_t program_id)
{
    uint8_t data_buf[256];
    memset(data_buf, 0, sizeof(uint8_t) * 256);

    // load an entry in the first EIT table with event_id = 4
    si_entry_struct entry;
    memset(&entry, 0, sizeof(si_entry_struct));
    entry.target_table_id = 0x50;
    entry.target_table_id_ext = program_id;
    entry.target_table_type =-1;                        // not required
    entry.target_entry_id = 4;                          // event_id
    entry.target_entry_id_ext = -1;                     // not used
    entry.replace_existing = 1;

    data_buf[0]  = 0;                                   // event_id hi
    data_buf[1]  = 4;                                   // event_id lo
    data_buf[2]  = 0xC0;                                // start_time[40 .. 33]  93/10/13 12:45:00
    data_buf[3]  = 0x79;                                // start_time[32 .. 25]
    data_buf[4]  = 0x12;                                // start_time[24 .. 17]
    data_buf[5]  = 0x45;                                // start_time[16 ..  9]
    data_buf[6]  = 0x00;                                // start_time[1  ..  8]

    data_buf[7]  = 0x01;                                // duration[24 .. 17]   01:45:30
    data_buf[8]  = 0x45;                                // duration[16 ..  9]
    data_buf[9]  = 0x30;                                // duration[1  ..  8]

    data_buf[10] = 0x80;                                // running_status = 4 + free_CA_mode = 0 + descriptors_loop_length hi
    data_buf[11] = 0;                                   // descriptors_loop_length lo

    entry.pbData = data_buf;
    entry.entry_length = 12;

    // now call this API function to load the entry....
    if (mpegOutMP2MuxLoadEntry(mp2muxer, &entry) != MUX_OK) {
        printf("mpegOutMP2MuxLoadEntry failed.\n");
        return -1;
    }

    si_commit_struct psi_struct = {0};
    // 0 = apply immediately
    // Note this control is in 27 MHz units. E.G. to apply the descriptor 10 mins
    // after the stream's beginning set to 16200000000
    psi_struct.target_time_PCR = 0;

    if (mpegOutMP2MuxCommitPSI(mp2muxer, &psi_struct) != MUX_OK) {
        printf("mpegOutMP2MuxCommitPSI failed.\n");
        return -1;
    }

    return 0;
}

constexpr int32_t ID_WRAP_FIELD = IDC_CUSTOM_START_ID + 1;
constexpr int32_t ID_DVB_EIT = ID_WRAP_FIELD + 1;
constexpr int32_t ID_SMOOTHING = ID_DVB_EIT + 1;
constexpr int32_t ID_PCR_FRAMES = ID_SMOOTHING + 1;
constexpr int32_t ID_AU_PACK_SIZE = ID_PCR_FRAMES + 1;
constexpr int32_t ID_DVB_EIT_DISABLE = ID_AU_PACK_SIZE + 1;

enum PCRFrames_e
{
    PCRFramesNone = 0,
    PCRFramesAll = 1,
    PCRFramesI = 2,
    PCRFramesIDR = 3
};

int main(int argc, char* argv[])
{
    mp2muxer_set_struct muxer_settings;
    mp2mux_ext_set_struct ext_muxer_settings;
    mp2mux_ts_program_set_struct program_settings;
    mp2muxer_tt* mp2muxer = 0;
    mp2mux_stream_set_struct stream_settings;
    uint8_t mpts_flag = 0;
    int32_t pmt_pid;
    char* in_file[N_INPUT_STREAMS];
    char* out_file;
    int32_t wrap_field_in_pes = 0;
    int32_t smoothing = 0;
    int32_t num_dvb_eit_tables = 0;
    int32_t presetID = MCPROFILE_DVB;
    int64_t clock_offset = 0;
    int32_t force_vbr_multiplex = 0;
    int32_t single_thread = 0;
    int32_t pcr_frames = PCRFramesNone;
    int32_t au_pack_size = 0;
    int32_t dvb_eit_disable = 0;

    memset(&muxer_settings, 0, sizeof(muxer_settings));
    memset(&stream_settings, 0, sizeof(stream_settings));
    memset(&ext_muxer_settings, 0, sizeof(ext_muxer_settings));
    memset(&program_settings, 0, sizeof(program_settings));
    memset(in_file, 0, sizeof(in_file));

    const std::vector<arg_item_t> params{
        {IDS_INPUT_FILE, 1, &in_file[0]},
        {IDS_INPUT_FILE, 0, &in_file[1]},
        {IDS_INPUT_FILE, 0, &in_file[2]},
        {IDS_INPUT_FILE, 0, &in_file[3]},
        {IDS_OUTPUT_FILE, 1, &out_file},
        {IDI_PRESET, 0, &presetID},
        {IDS_C_MP2_PCR_OFFSET, 0, &clock_offset},
        {IDS_C_MP2_VBR_MUX, 0, &force_vbr_multiplex},
        {IDI_SINGLE_THREAD_MODE, 0, &single_thread},
        {ID_DVB_EIT, 0, &num_dvb_eit_tables},
        {ID_WRAP_FIELD, 0, &wrap_field_in_pes},
        {ID_SMOOTHING, 0, &smoothing},
        {ID_PCR_FRAMES, 0, &pcr_frames},
        {ID_AU_PACK_SIZE, 0, &au_pack_size},
        {ID_DVB_EIT_DISABLE, 0,&dvb_eit_disable}
    };

    const std::vector<arg_item_desc_t> custom_params{
        arg_item_desc_t{ID_WRAP_FIELD, {"wrap_field_in_pes", ""}, ItemTypeNoArg, 1, "Specify option to create one PES header per field for field-encoded AVC"},
        arg_item_desc_t{ID_DVB_EIT, {"dvb_eit", ""}, ItemTypeInt, 16, "Specify option to insert extra DVB EIT tables"},
        arg_item_desc_t{ID_SMOOTHING, {"smoothing", ""}, ItemTypeNoArg, 1, "Specify option to enable packet rate smoothing"},
        arg_item_desc_t{ID_PCR_FRAMES, {"pcr_frames", ""}, ItemTypeInt, 0, "Specify frames to stamp with PCR"},
        arg_item_desc_t{ID_AU_PACK_SIZE, {"au_pack_size", ""}, ItemTypeInt, 0, "Specify the number of access units in a single PES packet"},
        arg_item_desc_t{ID_DVB_EIT_DISABLE, {"dvb_eit_disable", ""}, ItemTypeNoArg, 1, "Disable the default insert EIT table feature"}
    };

    if (parse_program_options(argc, argv, params, custom_params) < 0) {
        print_usage();
        return 1;
    }

    char in_file_real_path[N_INPUT_STREAMS][4096];
    for (int i = 0; i < N_INPUT_STREAMS; ++i) {
        if (!in_file[i]) {
            continue;
        }
        in_file[i] = path2real(in_file[i], in_file_real_path[i], 4096);
    }

    char out_file_real_path[4096];
    out_file = path2real(out_file, out_file_real_path, 4096);

    if (in_file[2] != NULL)
        mpts_flag = 1;

    if (presetID == ITEM_NOT_INIT)
        presetID = MCPROFILE_DVB;

    if (clock_offset == ITEM_NOT_INIT)
        clock_offset = 0;

    if (force_vbr_multiplex == ITEM_NOT_INIT)
        force_vbr_multiplex = 0;

    if (num_dvb_eit_tables == ITEM_NOT_INIT)
        num_dvb_eit_tables = 0;

    if (wrap_field_in_pes == ITEM_NOT_INIT)
        wrap_field_in_pes = 0;

    if (smoothing == ITEM_NOT_INIT)
        smoothing = 0;

    if (pcr_frames == ITEM_NOT_INIT)
        pcr_frames = PCRFramesNone;

    if (dvb_eit_disable == ITEM_NOT_INIT)
        dvb_eit_disable = 0;

    if (pcr_frames < PCRFramesNone || pcr_frames > PCRFramesIDR) {
        printf("The 'pcr_frames' option value must be in [0, 3].\n");
        return 1;
    }

    mpegOutMP2MuxDefaults(&muxer_settings, presetID);

    muxer_settings.sectors_delay = clock_offset;
    if (force_vbr_multiplex)
        muxer_settings.VBR_multiplex = 1;

    if (smoothing)
        muxer_settings.feature_flags |= MUX_FEATURE_PACKET_RATE_SMOOTHING;

    if (single_thread > 0)
        muxer_settings.feature_flags |= MUX_FEATURE_DISABLE_THREADING;

    switch (pcr_frames) {
        case PCRFramesAll:
            muxer_settings.feature_flags |= MUX_FEATURE_TS_PCR_ALL_FRAMES;
            break;
        case PCRFramesI:
            muxer_settings.feature_flags |= MUX_FEATURE_TS_PCR_IFRAMES;
            break;
        case PCRFramesIDR:
            muxer_settings.feature_flags |= MUX_FEATURE_TS_PCR_IDR_FRAMES;
            break;
        case PCRFramesNone:
        default:
            muxer_settings.feature_flags &= ~(MUX_FEATURE_TS_PCR_ALL_FRAMES | MUX_FEATURE_TS_PCR_IFRAMES | MUX_FEATURE_TS_PCR_IDR_FRAMES);
            break;
    }

    if (dvb_eit_disable)   // to disable insert EIT feature
        ext_muxer_settings.EIT_PID = -1;

    callbacks_t callbacks;
    init_callbacks(callbacks);

    mp2muxer = mpegOutMP2MuxNew(&callbacks, NULL, &muxer_settings);
    if (!mp2muxer) {
        printf("mpegOutMP2MuxNew failed.\n");
        return 1;
    }
    printf("Muxer instantiated...\n");

    if (mpegOutMP2MuxInitFile(mp2muxer, &ext_muxer_settings, out_file) != MUX_OK) {
        printf("mpegOutMP2MuxInitFile failed.\n");
        mpegOutMP2MuxFree(mp2muxer);
        return 1;
    }

    if (mpts_flag) {
        // create the first program, this is optional if only one program is needed
        pmt_pid = PROGRAM_PID_FIRST;

        program_settings.program_PID = pmt_pid;
        program_settings.program_number = PROGRAM_NUM_FIRST;
        program_settings.PCR_PID = pmt_pid + 1;

        if (num_dvb_eit_tables && ((presetID == MPEG_DVB) || (presetID == MCPROFILE_DVB)))
            program_settings.DVB_num_of_extra_EITs = 16;

        if (mpegOutMP2MuxAddProgram(mp2muxer, &program_settings) != MUX_OK) {
            printf("mpegOutMP2MuxAddProgram 1 failed.\n");
            mpegOutMP2MuxFree(mp2muxer);
            return 1;
        }
        printf("Program 1 added...\n");

        stream_settings.parent_program_PID = pmt_pid;
        stream_settings.PID = pmt_pid + 1;
    }

    if (au_pack_size >= 0) {
        stream_settings.opt_packing_flag = 1;
        stream_settings.opt_packing_count = au_pack_size;
    }

    stream_settings.wrap_field_in_pes = wrap_field_in_pes; // enable to wrap each AVC field in a PES packet

    if (mpegOutMP2MuxAddFile(mp2muxer, &stream_settings, in_file[0], 0) != MUX_OK) {
        printf("mpegOutMP2MuxAddFile 1 failed.\n");
        mpegOutMP2MuxFree(mp2muxer);
        return 1;
    }
    printf("Stream 1 added...\n");

    if (in_file[1] != NULL) {
        if (mpts_flag)
            stream_settings.PID = pmt_pid + 2;

        if (mpegOutMP2MuxAddFile(mp2muxer, &stream_settings, in_file[1], 0) != MUX_OK) {
            printf("mpegOutMP2MuxAddFile 2 failed.\n");
            mpegOutMP2MuxFree(mp2muxer);
            return 1;
        }
        printf("Stream 2 added...\n");
    }

    if (mpts_flag) {
        // create the second program
        pmt_pid = PROGRAM_PID_FIRST + PROGRAM_PID_STEP;

        program_settings.program_PID = pmt_pid;
        program_settings.program_number = PROGRAM_NUM_FIRST + 1;
        program_settings.PCR_PID = pmt_pid + 1;

        if (num_dvb_eit_tables && ((presetID == MPEG_DVB) || (presetID == MCPROFILE_DVB)))
            program_settings.DVB_num_of_extra_EITs = 16;

        if (mpegOutMP2MuxAddProgram(mp2muxer, &program_settings) != MUX_OK) {
            printf("mpegOutMP2MuxAddProgram 2 failed.\n");
            mpegOutMP2MuxFree(mp2muxer);
            return 1;
        }
        printf("Program 2 added...\n");

        stream_settings.parent_program_PID = pmt_pid;
        stream_settings.PID = pmt_pid + 1;

        if (mpegOutMP2MuxAddFile(mp2muxer, &stream_settings, in_file[2], 0) != MUX_OK) {
            printf("mpegOutMP2MuxAddFile 3 failed.\n");
            mpegOutMP2MuxFree(mp2muxer);
            return 1;
        }
        printf("Stream 3 added...\n");

        if (in_file[3] != NULL) {
            stream_settings.parent_program_PID = pmt_pid;
            stream_settings.PID = pmt_pid + 2;

            if (mpegOutMP2MuxAddFile(mp2muxer, &stream_settings, in_file[3], 0) != MUX_OK) {
                printf("mpegOutMP2MuxAddFile 4 failed.\n");
                mpegOutMP2MuxFree(mp2muxer);
                return 1;
            }
            printf("Stream 4 added...\n");
        }
    }

    if ((presetID == MPEG_DVB) || (presetID == MCPROFILE_DVB)) {
        if (init_eit_tables(mp2muxer, PROGRAM_PID_FIRST)) {
            printf("Failed to initialize DVB EIT tables for program %d\n", PROGRAM_PID_FIRST);
            mpegOutMP2MuxFree(mp2muxer);
            return 1;
        }

        if (mpts_flag) {
            if (init_eit_tables(mp2muxer, PROGRAM_PID_FIRST + PROGRAM_PID_STEP)) {
                printf("Failed to initialize DVB EIT tables for program %d\n", PROGRAM_PID_FIRST + PROGRAM_PID_STEP);
                mpegOutMP2MuxFree(mp2muxer);
                return 1;
            }
        }
    }

    printf("Starting the multiplexing process...\n");

    int32_t ret = mpegOutMP2Mux(mp2muxer);
    if (ret) {
        printf("\nmpegOutMP2Mux returned error (%d)\n", ret);
    }
    else {
        printf("\nDone successfully!\n");
    }

    mpegOutMP2MuxDone(mp2muxer, ret);
    mpegOutMP2MuxFree(mp2muxer);

    return ret;
}
