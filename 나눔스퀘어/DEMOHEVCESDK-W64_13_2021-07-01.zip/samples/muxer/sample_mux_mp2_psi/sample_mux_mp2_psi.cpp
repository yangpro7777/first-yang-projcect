/********************************************************************
 Created: 2011/04/06 
 File name: sample_mux_mp2_psi.cpp
 Purpose: command-line sample for MPEG muxer

 Copyright (c) 2005-2011 MainConcept GmbH. All rights reserved.

 This software is the confidential and proprietary information of
 MainConcept GmbH and may be used only in accordance with the terms of
 your license from MainConcept GmbH.

*********************************************************************/

#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "mctypes.h"
#include "bufstrm.h"
#include "sample_common_args.h"
#include "sample_common_misc.h"

#include "mux_mp2.h"

#define BASE_PROGRAM_PID              0x1E0
#define BASE_AUDIO_PID                0x1E2
#define BASE_VIDEO_PID                0x1E1
#define BASE_PROGRAM_NUMBER           1
#define BASE_ATSC_MAJOR_CHANNEL       5
#define BASE_ATSC_MINOR_CHANNEL       1
#define BASE_ATSC_SOURCE_ID           2

#define TRANSPORT_STREAM_ID           1


class TableInfo
{
public:
    TableInfo(uint16_t PCR_PID, int32_t program_number)
        : m_PCR_PID(PCR_PID), m_program_number(program_number) {};

    uint16_t m_PCR_PID;
    int32_t m_program_number;
};


typedef struct app_vars_s
{
    mp2muxer_tt *mp2muxer;
    
    char * in_file_v;
    char * in_file_a1;
    char * in_file_a2;

    int32_t mux_profile;

    std::vector<TableInfo> table_infos;
} app_vars_t;


int add_atsc_psi_program_items(app_vars_t *pVars, int program_idx)
{
    si_entry_struct entry;
    uint8_t data_buf[256];

    // load an entry in the first EIT table with event_id = 4
    memset(&entry, 0, sizeof(si_entry_struct));
    entry.target_table_id = 0xCB;                                   // ATSC EIT table ID
    entry.target_table_id_ext = BASE_ATSC_SOURCE_ID + program_idx;  // source_id
    entry.target_table_type = 0x0100;                               // EIT0 ID
    entry.target_entry_id = 4;                                      // event_id
    entry.target_entry_id_ext = -1;                                 // not used
    entry.replace_existing = 1;

    data_buf[0] = 0xC0;     // reserved + event_id hi
    data_buf[1] = 4;        // event_id lo
    data_buf[2] = 0;        // start_time[0]
    data_buf[3] = 0;        // start_time[1]
    data_buf[4] = 0xA8;     // start_time[2]
    data_buf[5] = 0xC0;     // start_time[3] (12:00:00 GMT)

    data_buf[6] = 0xC0;     // reserved + ETM_location = 0 + length_in_seconds high
    data_buf[7] = 0x38;     // length_in_seconds (9 .. 16) (default = 4 hours)
    data_buf[8] = 0x40;     // length_in_seconds (1 .. 8)

    data_buf[9] = 17;       // title_length

    data_buf[10] = 1;       // num_strings
    data_buf[11] = 'e';     // 'e'
    data_buf[12] = 'n';     // 'n'
    data_buf[13] = 'g';     // 'g'
    data_buf[14] = 1;       // num_segments
    data_buf[15] = 0;       // compression_type
    data_buf[16] = 0;       // mode
    data_buf[17] = 9;       // number_bytes

    data_buf[18] = 'P';
    data_buf[19] = 'r';
    data_buf[20] = 'o';
    data_buf[21] = 'g';
    data_buf[22] = 'r';
    data_buf[23] = 'a';
    data_buf[24] = 'm';
    data_buf[25] = ' ';
    data_buf[26] = '0' + BASE_PROGRAM_NUMBER + program_idx;

    data_buf[27] = 0xF0;    // descriptor_length high | 0xF0
    data_buf[28] = 6;       // descriptor_length low

    data_buf[29] = 0x87;    // content_advisory_descriptor
    data_buf[30] = 4;       // descriptor_length
    data_buf[31] = 0xC1;    // reserved + rating_region_count = 1
    data_buf[32] = 1;       // rating_region = 1
    data_buf[33] = 0;       // rated_dimensions = 0
    data_buf[34] = 0;       // rating_description_length = 0

    entry.pbData = data_buf;
    entry.entry_length = 35;

    // now call this API function to load the entry....
    if (mpegOutMP2MuxLoadEntry(pVars->mp2muxer, &entry) != MUX_OK)
    {
        printf("mpegOutMP2MuxLoadEntry failed.\n");
        return 1;
    }

    return 0;
}


int add_dvb_psi_program_items(app_vars_t *pVars, int program_idx)
{
    si_entry_struct entry;
    uint8_t data_buf[256];
    int program_number = BASE_PROGRAM_NUMBER + program_idx;

    // load an entry in the DVB SDT table with running_status = 'running'
    memset(&entry, 0, sizeof(si_entry_struct));
    entry.target_table_id = 0x42;                       // DVB SDT table ID
    entry.target_table_id_ext = TRANSPORT_STREAM_ID;    // transport_stream_id in PAT
    entry.target_table_type = -1;                       // not used
    entry.target_entry_id = program_number;             // service_id
    entry.target_entry_id_ext = -1;                     // service_id is a primary key of a SDT entry, therefore nothing is required as the extension
    entry.replace_existing = 1;

    data_buf[0] = (uint8_t)(program_number >> 8);       // service_id hi
    data_buf[1] = (uint8_t)(program_number & 0xFF);     // service_id lo
    data_buf[2] = 0xFC;                                 // reserved_future_use + EIT_schedule_flag = 0 + EIT_present_following_flag = 0
    data_buf[3] = 0x80;                                 // running_status = 4 + free_CA_mode = 0 + descriptors_loop_length hi
    data_buf[4] = 0;                                    // descriptors_loop_length lo
    entry.pbData = data_buf;
    entry.entry_length = 5;

    // now call this API function to load the entry
    if (mpegOutMP2MuxLoadEntry(pVars->mp2muxer, &entry) != MUX_OK)
    {
        printf("mpegOutMP2MuxLoadEntry failed.\n");
        return 1;
    }

    // load an entry in the DVB EIT table
    int event_id = 4;                                   // can be any unique number
    memset(&entry, 0, sizeof(si_entry_struct));
    entry.target_table_id = 0x50;                       // DVB EIT table ID
    entry.target_table_id_ext = program_number;         // service_id = program number
    entry.target_table_type = -1;                       // not used
    entry.target_entry_id = event_id;                   // event_id
    entry.target_entry_id_ext = -1;                     // event_id is a primary key of a EIT entry, therefore nothing is required as the extension
    entry.replace_existing = 1;

    data_buf[0]  = event_id >> 8;                       // event_id hi
    data_buf[1]  = event_id & 0xFF;                     // event_id lo
    data_buf[2]  = 0xC0;                                // start_time[40 .. 33]  93/10/13 12:45:00
    data_buf[3]  = 0x79;                                // start_time[32 .. 25]
    data_buf[4]  = 0x12;                                // start_time[24 .. 17]
    data_buf[5]  = 0x45;                                // start_time[16 ..  9]
    data_buf[6]  = 0x00;                                // start_time[1  ..  8]

    data_buf[7]  = 0x01;                                // duration[24 .. 17]   01:45:30
    data_buf[8]  = 0x45;                                // duration[16 ..  9]
    data_buf[9]  = 0x30;                                // duration[1  ..  8]

    data_buf[10] = 0x80;                                // running_status = 4 + free_CA_mode = 0 + descriptors_loop_length hi
    data_buf[11] = 0;                                   // descriptors_loop_length lo

    entry.pbData = data_buf;
    entry.entry_length = 12;

    // now call this API function to load the entry
    if (mpegOutMP2MuxLoadEntry(pVars->mp2muxer, &entry) != MUX_OK)
    {
        printf("mpegOutMP2MuxLoadEntry failed.\n");
        return 1;
    }

    return 0;
}


int add_program_and_streams(app_vars_t *pVars, int program_idx)
{
    int program_pid = BASE_PROGRAM_PID + 0x0010 * program_idx;
    int video_pid = BASE_VIDEO_PID + 0x0010 * program_idx;
    int audio_pid = BASE_AUDIO_PID + 0x0010 * program_idx;
    int program_number = BASE_PROGRAM_NUMBER + program_idx;

    mp2mux_ts_program_set_struct program_settings;
    mp2mux_stream_set_struct stream_settings;
    si_descriptor_struct desc;
    uint8_t data_buf[256];

    memset(&program_settings, 0, sizeof(mp2mux_ts_program_set_struct));
    memset(&stream_settings, 0, sizeof(mp2mux_stream_set_struct));

    // put the PCR on the video stream
    program_settings.PCR_PID = video_pid;
    program_settings.program_number = program_number;
    program_settings.program_PID = program_pid;

    if ((pVars->mux_profile == MCPROFILE_ATSC) ||
        (pVars->mux_profile == MCPROFILE_ATSCHI) ||
        (pVars->mux_profile == MCPROFILE_ATSC_C))
    {
        program_settings.atsc_major_channel = BASE_ATSC_MAJOR_CHANNEL + program_idx;
        program_settings.atsc_minor_channel = BASE_ATSC_MINOR_CHANNEL;
        program_settings.atsc_modulation_mode = atsc_modulation_mode_ATSC_16VSB;
        program_settings.atsc_service_type = atsc_service_type_digital_television;
        program_settings.atsc_source_id = BASE_ATSC_SOURCE_ID + program_idx;
    }
    else if (pVars->mux_profile == MCPROFILE_DVB)
    {
        program_settings.DVB_num_of_extra_EITs = 16;
    }

    if (mpegOutMP2MuxAddProgram(pVars->mp2muxer, &program_settings) != MUX_OK)
    {
        printf("mpegOutMP2MuxAddProgram failed.\n");
        return 1;
    }
    printf("Added program %d...\n", program_idx);

    stream_settings.parent_program_PID = program_pid;
    stream_settings.PID = video_pid;
    stream_settings.flags = STREAM_FLAG_VIDEO_STREAM;
        
    if (mpegOutMP2MuxAddFile(pVars->mp2muxer, &stream_settings, pVars->in_file_v, 0) != MUX_OK)
    {
        printf("mpegOutMP2MuxAddFile failed for video file.\n");
        return 1;
    }
    printf ("  Video stream added...\n");

    stream_settings.PID = audio_pid;
    stream_settings.flags = STREAM_FLAG_AUDIO_STREAM;

    if (mpegOutMP2MuxAddFile(pVars->mp2muxer, &stream_settings, pVars->in_file_a1, 0) != MUX_OK)
    {
        printf("mpegOutMP2MuxAddFile failed for first audio file.\n");
        return 1;
    }
    printf("  Audio stream 1 added...\n");

    if (pVars->in_file_a2)
    {
        stream_settings.PID = audio_pid + 1;

        if (mpegOutMP2MuxAddFile(pVars->mp2muxer, &stream_settings, pVars->in_file_a2, 0) != MUX_OK)
        {
            printf("mpegOutMP2MuxAddFile failed for second audio file.\n");
            return 1;
        }
        printf ("  Audio stream 2 added...\n");
    }


    // setup language descriptor for first audio stream
    memset(&desc, 0, sizeof(si_descriptor_struct));
    desc.target_table_id = 0x02;                    // PMT Table ID
    desc.target_table_id_ext = program_number;      // specify the target program number
    desc.target_table_type = -1;                    // not needed for PMT
    desc.target_entry_id = audio_pid;
    desc.target_entry_id_ext = -1;                  // PID is a primary key of the PMT entry, therefore nothing is required as the extension
    desc.target_loop = eInner_descriptor_loop;      // it goes into INNER descriptor loop, other words, applied to the stream
    desc.replace_existing = 1;                      // replace any existing language descriptor

    data_buf[0] = 'e';                              // English
    data_buf[1] = 'n';
    data_buf[2] = 'g';
    data_buf[3] = '\0';
    desc.descriptor_tag = 10;                       // lang_desc tag
    desc.descriptor_length = 4;                     // 4 bytes of payload
    desc.pbData = data_buf;

    // now load the descriptor
    if (mpegOutMP2MuxLoadDescriptor(pVars->mp2muxer, &desc) != MUX_OK)
    {
        printf("mpegOutMP2MuxLoadDescriptor failed for first audio stream.\n");
        return 1;
    }

    if (pVars->in_file_a2)
    {
        // setup language descriptor for secondary audio stream
        memset(&desc, 0, sizeof(si_descriptor_struct));
        desc.target_table_id = 0x02;
        desc.target_table_id_ext = program_number;
        desc.target_table_type = -1;
        desc.target_entry_id = audio_pid + 1;
        desc.target_entry_id_ext = -1;
        desc.target_loop = eInner_descriptor_loop;
        desc.replace_existing = 1;

        data_buf[0] = 'e';    // Spanish
        data_buf[1] = 's';
        data_buf[2] = 'p';
        data_buf[3] = '\0';
        desc.descriptor_tag = 10;
        desc.descriptor_length = 4;
        desc.pbData = data_buf;

        if (mpegOutMP2MuxLoadDescriptor(pVars->mp2muxer, &desc) != MUX_OK)
        {
            printf("mpegOutMP2MuxLoadDescriptor failed for second audio stream.\n");
            return 1;
        }
    }

    if ((pVars->mux_profile == MCPROFILE_ATSC) ||
        (pVars->mux_profile == MCPROFILE_ATSCHI) ||
        (pVars->mux_profile == MCPROFILE_ATSC_C))
    {
        if (add_atsc_psi_program_items(pVars, program_idx))
            return 1;
    }
    else if (pVars->mux_profile == MCPROFILE_DVB)
    {
        if (add_dvb_psi_program_items(pVars, program_idx))
            return 1;
    }

    pVars->table_infos.emplace_back(program_settings.PCR_PID, program_settings.program_number);
    return 0;
}

static unsigned int uint2bcd(unsigned int ival)
{
    return ((ival / 10) << 4) | (ival % 10);
}


void print_usage()
{
    printf("Usage:\n sample_mux_mp2_psi.exe -v video.mpg -a audio.mpg [-a audio2.mpg] -o output_ts.m2t [-preset xx] [-programs=xx]\n"
           "Supported input formats are:\n Video: MPEG 1/2, H.264, VC-1, MPEG-4\n"
           "Audio: MPEG Layer 1/2 Audio, AC-3 / AC-3 DDPlus, AAC ADTS / LATM. \n"
           "Specify -preset and a decimal preset value to initialize the muxer for a specific preset, by default the DVB preset is used\n"
           "Specify -programs and a decimal value to set the number of programs in the mux, default is 1\n"
           );
}


int main(int argc, char* argv[])
{
    app_vars_t vars = {0};
    mp2muxer_set_struct muxer_settings = {0};
    mp2mux_ext_set_struct ext_muxer_settings = {0};
    si_section_struct section;
    uint8_t data_buf[256];
    char * out_file;
    uint32_t num_programs = 1;    // if > 1 the same input streams are muxed for each program
    char * custom_arg;

    arg_item_t params[] =
    {
        { IDS_VIDEO_FILE,    1,  &vars.in_file_v},
        { IDS_AUDIO_FILE,    1,  &vars.in_file_a1},
        { IDS_AUDIO_FILE,    0,  &vars.in_file_a2},
        { IDS_OUTPUT_FILE,   1,  &out_file},
        { IDI_PRESET,        0,  &vars.mux_profile},
        { IDS_CUSTOM_ARG,    0,  &custom_arg},
    };

    printf("\n==== MainConcept PSI Muxer Sample ====\n");

    if (parse_args(argc - 1, argv + 1, sizeof(params) / sizeof(params[0]), params) < 0)
    {
        print_usage();
        return 1;
    }

    if(custom_arg)
    {
        if(!strncmp(custom_arg, "-programs", strlen("-programs")))
        {
            char *arg_value = strchr(custom_arg, '=');
            if(!arg_value || strlen(arg_value) <= 1) {
                num_programs = 1;
            }
            else {
                num_programs = atoi(++arg_value);
            }
        }
        else
        {
            print_usage();
            return 1;
        }
    }

    if (vars.mux_profile <= 0)
        vars.mux_profile = MCPROFILE_DVB;

    mpegOutMP2MuxDefaults(&muxer_settings, vars.mux_profile);

    callbacks_t callbacks;
    init_callbacks(callbacks);
    vars.mp2muxer = mpegOutMP2MuxNew(&callbacks, NULL, &muxer_settings);
    if (!vars.mp2muxer)
    {
        printf("mpegOutMP2MuxNew failed.\n");
        return 1;
    }
    printf("Muxer instance created...\n");

    ext_muxer_settings.transport_id = TRANSPORT_STREAM_ID;
    if (mpegOutMP2MuxInitFile(vars.mp2muxer, &ext_muxer_settings, out_file) != MUX_OK)
    {
        printf("mpegOutMP2MuxInitFile failed.\n");
        mpegOutMP2MuxFree(vars.mp2muxer);
        return 1;
    }

    for (int idx = 0; idx < num_programs; idx++)
    {
        if (add_program_and_streams(&vars, idx))
        {
            mpegOutMP2MuxFree(vars.mp2muxer);
            return 1;
        }
    }

    // general PSI items
    if ((vars.mux_profile == MCPROFILE_ATSC) ||
        (vars.mux_profile == MCPROFILE_ATSCHI) ||
        (vars.mux_profile == MCPROFILE_ATSC_C))
    {
        memset(&section, 0, sizeof(si_section_struct));
        section.target_table_id = 0xCA;               // RRT table ID
        section.target_table_id_ext = -1;
        section.target_table_type = -1;

        data_buf[0]  = 0xCA;                          // RRT table
        data_buf[1]  = 0xF0;                          // section length high | 0xF0
        data_buf[2]  = 80;                            // section length low
        data_buf[3]  = 0xFF;                          // reserved
        data_buf[4]  = 1;                             // rating region
        data_buf[5]  = 0xC3;                          // reserved + version_number = 1 + current_next_indicator set
        data_buf[6]  = 0;                             // section_number
        data_buf[7]  = 0;                             // last_section_number
        data_buf[8]  = 0;                             // protocol version

        data_buf[9]  = 11;                            // rating region name length
        data_buf[10] = 1;                             // number of strings
        data_buf[11] = 0x65;                          // ISO 639 language code
        data_buf[12] = 0x6E;                          // ISO 639 language code
        data_buf[13] = 0x67;                          // ISO 639 language code
        data_buf[14] = 1;                             // number of segments
        data_buf[15] = 0;                             // compression type
        data_buf[16] = 0;                             // mode
        data_buf[17] = 3;                             // number bytes
        data_buf[18] = 'N';                           // name
        data_buf[19] = '/';                           // name
        data_buf[20] = 'A';                           // name

        data_buf[21] = 1;                             // dimensions defined
    
        data_buf[22] = 11;                            // dimension name length
        data_buf[23] = 1;                             // number of strings
        data_buf[24] = 0x65;                          // ISO 639 language code
        data_buf[25] = 0x6E;                          // ISO 639 language code
        data_buf[26] = 0x67;                          // ISO 639 language code
        data_buf[27] = 1;                             // number of segments
        data_buf[28] = 0;                             // compression type
        data_buf[29] = 0;                             // mode
        data_buf[30] = 3;                             // number bytes
        data_buf[31] = 'N';                           // name
        data_buf[32] = '/';                           // name
        data_buf[33] = 'A';                           // name
    
        data_buf[34] = 0xF2;                          // 0xE0 | graduated scale | values defined
    
        // rating 0
        data_buf[35] = 8;                             // abbrev rating value length
        data_buf[36] = 1;                             // number of strings
        data_buf[37] = 0x65;                          // ISO 639 language code
        data_buf[38] = 0x6E;                          // ISO 639 language code
        data_buf[39] = 0x67;                          // ISO 639 language code
        data_buf[40] = 1;                             // number of segments
        data_buf[41] = 0;                             // compression type
        data_buf[42] = 0;                             // mode
        data_buf[43] = 0;                             // number bytes

        data_buf[44] = 8;                             // rating value length
        data_buf[45] = 1;                             // number of strings
        data_buf[46] = 0x65;                          // ISO 639 language code
        data_buf[47] = 0x6E;                          // ISO 639 language code
        data_buf[48] = 0x67;                          // ISO 639 language code
        data_buf[49] = 1;                             // number of segments
        data_buf[50] = 0;                             // compression type
        data_buf[51] = 0;                             // mode
        data_buf[52] = 0;                             // number bytes

        // rating 1
        data_buf[53] = 11;                            // abbrev rating value length
        data_buf[54] = 1;                             // number of strings
        data_buf[55] = 0x65;                          // ISO 639 language code
        data_buf[56] = 0x6E;                          // ISO 639 language code
        data_buf[57] = 0x67;                          // ISO 639 language code
        data_buf[58] = 1;                             // number of segments
        data_buf[59] = 0;                             // compression type
        data_buf[60] = 0;                             // mode
        data_buf[61] = 3;                             // number bytes
        data_buf[62] = 'N';                           // abbrev rating text
        data_buf[63] = '/';                           // abbrev rating text
        data_buf[64] = 'A';                           // abbrev rating text
    
        data_buf[65] = 11;                            // rating value length
        data_buf[66] = 1;                             // number of strings
        data_buf[67] = 0x65;                          // ISO 639 language code
        data_buf[68] = 0x6E;                          // ISO 639 language code
        data_buf[69] = 0x67;                          // ISO 639 language code
        data_buf[70] = 1;                             // number of segments
        data_buf[71] = 0;                             // compression type
        data_buf[72] = 0;                             // mode
        data_buf[73] = 3;                             // number bytes
        data_buf[74] = 'N';                           // rating text
        data_buf[75] = '/';                           // rating text
        data_buf[76] = 'A';                           // rating text
    
        data_buf[77] = 0xFC;                          // descriptors length high | 0xFC
        data_buf[78] = 0;                             // descriptors length low

        // the muxer will compute the CRC over this length
        section.pbData = data_buf;
        section.section_length = 79;

        // now call this API function to load the section
        if (mpegOutMP2MuxLoadSection(vars.mp2muxer, &section) != MUX_OK)
        {
            printf("mpegOutMP2MuxLoadSection failed.\n");
            mpegOutMP2MuxFree(vars.mp2muxer);
            return 1;
        }
    }
    else if (vars.mux_profile == MCPROFILE_DVB)
    {
        memset(&section, 0, sizeof(si_section_struct));
        section.target_table_id = 0x70;               // TDT table ID
        section.target_table_id_ext = -1;
        section.target_table_type = -1;

        time_t ltime;
        struct tm *gmt;
        int32_t y, m, d, l, ymd;
    
        time(&ltime);
        gmt = gmtime(&ltime);
        y = gmt->tm_year;
        m = gmt->tm_mon + 1;
        d = gmt->tm_mday;

        if (m == 1 || m == 2)
            l = 1;
        else
            l = 0;

        ymd = 14956 + d + (int32_t)((y - l) * 365.25) + (int32_t)((m + 1 + l * 12) * 30.6001);

        data_buf[0] = 0x70;              // TDT table
        data_buf[1] = 0x70;              // section_syntax_indicator = 0 + reserved + section length high
        data_buf[2] = 5;                 // section length low

        data_buf[3] = ymd >> 8;          // UTC_time YMD high
        data_buf[4] = ymd & 0xFF;        // UTC_time YMD low
        data_buf[5] = uint2bcd(gmt->tm_hour);      // UTC_time hour
        data_buf[6] = uint2bcd(gmt->tm_min);       // UTC_time min
        data_buf[7] = uint2bcd(gmt->tm_sec);       // UTC_time sec

        section.pbData = data_buf;
        section.section_length = 8;

        // now call this API function to load the section
        if (mpegOutMP2MuxLoadSection(vars.mp2muxer, &section) != MUX_OK)
        {
            printf("mpegOutMP2MuxLoadSection failed.\n");
            mpegOutMP2MuxFree(vars.mp2muxer);
            return 1;
        }
    }
    else if (vars.mux_profile == MPEG_TS)
    {
        uint8_t sections_data[8] {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};
        for (auto table_info : vars.table_infos) {
            si_table_struct table = {};
            table.PID = table_info.m_PCR_PID + 0x100;
            table.parent_program_number = table_info.m_program_number;
            table.stream_type = 0x86; // SCTE-35 splice info section
            table.table_id = 0xfc;

            if(mpegOutMP2MuxAddTable(vars.mp2muxer, &table) != MUX_OK)
            {
                printf("mpegOutMP2MuxAddTable failed.\n");
                mpegOutMP2MuxFree(vars.mp2muxer);
                return 1;
            }

            si_section_struct section = {};
            section.pbData = sections_data;
            section.section_length = 8;
            section.target_table_id = table.table_id;
            section.target_table_id_ext = -1;
            section.target_table_PID = table.PID;
            section.target_table_type = -1;

            if (mpegOutMP2MuxLoadSection(vars.mp2muxer, &section) != MUX_OK)
            {
                printf("mpegOutMP2MuxLoadSection failed.\n");
                mpegOutMP2MuxFree(vars.mp2muxer);
                return 1;
            }
        }
    }

    si_commit_struct psi_struct = {0}; 
    // 0 = apply immediately
    // Note this control is in 27 MHz units. E.G. to apply the descriptor 10 mins
    // after the stream's beginning set to 16200000000
    psi_struct.target_time_PCR = 0;
        
    if (mpegOutMP2MuxCommitPSI(vars.mp2muxer, &psi_struct) != MUX_OK)
    {
        printf("mpegOutMP2MuxCommitPSI failed.\n");
        mpegOutMP2MuxFree(vars.mp2muxer);
        return 1;
    }

    printf ("Starting the multiplexing process, press any key to abort...\n");

    if (mpegOutMP2Mux(vars.mp2muxer) != MUX_ERR)
        printf("\nDone successfully!\n");

    mpegOutMP2MuxDone(vars.mp2muxer, 0);
    mpegOutMP2MuxFree(vars.mp2muxer);

    return 0;
}

