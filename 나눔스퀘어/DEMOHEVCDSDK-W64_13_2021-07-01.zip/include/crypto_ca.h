#pragma once

enum eCA_TS_Mode{CA_TS_MODE_AES128_CBC = 0, CA_TS_MODE_LAST};
enum eCA_TS_BlockTermMode{CA_TS_BT_SCTE52 = 0, CA_TS_BT_LAST};

